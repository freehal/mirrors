#!/usr/bin/perl -w
#
#   This program is free software; you can redistribute it and/or modify  
#   it under the terms of the GNU General Public License as published by  
#   the Free Software Foundation; either version 3 of the License, or     
#   (at your option) any later version.                                   
#                                                                         

$| = 1;

use strict;
use warnings;
use CGI;
use CGI::Carp qw(fatalsToBrowser);
use Config::Std;

our $cgi = new CGI;
print $cgi->header();

our $dir = './';


sub footer {
	open my $template, "<", "footer.template.html";
	print join '', <$template>;
	close $template;
}


open my $template, "<", "header.template.html";
print join '', <$template>;
close $template;



print << "EOT";
<iframe height="300" style="border: 1px solid #dee9ff !important; width: 70%; background-color: #ced8ed !important; border: 1px solid #dee9ff !important;
" src="http://developer.jeliza.org/online/jeliza-cgi-simple.pl" name="jeliza" style="border: 0;"></iframe>

<p>&nbsp;</p>

<form method="get" action="http://developer.jeliza.org/online/jeliza-cgi-simple.pl" target="jeliza">
	Sprechen Sie mit JEliza! Geben Sie hier einen Satz ein: <br />
	<input type="text" name="ask" value="" />	<input type="hidden" name="log" value="" />
	&nbsp;&nbsp;&nbsp;
	<select name="lang">
		<option value="de" >  German  </option>
		<option value="en">  English  </option>
	</select>
	&nbsp;&nbsp;&nbsp;
	<button name="ok" type='submit'>Antwort erhalten!</button>
</form>
<div style="clear: both;"></div>

EOT




print footer();
exit(0);


1;



