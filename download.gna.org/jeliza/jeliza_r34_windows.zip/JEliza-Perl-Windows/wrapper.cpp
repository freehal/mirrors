#include <iostream>
#include <windows.h>

using namespace std;


int main () {
	    if (AllocConsole()) {
        freopen("CON", "w", stdout);
        freopen("CON", "w", stderr);
    }


	system("perl.exe jeliza.pl");


	return 0;
}
