rm -rf dist JEliza-Perl-Windows JEliza-Perl-${V}
mkdir dist

export V=$(cat .version)

#cp -r ../JEliza\ Perl\ Windows/* dist/
cp -r ../JEliza\ Perl\ Windows/JElizaQT.exe ../JEliza\ Perl\ Windows/kernel.exe dist/
cp -r * dist/
rm dist/x.pl
find dist -name '.svn' | xargs rm -rf
find dist -name '.svn' | xargs rm -rf
find dist -name '.svn' | xargs rm -rf

rm -rf JEliza-Perl-Windows
mv dist JEliza-Perl-Windows

rm ../JEliza-Perl_${V}_windows.zip

wine /home/tobias/.wine/drive_c/Programme/ISTool/ISCC.exe ../jeliza-perl.iss

zip -r ../jeliza_${V}_windows.zip JEliza-Perl-Windows 2>&1 > /dev/null

rm -rf JEliza-Perl-Windows

################

rm -rf dist
mkdir dist

cp -r * dist/
find dist -name '.svn' | xargs rm -rf
find dist -name '.svn' | xargs rm -rf
find dist -name '.svn' | xargs rm -rf
rm -rf JEliza-Perl-${V}
mv dist JEliza-Perl-${V}
cd JEliza-Perl-${V}
rm x x.pl *.sh *.exe
cd ..
tar cplSzf ../jeliza_${V}_src.tgz JEliza-Perl-${V}
rm -rf JEliza-Perl-${V}

################

rm -rf dist
mkdir dist

cp -r * dist/
find dist -name '.svn' | xargs rm -rf
find dist -name '.svn' | xargs rm -rf
find dist -name '.svn' | xargs rm -rf
rm -rf JEliza-Perl-Linux-${V}
mv dist JEliza-Perl-Linux-${V}
cd JEliza-Perl-Linux-${V}

rm -r ../../JEliza/trunk/dist/linux/{lib,src}
cp -rf ../../JEliza/trunk/dist/linux/jelizaqt .
cp -rf ../../JEliza/trunk/dist/linux/bin/jelizaqt bin

rm x *.sh *.exe

cd ..
tar cplSzf ../jeliza_${V}_linux.tgz JEliza-Perl-Linux-${V}
rm -rf JEliza-Perl-Linux-${V}

