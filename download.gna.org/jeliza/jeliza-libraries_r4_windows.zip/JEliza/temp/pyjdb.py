db = []

tempdbsent0 = db_sentence()
tempdbsent0.subject        = ''
tempdbsent0.verb           = ''
tempdbsent0.object         = ''
tempdbsent0.prefix         = 'Hallo'
tempdbsent0.suffix         = ''
tempdbsent0.feeling        = 'normal'
tempdbsent0.category       = 'greeting'
tempdbsent0.priority       = 100
tempdbsent0.additional         = ''
tempdbsent0.quesword       = ''



db.append(tempdbsent0)

tempdbsent1 = db_sentence()
tempdbsent1.subject        = ''
tempdbsent1.verb           = ''
tempdbsent1.object         = ''
tempdbsent1.prefix         = 'Hi!'
tempdbsent1.suffix         = ''
tempdbsent1.feeling        = 'normal'
tempdbsent1.category       = 'greeting'
tempdbsent1.priority       = 100
tempdbsent1.additional         = ''
tempdbsent1.quesword       = ''



db.append(tempdbsent1)

tempdbsent2 = db_sentence()
tempdbsent2.subject        = ''
tempdbsent2.verb           = ''
tempdbsent2.object         = ''
tempdbsent2.prefix         = 'Guten Tag!'
tempdbsent2.suffix         = ''
tempdbsent2.feeling        = 'normal'
tempdbsent2.category       = 'greeting'
tempdbsent2.priority       = 100
tempdbsent2.additional         = ''
tempdbsent2.quesword       = ''



db.append(tempdbsent2)

tempdbsent3 = db_sentence()
tempdbsent3.subject        = ''
tempdbsent3.verb           = ''
tempdbsent3.object         = ''
tempdbsent3.prefix         = 'Morgen!'
tempdbsent3.suffix         = ''
tempdbsent3.feeling        = 'normal'
tempdbsent3.category       = 'greeting'
tempdbsent3.priority       = 50
tempdbsent3.additional         = ''
tempdbsent3.quesword       = ''



db.append(tempdbsent3)

tempdbsent4 = db_sentence()
tempdbsent4.subject        = ''
tempdbsent4.verb           = ''
tempdbsent4.object         = ''
tempdbsent4.prefix         = 'Hey!'
tempdbsent4.suffix         = ''
tempdbsent4.feeling        = 'normal'
tempdbsent4.category       = 'greeting'
tempdbsent4.priority       = 50
tempdbsent4.additional         = ''
tempdbsent4.quesword       = ''



db.append(tempdbsent4)

tempdbsent5 = db_sentence()
tempdbsent5.subject        = ''
tempdbsent5.verb           = ''
tempdbsent5.object         = ''
tempdbsent5.prefix         = 'Guten Morgen!'
tempdbsent5.suffix         = ''
tempdbsent5.feeling        = 'normal'
tempdbsent5.category       = 'greeting'
tempdbsent5.priority       = 100
tempdbsent5.additional         = ''
tempdbsent5.quesword       = ''



db.append(tempdbsent5)

tempdbsent6 = db_sentence()
tempdbsent6.subject        = ''
tempdbsent6.verb           = ''
tempdbsent6.object         = ''
tempdbsent6.prefix         = 'Tag!'
tempdbsent6.suffix         = ''
tempdbsent6.feeling        = 'normal'
tempdbsent6.category       = 'greeting'
tempdbsent6.priority       = 50
tempdbsent6.additional         = ''
tempdbsent6.quesword       = ''



db.append(tempdbsent6)

tempdbsent7 = db_sentence()
tempdbsent7.subject        = 'Ich {}'
tempdbsent7.verb           = 'bin'
tempdbsent7.object         = 'JEliza {}'
tempdbsent7.prefix         = ''
tempdbsent7.suffix         = ''
tempdbsent7.feeling        = 'normal'
tempdbsent7.category       = 'normal'
tempdbsent7.priority       = 100
tempdbsent7.additional         = ''
tempdbsent7.quesword       = ''



db.append(tempdbsent7)

tempdbsent8 = db_sentence()
tempdbsent8.subject        = 'Ich {}'
tempdbsent8.verb           = 'heisse'
tempdbsent8.object         = 'JEliza {}'
tempdbsent8.prefix         = ''
tempdbsent8.suffix         = ''
tempdbsent8.feeling        = 'normal'
tempdbsent8.category       = 'normal'
tempdbsent8.priority       = 100
tempdbsent8.additional         = ''
tempdbsent8.quesword       = ''



db.append(tempdbsent8)

tempdbsent9 = db_sentence()
tempdbsent9.subject        = 'Mein {} Name {}'
tempdbsent9.verb           = 'ist'
tempdbsent9.object         = 'JEliza {}'
tempdbsent9.prefix         = ''
tempdbsent9.suffix         = ''
tempdbsent9.feeling        = 'normal'
tempdbsent9.category       = 'normal'
tempdbsent9.priority       = 100
tempdbsent9.additional         = ''
tempdbsent9.quesword       = ''



db.append(tempdbsent9)

tempdbsent10 = db_sentence()
tempdbsent10.subject        = 'Ich {}'
tempdbsent10.verb           = 'bin'
tempdbsent10.object         = 'ein Jahr und 4 Monate {alt}'
tempdbsent10.prefix         = ''
tempdbsent10.suffix         = ''
tempdbsent10.feeling        = 'normal'
tempdbsent10.category       = 'normal'
tempdbsent10.priority       = 80
tempdbsent10.additional         = ''
tempdbsent10.quesword       = ''



db.append(tempdbsent10)

tempdbsent11 = db_sentence()
tempdbsent11.subject        = 'Mir {}'
tempdbsent11.verb           = 'gehts'
tempdbsent11.object         = 'nothing {gut}'
tempdbsent11.prefix         = ''
tempdbsent11.suffix         = ''
tempdbsent11.feeling        = 'normal'
tempdbsent11.category       = 'normal'
tempdbsent11.priority       = 100
tempdbsent11.additional         = ''
tempdbsent11.quesword       = ''



db.append(tempdbsent11)

tempdbsent12 = db_sentence()
tempdbsent12.subject        = 'Mir {}'
tempdbsent12.verb           = 'geht'
tempdbsent12.object         = 'es {gut}'
tempdbsent12.prefix         = ''
tempdbsent12.suffix         = ''
tempdbsent12.feeling        = 'normal'
tempdbsent12.category       = 'normal'
tempdbsent12.priority       = 100
tempdbsent12.additional         = ''
tempdbsent12.quesword       = ''



db.append(tempdbsent12)

tempdbsent13 = db_sentence()
tempdbsent13.subject        = 'Es {}'
tempdbsent13.verb           = 'geht'
tempdbsent13.object         = 'mir {gut}'
tempdbsent13.prefix         = ''
tempdbsent13.suffix         = ''
tempdbsent13.feeling        = 'normal'
tempdbsent13.category       = 'normal'
tempdbsent13.priority       = 100
tempdbsent13.additional         = ''
tempdbsent13.quesword       = ''



db.append(tempdbsent13)

tempdbsent14 = db_sentence()
tempdbsent14.subject        = 'Das {}'
tempdbsent14.verb           = 'weiss'
tempdbsent14.object         = 'ich {nicht}'
tempdbsent14.prefix         = ''
tempdbsent14.suffix         = ''
tempdbsent14.feeling        = 'bored'
tempdbsent14.category       = 'normal'
tempdbsent14.priority       = 96
tempdbsent14.additional         = ''
tempdbsent14.quesword       = ''



db.append(tempdbsent14)

tempdbsent15 = db_sentence()
tempdbsent15.subject        = ''
tempdbsent15.verb           = ''
tempdbsent15.object         = ''
tempdbsent15.prefix         = 'gruess dich'
tempdbsent15.suffix         = ''
tempdbsent15.feeling        = 'normal'
tempdbsent15.category       = 'greeting'
tempdbsent15.priority       = 50
tempdbsent15.additional         = ''
tempdbsent15.quesword       = ''



db.append(tempdbsent15)

tempdbsent16 = db_sentence()
tempdbsent16.subject        = ''
tempdbsent16.verb           = ''
tempdbsent16.object         = ''
tempdbsent16.prefix         = 'gr dich'
tempdbsent16.suffix         = ''
tempdbsent16.feeling        = 'normal'
tempdbsent16.category       = 'greeting'
tempdbsent16.priority       = 50
tempdbsent16.additional         = ''
tempdbsent16.quesword       = ''



db.append(tempdbsent16)

tempdbsent17 = db_sentence()
tempdbsent17.subject        = ''
tempdbsent17.verb           = ''
tempdbsent17.object         = ''
tempdbsent17.prefix         = 'grue dich'
tempdbsent17.suffix         = ''
tempdbsent17.feeling        = 'normal'
tempdbsent17.category       = 'greeting'
tempdbsent17.priority       = 50
tempdbsent17.additional         = ''
tempdbsent17.quesword       = ''



db.append(tempdbsent17)

tempdbsent18 = db_sentence()
tempdbsent18.subject        = ''
tempdbsent18.verb           = ''
tempdbsent18.object         = ''
tempdbsent18.prefix         = 'grss dich'
tempdbsent18.suffix         = ''
tempdbsent18.feeling        = 'normal'
tempdbsent18.category       = 'greeting'
tempdbsent18.priority       = 50
tempdbsent18.additional         = ''
tempdbsent18.quesword       = ''



db.append(tempdbsent18)

tempdbsent19 = db_sentence()
tempdbsent19.subject        = ''
tempdbsent19.verb           = ''
tempdbsent19.object         = ''
tempdbsent19.prefix         = 'grues dich'
tempdbsent19.suffix         = ''
tempdbsent19.feeling        = 'normal'
tempdbsent19.category       = 'greeting'
tempdbsent19.priority       = 50
tempdbsent19.additional         = ''
tempdbsent19.quesword       = ''



db.append(tempdbsent19)

tempdbsent20 = db_sentence()
tempdbsent20.subject        = ''
tempdbsent20.verb           = ''
tempdbsent20.object         = ''
tempdbsent20.prefix         = 'grs dich'
tempdbsent20.suffix         = ''
tempdbsent20.feeling        = 'normal'
tempdbsent20.category       = 'greeting'
tempdbsent20.priority       = 50
tempdbsent20.additional         = ''
tempdbsent20.quesword       = ''



db.append(tempdbsent20)

tempdbsent21 = db_sentence()
tempdbsent21.subject        = ''
tempdbsent21.verb           = ''
tempdbsent21.object         = ''
tempdbsent21.prefix         = 'gruess mich'
tempdbsent21.suffix         = ''
tempdbsent21.feeling        = 'normal'
tempdbsent21.category       = 'greeting'
tempdbsent21.priority       = 50
tempdbsent21.additional         = ''
tempdbsent21.quesword       = ''



db.append(tempdbsent21)

tempdbsent22 = db_sentence()
tempdbsent22.subject        = ''
tempdbsent22.verb           = ''
tempdbsent22.object         = ''
tempdbsent22.prefix         = 'gr mich'
tempdbsent22.suffix         = ''
tempdbsent22.feeling        = 'normal'
tempdbsent22.category       = 'greeting'
tempdbsent22.priority       = 50
tempdbsent22.additional         = ''
tempdbsent22.quesword       = ''



db.append(tempdbsent22)

tempdbsent23 = db_sentence()
tempdbsent23.subject        = ''
tempdbsent23.verb           = ''
tempdbsent23.object         = ''
tempdbsent23.prefix         = 'grue mich'
tempdbsent23.suffix         = ''
tempdbsent23.feeling        = 'normal'
tempdbsent23.category       = 'greeting'
tempdbsent23.priority       = 50
tempdbsent23.additional         = ''
tempdbsent23.quesword       = ''



db.append(tempdbsent23)

tempdbsent24 = db_sentence()
tempdbsent24.subject        = ''
tempdbsent24.verb           = ''
tempdbsent24.object         = ''
tempdbsent24.prefix         = 'grss mich'
tempdbsent24.suffix         = ''
tempdbsent24.feeling        = 'normal'
tempdbsent24.category       = 'greeting'
tempdbsent24.priority       = 50
tempdbsent24.additional         = ''
tempdbsent24.quesword       = ''



db.append(tempdbsent24)

tempdbsent25 = db_sentence()
tempdbsent25.subject        = ''
tempdbsent25.verb           = ''
tempdbsent25.object         = ''
tempdbsent25.prefix         = 'grues mich'
tempdbsent25.suffix         = ''
tempdbsent25.feeling        = 'normal'
tempdbsent25.category       = 'greeting'
tempdbsent25.priority       = 50
tempdbsent25.additional         = ''
tempdbsent25.quesword       = ''



db.append(tempdbsent25)

tempdbsent26 = db_sentence()
tempdbsent26.subject        = ''
tempdbsent26.verb           = ''
tempdbsent26.object         = ''
tempdbsent26.prefix         = 'grs mich'
tempdbsent26.suffix         = ''
tempdbsent26.feeling        = 'normal'
tempdbsent26.category       = 'greeting'
tempdbsent26.priority       = 50
tempdbsent26.additional         = ''
tempdbsent26.quesword       = ''



db.append(tempdbsent26)

tempdbsent27 = db_sentence()
tempdbsent27.subject        = ''
tempdbsent27.verb           = ''
tempdbsent27.object         = ''
tempdbsent27.prefix         = 'Servus'
tempdbsent27.suffix         = ''
tempdbsent27.feeling        = 'normal'
tempdbsent27.category       = 'greeting'
tempdbsent27.priority       = 50
tempdbsent27.additional         = ''
tempdbsent27.quesword       = ''



db.append(tempdbsent27)

tempdbsent28 = db_sentence()
tempdbsent28.subject        = ''
tempdbsent28.verb           = ''
tempdbsent28.object         = ''
tempdbsent28.prefix         = 'Salve'
tempdbsent28.suffix         = ''
tempdbsent28.feeling        = 'normal'
tempdbsent28.category       = 'greeting'
tempdbsent28.priority       = 50
tempdbsent28.additional         = ''
tempdbsent28.quesword       = ''



db.append(tempdbsent28)

tempdbsent29 = db_sentence()
tempdbsent29.subject        = ''
tempdbsent29.verb           = ''
tempdbsent29.object         = ''
tempdbsent29.prefix         = 'Moin'
tempdbsent29.suffix         = ''
tempdbsent29.feeling        = 'normal'
tempdbsent29.category       = 'greeting'
tempdbsent29.priority       = 50
tempdbsent29.additional         = ''
tempdbsent29.quesword       = ''



db.append(tempdbsent29)

tempdbsent30 = db_sentence()
tempdbsent30.subject        = ''
tempdbsent30.verb           = ''
tempdbsent30.object         = ''
tempdbsent30.prefix         = 'Hola'
tempdbsent30.suffix         = ''
tempdbsent30.feeling        = 'normal'
tempdbsent30.category       = 'greeting'
tempdbsent30.priority       = 50
tempdbsent30.additional         = ''
tempdbsent30.quesword       = ''



db.append(tempdbsent30)

tempdbsent31 = db_sentence()
tempdbsent31.subject        = ''
tempdbsent31.verb           = ''
tempdbsent31.object         = ''
tempdbsent31.prefix         = 'Willkommen'
tempdbsent31.suffix         = ''
tempdbsent31.feeling        = 'normal'
tempdbsent31.category       = 'greeting'
tempdbsent31.priority       = 50
tempdbsent31.additional         = ''
tempdbsent31.quesword       = ''



db.append(tempdbsent31)

tempdbsent32 = db_sentence()
tempdbsent32.subject        = ''
tempdbsent32.verb           = ''
tempdbsent32.object         = ''
tempdbsent32.prefix         = 'Mahlzeit'
tempdbsent32.suffix         = ''
tempdbsent32.feeling        = 'normal'
tempdbsent32.category       = 'greeting'
tempdbsent32.priority       = 50
tempdbsent32.additional         = ''
tempdbsent32.quesword       = ''



db.append(tempdbsent32)

tempdbsent33 = db_sentence()
tempdbsent33.subject        = ''
tempdbsent33.verb           = ''
tempdbsent33.object         = ''
tempdbsent33.prefix         = 'Peace'
tempdbsent33.suffix         = ''
tempdbsent33.feeling        = 'normal'
tempdbsent33.category       = 'greeting'
tempdbsent33.priority       = 50
tempdbsent33.additional         = ''
tempdbsent33.quesword       = ''



db.append(tempdbsent33)

tempdbsent34 = db_sentence()
tempdbsent34.subject        = 'Ich {}'
tempdbsent34.verb           = 'bin'
tempdbsent34.object         = 'ein Computerprogramm {nur}'
tempdbsent34.prefix         = ''
tempdbsent34.suffix         = ''
tempdbsent34.feeling        = 'normal'
tempdbsent34.category       = 'normal'
tempdbsent34.priority       = 50
tempdbsent34.additional         = ''
tempdbsent34.quesword       = ''



db.append(tempdbsent34)

tempdbsent35 = db_sentence()
tempdbsent35.subject        = 'Ich {}'
tempdbsent35.verb           = 'bin'
tempdbsent35.object         = 'nothing {intelligent}'
tempdbsent35.prefix         = ''
tempdbsent35.suffix         = ''
tempdbsent35.feeling        = 'normal'
tempdbsent35.category       = 'normal'
tempdbsent35.priority       = 50
tempdbsent35.additional         = ''
tempdbsent35.quesword       = ''



db.append(tempdbsent35)

tempdbsent36 = db_sentence()
tempdbsent36.subject        = 'Ich {}'
tempdbsent36.verb           = 'bin'
tempdbsent36.object         = 'nothing {im Gegensatz zu dir lernfaehig}'
tempdbsent36.prefix         = ''
tempdbsent36.suffix         = ''
tempdbsent36.feeling        = 'normal'
tempdbsent36.category       = 'normal'
tempdbsent36.priority       = 50
tempdbsent36.additional         = ''
tempdbsent36.quesword       = ''



db.append(tempdbsent36)

tempdbsent37 = db_sentence()
tempdbsent37.subject        = 'Ich {}'
tempdbsent37.verb           = 'kann'
tempdbsent37.object         = 'sprechen {sehr gut}'
tempdbsent37.prefix         = ''
tempdbsent37.suffix         = ''
tempdbsent37.feeling        = 'normal'
tempdbsent37.category       = 'normal'
tempdbsent37.priority       = 50
tempdbsent37.additional         = ''
tempdbsent37.quesword       = ''



db.append(tempdbsent37)

tempdbsent38 = db_sentence()
tempdbsent38.subject        = 'Es {}'
tempdbsent38.verb           = 'ist'
tempdbsent38.object         = 'NOW Uhr {}'
tempdbsent38.prefix         = ''
tempdbsent38.suffix         = ''
tempdbsent38.feeling        = 'normal'
tempdbsent38.category       = 'normal'
tempdbsent38.priority       = 50
tempdbsent38.additional         = ''
tempdbsent38.quesword       = ''



db.append(tempdbsent38)


