import string
import random
from jelizacpp import log
import time
from jelizacpp import *
from threading import *

def get_lang():
    fp = None
    try:
        fp = open("temp/language.tmp")
    except:
        fp = open("temp/language.tmp", "w")
        fp.write("de")
        fp.close()
        fp = open("temp/language.tmp")
    lang = fp.read().strip()
    fp.close()
    return lang

def containsWord (s1, s2):
    a = [" ", str(s1).replace(".", "").replace(",", "").replace("?", "").replace("!", ""), " "]
    b = [" ", str(s2), " "]

    return (string.find("".join(a), "".join(b)) > -1)

def contains (s1, s2):
    return (string.find(str(s1), str(s2)) > -1)

without_nonsense_cache = {}

unuseful_words = []

VERB = 5
NOMEN = 6
ADJ = 7
PREP = 8
PP = 9
ART = 10
QUESTIONWORD = 11


def loadcache():
    ''''''

def savecache():
    ''''''

def without_nonsense(question2):
  try:
    incache = without_nonsense_cache[question2]
    if bool(incache):
      incache = str(incache)
      if len(incache) > 0:
        return incache
  except:
    """"""

  question = question2 + ""
  question = question.replace("?","")
  question = question.replace(".","")
  question = question.replace(",","")
  question = question.replace("!","")
  question = question.replace("","")
  question = question.replace("+"," ztrgftredrefd ")
  question = question.replace("ztrgftredrefd","+")
  question = question.replace("-"," ztrgftredrefd ")
  question = question.replace("ztrgftredrefd","-")
  question = question.replace("*"," ztrgftredrefd ")
  question = question.replace("ztrgftredrefd","*")
  question = question.replace("/"," ztrgftredrefd ")
  question = question.replace("ztrgftredrefd","/")
  question = question.replace("  "," ")
  question = " " + question + " "

  for unuseful_word in unuseful_words:
    unuseful_word = " " + unuseful_word + " "

    better_question = question.replace(unuseful_word, " ")

    if len(better_question.strip()) > 0:
      question = better_question

  question = question.strip()

  without_nonsense_cache[question2 + ""] = question + ""

  return question


class db_sentence:
    subject = ""
    verb = ""
    object = ""
    prefix = ""
    suffix = ""
    feeling = ""
    category = ""
    priority = 50
    additional = ""
    quesword = ""
    all_without_nonsense = ""
    parts = []
    advs = []
    has_sub = False
    advs = []
    isTrue = True

    def init(self):
        self.sub1 = db_sentence(None)
        self.has1_sub = False
        self.sub1.has_sub = False
        self.sub2 = db_sentence(None)
        self.has2_sub = False
        self.sub2.has_sub = False
        self.sub3 = db_sentence(None)
        self.has3_sub = False
        self.sub3.has_sub = False
        self.sub4 = db_sentence(None)
        self.has4_sub = False
        self.sub4.has_sub = False
        self.sub5 = db_sentence(None)
        self.has5_sub = False
        self.sub5.has_sub = False

    def subs(self):
        s = []
        if self.has1_sub:
            s.append(self.sub1)
        if self.has2_sub:
            s.append(self.sub2)
        if self.has3_sub:
            s.append(self.sub3)
        if self.has4_sub:
            s.append(self.sub4)
        if self.has5_sub:
            s.append(self.sub5)
        return s

    def __init__(self, doNothing = True):
        if doNothing != None:
            self.init()



    def copy_tupel(self, tup):
        self.subject = tup[0].strip()
        self.verb = tup[1].strip()
        self.object = tup[2].strip()
        self.prefix = tup[3].strip()
        self.suffix = tup[4].strip()
        self.feeling = tup[5].strip()
        self.category = tup[6].strip()
        self.priority = tup[7]
        self.additional = tup[8].strip()
        self.quesword = tup[9].strip()
        if tup[10]:
            self.has1_sub = True
            self.sub1 = db_sentence()
            self.sub1.subject = tup[11].strip()
            self.sub1.verb = tup[12].strip()
            self.sub1.object = tup[13].strip()
            self.sub1.prefix = tup[14].strip()
            self.sub1.suffix = tup[15].strip()
            self.sub1.feeling = tup[16].strip()
            self.sub1.category = tup[17].strip()
            self.sub1.priority = tup[18]
            self.sub1.additional = tup[19].strip()
            self.sub1.quesword = tup[20].strip()
        if tup[21]:
            self.has2_sub = True
            self.sub2 = db_sentence()
            self.sub2.subject = tup[22].strip()
            self.sub2.verb = tup[23].strip()
            self.sub2.object = tup[24].strip()
            self.sub2.prefix = tup[25].strip()
            self.sub2.suffix = tup[26].strip()
            self.sub2.feeling = tup[27].strip()
            self.sub2.category = tup[28].strip()
            self.sub2.priority = tup[29]
            self.sub2.additional = tup[30].strip()
            self.sub2.quesword = tup[31].strip()
        if tup[32]:
            self.has3_sub = True
            self.sub3 = db_sentence()
            self.sub3.subject = tup[33].strip()
            self.sub3.verb = tup[34].strip()
            self.sub3.object = tup[35].strip()
            self.sub3.prefix = tup[36].strip()
            self.sub3.suffix = tup[37].strip()
            self.sub3.feeling = tup[38].strip()
            self.sub3.category = tup[39].strip()
            self.sub3.priority = tup[40]
            self.sub3.additional = tup[41].strip()
            self.sub3.quesword = tup[42].strip()
        if tup[43]:
            self.has4_sub = True
            self.sub4 = db_sentence()
            self.sub4.subject = tup[44].strip()
            self.sub4.verb = tup[45].strip()
            self.sub4.object = tup[46].strip()
            self.sub4.prefix = tup[47].strip()
            self.sub4.suffix = tup[48].strip()
            self.sub4.feeling = tup[49].strip()
            self.sub4.category = tup[50].strip()
            self.sub4.priority = tup[51]
            self.sub4.additional = tup[52].strip()
            self.sub4.quesword = tup[53].strip()
        if tup[54]:
            self.has5_sub = True
            self.sub5 = db_sentence()
            self.sub5.subject = tup[55].strip()
            self.sub5.verb = tup[56].strip()
            self.sub5.object = tup[57].strip()
            self.sub5.prefix = tup[58].strip()
            self.sub5.suffix = tup[59].strip()
            self.sub5.feeling = tup[60].strip()
            self.sub5.category = tup[61].strip()
            self.sub5.priority = tup[62]
            self.sub5.additional = tup[63].strip()
            self.sub5.quesword = tup[64].strip()

    def copy(self, src):
        self.subject = "" + src.subject.strip()
        self.verb = "" + str(src.verb).strip()
        self.object = "" + src.object.strip()
        self.prefix = "" + src.prefix.strip()
        self.suffix = "" + src.suffix.strip()
        self.feeling = "" + src.feeling.strip()
        self.category = "" + src.category.strip()
        self.additional = "" + src.additional.strip()
        self.quesword = "" + src.quesword.strip()
        self.priority = src.priority + 0
        self.parts = src.parts + []
        self.advs = src.advs + []
        if src.has1_sub:
            self.has1_sub = True
            self.sub1 = db_sentence()
            self.sub1.copy(src.sub1)
        if src.has2_sub:
            self.has2_sub = True
            self.sub2 = db_sentence()
            self.sub2.copy(src.sub2)
        if src.has3_sub:
            self.has3_sub = True
            self.sub3 = db_sentence()
            self.sub3.copy(src.sub3)
        if src.has4_sub:
            self.has4_sub = True
            self.sub4 = db_sentence()
            self.sub4.copy(src.sub4)
        if src.has5_sub:
            self.has5_sub = True
            self.sub5 = db_sentence()
            self.sub5.copy(src.sub5)
        self.isTrue = src.isTrue

    def strip(self):
        self.subject = self.subject.strip()
        self.verb = str(self.verb).strip()
        self.object = self.object.strip()
        self.prefix = self.prefix.strip()
        self.suffix = self.suffix.strip()
        self.feeling = self.feeling.strip()
        self.category = self.category.strip()
        self.additional = self.additional.strip()
        self.quesword = self.quesword.strip()
        if self.has1_sub:
            self.sub1.strip()
        if self.has2_sub:
            self.sub2.strip()
        if self.has3_sub:
            self.sub3.strip()
        if self.has4_sub:
            self.sub4.strip()
        if self.has5_sub:
            self.sub5.strip()

    def uniq(self):
        return (
                  self.subject + " -----"
                + self.verb + " -----"
                + self.object + " -----"
                + self.prefix + " -----"
                + self.suffix + " -----"
                + self.feeling + " -----"
                + self.category + " -----"
                + self.additional + " -----"
                + self.quesword
               )

    def print_parts(self):
        log('Subject:    ' + self.subject)
        log('Verb:       ' + str(self.verb))
        log('Object:     ' + self.object)
        log('Prefix:     ' + self.prefix)
        log('Suffix:     ' + self.suffix)
        log('Feeling:    ' + self.feeling)
        log('Category:   ' + self.category)
        log('additional:     ' + self.additional)
        log('QuesWord:   ' + self.quesword)
        log('Ohne Muell: ' + self.all_without_nonsense)
        log('Wahr:       ' + str(self.isTrue))
        if self.has1_sub:
            log('Nebensatz:')
            self.sub1.print_parts()
        if self.has2_sub:
            log('Nebensatz:')
            self.sub2.print_parts()
        if self.has3_sub:
            log('Nebensatz:')
            self.sub3.print_parts()
        if self.has4_sub:
            log('Nebensatz:')
            self.sub4.print_parts()
        if self.has5_sub:
            log('Nebensatz:')
            self.sub5.print_parts()

    def gen_sentences(self, withFix):
        self.strip()
        ans = []
        ans.append(' '.join([self.prefix, self.subject, self.verb, self.object, self.suffix]))
        temp = ' '.join([self.prefix, self.subject, self.verb, self.object])
        temp = temp.strip()
        if len(temp) > 1:
            ans.append(temp)
        temp = ' '.join([self.subject, self.verb, self.object, self.suffix])
        temp = temp.strip()
        if len(temp) > 1:
            ans.append(temp)
        ans.append((' '.join([self.prefix, self.subject, self.verb, self.object, self.suffix])).strip())
        return ans

    def to_xml(self, before = ""):
        lines = []
        lines +=     [

            before + "<fact>",
                "  " + before + "<subject>" +
                    self.subject +
                "</subject>",
                "  " + before + "<verb>" +
                    str(self.verb) +
                "</verb>",
                "  " + before + "<object>" +
                    self.object +
                "</object>",
                "  " + before + "<prefix>" +
                    self.prefix +
                "</prefix>",
                "  " + before + "<suffix>" +
                    self.suffix +
                "</suffix>",
                "  " + before + "<feeling>" +
                    self.feeling +
                "</feeling>",
                "  " + before + "<category>" +
                    self.category +
                "</category>",
                "  " + before + "<additional>" +
                    self.additional +
                "</additional>",
                "  " + before + "<quesword>" +
                    self.quesword +
                "</quesword>",
                "  " + before + "<priority>" +
                    str(self.priority) +
                "</priority>",

                    ]

        if self.has1_sub:
            lines.append(before + "<sub>")
            lines += self.sub1.to_xml(before + "  ").split("\n")
            lines.append(before + "</sub>")
        if self.has2_sub:
            lines.append(before + "<sub>")
            lines += self.sub2.to_xml(before + "  ").split("\n")
            lines.append(before + "</sub>")
        if self.has3_sub:
            lines.append(before + "<sub>")
            lines += self.sub3.to_xml(before + "  ").split("\n")
            lines.append(before + "</sub>")
        if self.has4_sub:
            lines.append(before + "<sub>")
            lines += self.sub4.to_xml(before + "  ").split("\n")
            lines.append(before + "</sub>")
        if self.has5_sub:
            lines.append(before + "<sub>")
            lines += self.sub5.to_xml(before + "  ").split("\n")
            lines.append(before + "</sub>")
        lines.append(before + "</fact>")
        return "\n".join(lines)

def save_override_sentence(x):
	fp = open("temp/override_sentence.tmp", "w")
	fp.write(str(x))
	fp.close()

def load_override_sentence():
	try:
		fp = open("temp/override_sentence.tmp")
		a = fp.read().strip()
		fp.close()
		return a
	except IOError:
		save_override_sentence("")
		return ""

def save_do_learn(x):
	fp = open("temp/do_learn.tmp", "w")
	fp.write(str(x))
	fp.close()

def load_do_learn():
	try:
		fp = open("temp/do_learn.tmp")
		a = int(fp.read().strip())
		fp.close()
		return a
	except IOError:
		save_do_learn(1)
		return 1

def save_clear_override_sentence(x):
	fp = open("temp/clear_override_sentence.tmp", "w")
	fp.write(str(x))
	fp.close()

def load_clear_override_sentence():
	try:
		fp = open("temp/clear_override_sentence.tmp")
		a = int(fp.read().strip())
		fp.close()
		return a
	except IOError:
		save_clear_override_sentence(0)
		return 0

def save_do_callback(x):
	fp = open("temp/do_callback.tmp", "w")
	fp.write(str(x))
	fp.close()

def load_do_callback():
	try:
		fp = open("temp/do_callback.tmp")
		a = int(fp.read().strip())
		fp.close()
		return a
	except IOError:
		save_do_callback(0)
		return 0

def get_use_online_db():
    try:
        fp = open("temp/use_online_db.tmp", "r")
        x = int(fp.read().strip())
        fp.close()
        return x
    except IOError:
        return 1
    return 1

def get_online_semantic_net_urls():
    try:
        fp = open("temp/online_semantic_net_urls.txt")
        exec(fp.read())
        fp.close()
    except IOError:
        return  [
                    [ "jeliza.sourceforge.net", "/cgi-bin/online-semnet/query.pl?" ],
                ]
    return online_fact_urls

