#-------------------------------------------------->
# JEliza Module
#
#-> name: firstname
#-> compatible: r59
#-> author: Tobias Schulz
#-> copyright: JEliza Team
#-> date: 01.2008
#-------------------------------------------------->

# librarys to import
import random
from defs import containsWord, save_override_sentence, load_override_sentence, save_clear_override_sentence, load_clear_override_sentence
from utilities import get_first_names, get_not_first_names, add_first_name, add_not_first_name

def interj(question, orig_fra, db, is_positive):
    interjs = [ "Ja", "nein", "doch", "juhu", "juhuu", "huhu", "noe", "no", "yes" ]

    for ij in interjs:
        if containsWord(orig_fra.lower().replace("!", ""), ij.lower()):
            interjs = [ s.capitalize() + "!" for s in interjs ]
            interjs += [ s.capitalize().replace("!", "") + "." for s in interjs ]
            random.shuffle(interjs)
            return interjs[0]

    return ""

funcs_module.append(interj)
