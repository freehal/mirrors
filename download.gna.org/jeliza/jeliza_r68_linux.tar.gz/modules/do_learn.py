#-------------------------------------------------->
# JEliza Module
#
#-> name: do_learn
#-> compatible: r59
#-> author: Tobias Schulz
#-> copyright: JEliza Team
#-> date: 01.2008
#-------------------------------------------------->

# librarys to import
import random
from defs import containsWord, save_override_sentence, load_override_sentence, save_do_learn
from utilities import get_first_names, get_not_first_names, add_first_name, add_not_first_name

def x_do_learn(x = 1, y = 1, z = 1, a = 1, b = 1):
	save_do_learn(1)
	return ""

funcs_module.append(x_do_learn)
