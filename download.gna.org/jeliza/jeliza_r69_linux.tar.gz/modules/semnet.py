# Semantic Network stuff

from defs import get_lang, get_use_online_db, containsWord, contains, db_sentence
from utilities import apply_procent, is_similar_in_array, is_similar
from threading import Thread
from jelizacpp import cpp_to_db_sentence
#from init_semantic import divide

class background_do(Thread):
    def __init__ (self, func, a = None, b = None, c = None, d = None, e = None, f = None):
           Thread.__init__(self)
           self.func = func
           self.a, self.b, self.c, self.d, self.e, self.f = a, b, c, d, e, f
    def run(self):
          self.func(self.a, self.b, self.c, self.d, self.e, self.f)



nouns = {}
verbs = {}
noun_verb = {}


fp = open("lang_" + get_lang() + "/wsh/synonyms_verbs.wsh", "r")
verb_lines = fp.readlines()
fp.close()
synonyms_verbs = {}
for line in verb_lines:
    line = line.strip()
    if len(line) > 0:
        line = line.split(" ")

        for x in line:
            for y in line:
                if x != y:
                    try:
                        synonyms_verbs[x[:]]
                    except KeyError:
                        synonyms_verbs[x[:]] = []
                    try:
                        synonyms_verbs[y[:]]
                    except KeyError:
                        synonyms_verbs[y[:]] = []
                    synonyms_verbs[x[:]].append(y[:])
                    synonyms_verbs[y[:]].append(x[:])

import string
def contains (s1, s2):
    return (string.find(str(s1), str(s2)) > -1)


def acc(arr, u, d = None):
    if u in arr:
        return arr[u]
    if d != None:
        arr[u] = d
        return arr[u]
    return None

def acc_dict(arr, i, d = None):
    u = i.lower()
    if u in arr.keys():
        return arr[u]
    if d != None:
        arr[u] = d
        return arr[u]
    return None

def acc_add(arr, i, toadd = None):
    u = i.lower()
    if toadd != None:
        if u not in arr:
            arr[u] = []
        arr[u] += toadd
    return None

def acc_int(arr, i, d = None):
    if i < len(arr):
        return arr[i]
    return d

def set_acc(arr, i, o):
    arr[str(i).lower()] = o
    return o

def getUniqValues(dic):
    unique = {} # dictionary
    for item in dic:
        unique[item] = 1
    mylist=unique.keys()
    mylist.sort()
    return mylist

already_in_synonyms_verbs = {}

def verb_synonyms(verb):
    verb = str(verb).lower().strip()
    ret = [verb[:]]
    try:
        ret += synonyms_verbs[verb]
    except KeyError:
        ''''''

#    try:
#        already_in_synonyms_verbs[verb]
#
#        return ret
#    except:
#        ''''''

    a = 0

    copy_ret = ret[:] + [verb]
    for v in copy_ret:
        a += 1
#        apply_procent(0.5 * float(a))
        if v.endswith("tzt"):
            q = v.replace("tzt", "")
            ret.append(q + "tze")
            ret.append(q + "tzst")
            ret.append(q + "tzte")
            ret.append(q + "tztst")
            ret.append(q + "tzen")
            ret.append(q + "tzten")
        if v.endswith("sse"):
            q = v.replace("sse", "")
            ret.append(q + "sst")
            ret.append(q + "ssst")
            ret.append(q + "st")
            ret.append(q + "ssen")
        if v.endswith("en"):
            q = v.replace("en", "")
            ret.append(q + "st")
            ret.append(q + "t")
            ret.append(q + "sst")
            ret.append(q + "tst")
            ret.append(q + "e")
            ret.append(q + "est")
            ret.append(q + "ste")
            ret.append(q + "en")
        for tmp in ("te", "t", "e", "st", "n", "sst"):
            if v.endswith(tmp):
                q = "".join((v,"-")).replace("".join((tmp,"-")), "")
                ret.append(q + "test")
                ret.append(q + "ten")
                ret.append(q + "en")
                ret.append(q + "tst")
                ret.append(q + "t")
                ret.append(q + "e")
                ret.append(q + "st")
                ret.append(q + "sst")
                ret.append(q + "tst")
                ret.append(q + "n")
#    apply_procent(2.5)
    if "hat" in ret: ret.append("haben")
    if "haben" in ret: ret.append("hat")
    if "hat" in ret: ret.append("besitzt")
    if "haben" in ret: ret.append("besitzen")
    if "besitzen" in ret: ret.append("haben")
    if "besitzt" in ret: ret.append("hat")
    if "besitzen" in ret: ret.append("besitzt")
    if "besitzt" in ret: ret.append("besitzen")


    ret = getUniqValues(ret)
    ret += [ "".join(["ge", x]) for x in ret ] + [ x.replace("ge", "") for x in ret ]
#    apply_procent(10)

#    already_in_synonyms_verbs[verb] = True
#    synonyms_verbs[verb] = ret

    return ret




anything = "_"

anything_verb_objects = {}
anything_verb_advs = []


import re
enthaelt_pipe = re.compile("|")

subj_verb_obj = {}
obj_verb_subj = {}
subj_verb = []
subj_verb_advs = {}
subj_verb_dbs = []
is_a = {}

"""
def Fact(__agent, relation, ___object, prio = 50, sub = None, advs = []):
    _agent = __agent.split("|")
    a = [ "|".join(_agent) ]
    if enthaelt_pipe.search(__agent):
        a.append(_agent[0])
    for agent in a:
        if not len(agent):
            continue

        b = []
        for __object in ___object:
            _object = __object.split("|")
            b.append("|".join(_object).strip())
            if enthaelt_pipe.search(__object):
                b.append(_object[0].strip())

        fact(agent, relation, b, prio, sub, advs)
"""

from random import randint

list_IS_A = [
             "sein",
             "ist",
             "bin",
             "bist",
             "sind",
             "seid",

             "am",
             "are",
             "is",
             "be",
            ]

# functions to allow outside access to these objects more easily:
def GetIsA(): return list_IS_A[0]

def ohne_artikel(_satz):
    satz = _satz[:]
    satz = satz.split(" ")
    arts = [ "der", "die", "das", "dem", "den", "ein", "eine", "einer", "einen", "eines", "the", "a", "an" ]
    satz = [ s for s in satz if s.lower() not in arts ]
    return " ".join(satz)

def fact(agent, relation, object, prio = 50, sub = None, advs = []):
        advs = [ a for a in advs if len(str(a)) != 0 ]
        if len(advs):
            try:
                subj_verb_advs[agent.lower()]
            except:
                subj_verb_advs[agent.lower()] = []
            subj_verb_advs[agent.lower()].append((agent, relation, advs, prio))

            for o in object:
                try:
                    subj_verb_advs[o.lower()]
                except:
                    subj_verb_advs[o.lower()] = []
                subj_verb_advs[o.lower()].append((agent, relation, advs, prio))
                #subj_verb_advs.append((o, relation, advs, prio))


        if sub:
#            acc_dict(subj_verb_dbs, agent.lower(), {})
#            acc_dict(acc_dict(subj_verb_dbs, agent.lower(), {}), relation, [])
#            acc_add(acc_dict(subj_verb_dbs, agent.lower(), {}), relation, sub)

            for o in object:
                subj_verb_dbs.append((agent.lower(), relation, o.lower(), sub))

        for o in object:
            # stuff into dictionaries, for searching
            key = " ".join((str(relation), str(o), str(agent)))
            try:
                anything_verb_objects[key]
            except:
                anything_verb_objects[key] = []
            anything_verb_objects[key] += (relation, o, agent)

#            print (agent, relation, o, prio)

            try:
                subj_verb_obj[agent.lower()]
            except:
                subj_verb_obj[agent.lower()] = []
            subj_verb_obj[agent.lower()].append((agent, relation, o, prio))
            try:
                subj_verb_obj[o.lower()]
            except:
                subj_verb_obj[o.lower()] = []
            subj_verb_obj[o.lower()].append((agent, relation, o, prio))
            try:
                obj_verb_subj[agent.lower()]
            except:
                obj_verb_subj[agent.lower()] = []
            obj_verb_subj[agent.lower()].append((agent, relation, o, prio))
            try:
                obj_verb_subj[o.lower()]
            except:
                obj_verb_subj[o.lower()] = []
            obj_verb_subj[o.lower()].append((agent, relation, o, prio))


#            subj_verb_obj.append((agent, relation, o, prio))
#            obj_verb_subj.append((o, relation, agent, prio))

            if relation.lower() in list_IS_A:
                try:
                    is_a[ohne_artikel(agent.lower())]
                except:
                    is_a[ohne_artikel(agent.lower())] = []
                try:
                    is_a[ohne_artikel(o.lower())]
                except:
                    is_a[ohne_artikel(o.lower())] = []
                is_a[ohne_artikel(agent.lower())].append(ohne_artikel(o.lower()))
                is_a[ohne_artikel(o.lower())].append(ohne_artikel(agent.lower()))
                try:
                    is_a[agent.lower()]
                except:
                    is_a[agent.lower()] = []
                try:
                    is_a[o.lower()]
                except:
                    is_a[o.lower()] = []
                is_a[agent.lower()].append(o.lower())
                is_a[o.lower()].append(agent.lower())



def Fact_nolinking(__agent, relation, ___object, prio = 50, sub = None, advs = []):
    _agent = __agent.split("|")
    a = [ "|".join(_agent), "|".join([ ohne_artikel(z) for z in _agent ]) ]
    if enthaelt_pipe.search(__agent):
        a.append(_agent[0])
        a.append(ohne_artikel(_agent[0]))
 #   if contains(__agent.lower(), "now") or contains("".join(___object).lower(), "now"):
 #       print "a:", a
    for agent in a:
        if not len(agent):
            continue

        b1 = []
        b2 = []
        b = []
        for __object in ___object:
            _object = __object.split("|")
            if "|".join(_object).strip() not in b1:
                b1.append("|".join(_object).strip())
            if "|".join([ ohne_artikel(z) for z in _object ]).strip() not in b2:
                b2.append("|".join([ ohne_artikel(z) for z in _object ]).strip())
            if enthaelt_pipe.search(__object):
                b.append(_object[0].strip())
                b.append(ohne_artikel(_object[0]).strip())

        b1 = "/".join(b1)
        b2 = "/".join(b2)
#        print "b1:", b1
#        print "b:", b

  #      if contains(__agent.lower(), "now") or contains("".join(___object).lower(), "now"):
  #          print "b:", b
        fact(agent, relation, b + [b1, b2], prio, sub, advs)

def Fact(__agent, relation, ___object, prio = 50, sub = None, advs = []):
    for _agent in __agent.split(" und "):
        for agent_2 in _agent.split(" oder "):
            l1 = [ agent_2 ]
            for agent in l1:
                o = []
                for __object in ___object:
                    oo = []
                    aa = ""
                    if contains(__object, "|"):
                        __object, aa = __object.split("|")
                    for _object in __object.split(" und "):
                        for object in _object.split(" oder "):

                            l2 = [ object + "|" + aa ]
                            oo += l2
                    o.append(oo)

                objs = []
                for obj in o:
                    _objs = []
                    if not len(objs):
                        for oo in obj:
                            _objs.append([oo])
                    for x in objs:
                        for oo in obj:
                            _objs.append(x + [oo])
                    objs += _objs

                for ob in objs:
                    Fact_nolinking(agent, relation, ob, prio, sub, advs)


#    print subj_verb_obj
#    exit(0)


#    fact(__agent, relation, ___object, prio, sub, advs)



# declare global "is-a" relationship.
# other modules MUST properly use this, rather than
# define their own "is-a", since it has special meaning (inheritance).


def get_subj_list(_subj_list):
    subj_list = _subj_list[:]
    for x in range(0, 4):
        tmp = subj_list[:]
        for t in tmp:
            try: subj_list += [ n for n in is_a[ohne_artikel(t)] if not contains(n, " ") and not contains(n, "|") and n.lower() not in ("er", "sie", "es", "ich", "du", "mir", "dir", "mich", "dich") ]
            except KeyError: pass

            if contains(t, "|"):
                u1, u2 = t.split("|")
                if len(t) > 3:
                    if u1.endswith("en"):
                        subj_list.append("".join((u1,"-")).replace("en-", "") + "|" + u2)
                    if u1.endswith("e"):
                        subj_list.append("".join((u1,"-")).replace("e-", "") + "|" + u2)
                    if u1.endswith("n"):
                        subj_list.append("".join((u1,"-")).replace("n-", "") + "|" + u2)
                    if u1.endswith("s"):
                        subj_list.append("".join((u1,"-")).replace("s-", "") + "|" + u2)
                    if u1.endswith("in"):
                        subj_list.append("".join((u1,"-")).replace("in-", "innen") + "|" + u2)
                    if u1.endswith("innen"):
                        subj_list.append("".join((u1,"-")).replace("innen-", "in") + "|" + u2)
                    subj_list.append(u1 + "s" + "|" + u2)
                    subj_list.append(u1 + "en" + "|" + u2)
                    subj_list.append(u1 + "e" + "|" + u2)
            else:
                u1 = t
                if len(t) > 3:
                    if u1.endswith("en"):
                        subj_list.append("".join((u1,"-")).replace("en-", ""))
                    if u1.endswith("e"):
                        subj_list.append("".join((u1,"-")).replace("e-", ""))
                    if u1.endswith("n"):
                        subj_list.append("".join((u1,"-")).replace("n-", ""))
                    if u1.endswith("s"):
                        subj_list.append("".join((u1,"-")).replace("s-", ""))
                    if u1.endswith("in"):
                        subj_list.append("".join((u1,"-")).replace("in-", "innen"))
                    if u1.endswith("innen"):
                        subj_list.append("".join((u1,"-")).replace("innen-", "in"))
                    subj_list.append(u1 + "s")
                    subj_list.append(u1 + "en")
                    subj_list.append(u1 + "e")

        subj_list = getUniqValues(subj_list)
    return subj_list




anything = "_"
nothing = "nothing"
nouns = { "nothing" : nothing, "_" : anything }
verbs = {}
for isa in list_IS_A:
    verbs[str(isa)] = isa


def get_obj_impl(subj_list, verb, first = None, n = 0):
    subj_list = [ x[:].lower() for x in subj_list ]

    ret = []
    verbsynonyms = verb_synonyms(verb)
    print "verb:", verb
    proz = 1

    ##a += 1
    ##apply_procent(100.0 / (5*len(subj_list)) * ((y+1)*a))
#    print "subj_list:", subj_list
    h = []
    z = []
    for s in subj_list:
        try: z += subj_verb_obj[s]
        except KeyError: pass
    for q in z:
        try:
            if "".join(q[0]).lower() in subj_list and "".join(q[1]).lower() in verbsynonyms:
                h.append(q)
        except: pass
#    for hh in h:
#        print h
#            print 1, "h:", h, [ q[2] for q in h if q[1] == verb ]
    ret += [ (w[3], w[2]) for w in h ] #[ q[2] for q in h if q[1] == verb ]


    ret = getUniqValues(ret)
    ret = [ r for r in ret if contains(r[1], "|") ]

    return ret

def get_agen_impl(subj_list, verb, first = None, n = 0):
    subj_list = [ x[:].lower() for x in subj_list ]
    ret = []
    verbsynonyms = verb_synonyms(verb)
#    print "verbsynonyms:", verbsynonyms
    print "verb:", verb
    proz = 1

    ##a += 1
    ##apply_procent(100.0 / (5*len(subj_list)) * ((y+1)*a))
    h = []
    z = []
    for s in subj_list:
        try: z += obj_verb_subj[s]
        except KeyError: pass
    for q in z:
        try:
            if "".join(q[2]).lower() in subj_list and "".join(q[1]).lower() in verbsynonyms:
                h.append(q)
        except: pass
#            print 1, "h:", h, [ q[2] for q in h if q[1] == verb ]
    ret += [ (w[3], w[0]) for w in h ] #[ q[2] for q in h if q[1] == verb ]

    ret = getUniqValues(ret)
    ret = [ r for r in ret if contains(r[1], "|") ]

    return ret

    return ret

def get_advs_impl(subj_list, verb, first = None, n = 0):
    subj_list = [ x[:].lower() for x in subj_list ]
    ret = []
    verbsynonyms = verb_synonyms(verb)
#    print "verb:", verb


    z = []
    h = []
    for s in subj_list:
        try: z += subj_verb_advs[s]
        except KeyError: pass
    for q in z:
        try:
            if "".join(q[0]).lower() in subj_list and "".join(q[1]).lower() in verbsynonyms:
                for qq in q[2]:
                    h.append(qq)
        except: pass
#            print 1, "h:", h, [ q[2] for q in h if q[1] == verb ]
    ret += h #[ (w[3], w[2]) for w in h ] #[ q[2] for q in h if q[1] == verb ]

    ret = getUniqValues(ret)
#    ret = [ r for r in ret if contains(r[1], "|") ]

    return ret

def call(subj_list, verb, obj):
    objs = get_obj_impl(subj_list, verb)

    if get_use_online_db():
        from defs import get_online_semantic_net_urls
        online_fact_urls = get_online_semantic_net_urls()
        for host, ofu in online_fact_urls:
            th = background_do(online_get_objects, host, ofu, ",".join(subj_list), ",".join(verb_synonyms(verb)))
            th.start()

            for x in range(1, 8):
                import time
                time.sleep(0.1)

                fp = open("temp/down_tmp.tmp")
                rrr = [ l.split(";") for l in fp.read().split("\n") if len(l.strip()) > 0 ]
                fp.close()
                objs += rrr
                if len(rrr):
                    break

    objs = [ o for o in objs if len(o) == 2 ]
    objs = [ o[1] for o in objs ]
    objs += [ ohne_artikel(o[1]) for o in objs ]
    for o in objs:
        if enthaelt_pipe.search(o):
            o = o.split("|")[0]
        if is_similar(obj, o):
            return True
    return False


hash_online_get_objects = {}
def online_get_objects(host, ofu, sub, verb, c, d):
    try:
        x = hash_online_get_objects[sub.lower()+verb.lower()]
        fp = open("temp/down_tmp.tmp", "a")
        fp.write(str(x))
        fp.close()
    except KeyError:
        pass

    lines = []
    ofu += "get_objs_full=" + sub.replace(" ", "%20")
    ofu += "&rel=" + verb.replace(" ", "%20")

    print "Online get_objects Process started."

    from httplib import HTTPConnection
    port = 80
    if contains(host, ":"):
        host, port = host.split(":")
    http = HTTPConnection(host, port)
    print "HTTPConnection(" + host + ", " + str(port) + ")"
    http.connect() # agent=ich|&rel=bin&objects=da|&prio=100
    http.putrequest("GET", ofu)
#    print "http://" + host + "/" + ofu
    http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
    try:
        http.endheaders()
    except:
        print "Socket Error while endheaders()"
        pass
    fp = open("temp/down_tmp.tmp", "a")
    x = str(http.getresponse().read().replace("\r", ""))
    fp.write(x)
    hash_online_get_objects[sub.lower()+verb.lower()] = x
    fp.close()

hash_online_get_subjects = {}
def online_get_subjects(host, ofu, sub, verb, c, d):
    try:
        x = hash_online_get_subjects[sub.lower()+verb.lower()]
        fp = open("temp/down_tmp.tmp", "a")
        fp.write(str(x))
        fp.close()
    except KeyError:
        pass

    lines = []
    ofu += "get_subjs=" + sub.replace(" ", "%20")
    ofu += "&rel=" + verb.replace(" ", "%20")

    print "Online get_subjects Process started."

    from httplib import HTTPConnection
    port = 80
    if contains(host, ":"):
        host, port = host.split(":")
    print "HTTPConnection(" + host + ", " + str(port) + ")"
    http = HTTPConnection(host, port)
    http.connect() # agent=ich|&rel=bin&objects=da|&prio=100
    http.putrequest("GET", ofu)
#        print "http://" + host + "/" + ofu
    http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
    try:
        http.endheaders()
    except:
        print "Socket Error while endheaders()"
        pass
    fp = open("temp/down_tmp.tmp", "a")
    x = str(http.getresponse().read().replace("\r", ""))
    fp.write(x)
    hash_online_get_subjects[sub.lower()+verb.lower()] = x
    fp.close()



def getObjects(sub, verb):
    ret = []
    subj_list = get_subj_list([ sub ])

    from init_semantic import divide

    ret += get_obj_impl(subj_list, verb)

    fp = open("temp/down_tmp.tmp", "w")
    fp.close()

    print "ret(1):", ret
    if get_use_online_db() and len(ret) == 0:
        from defs import get_online_semantic_net_urls
        online_fact_urls = get_online_semantic_net_urls()
        for host, ofu in online_fact_urls:
            if len(ofu):
                th = background_do(online_get_objects, host, ofu, ",".join(subj_list), ",".join(verb_synonyms(verb)))
                th.start()
            else:
                th = background_do(online_get_objects, host, ofu, sub, verb)
                th.start()

            for x in range(1, 20):
                import time
                time.sleep(0.1)

                fp = open("temp/down_tmp.tmp")
                rrr = [ l.split(";") for l in fp.read().split("\n") if len(l.strip()) > 0 ]
                rrrr = []
                for r in rrr:
#                    print "r:", r
                    if contains(r[1], "|"): rrrr.append((r[0], r[1]))
                    l2 = r[2]
                    if not len(l2.strip()):
                        continue
                    sent = []
                    sent.append(sub)
                    sent.append(verb)
                    sent.append(r[1])
                    sent2 = [
                        l2.split("-----")[8],
                        l2.split("-----")[0].replace("}", "").replace("{", " "),
                        l2.split("-----")[1],
                        l2.split("-----")[2].replace("}", "").replace("{", " "),
                        l2.split("-----")[7]
                    ]
                    sent = " ".join(sent) + ", " + " ".join(sent2)
#                    print "sent:", sent
                    dbs = db_sentence()
                    dbs.copy_tupel(cpp_to_db_sentence(sent.replace("  ", " ").replace("}", "").replace("{", " ").replace("|", " ")))
                    divide(dbs)
#                    for d in dbs.subs():
#                        d.print_parts()


                    subj_verb_dbs.append((sub.lower(), verb, r[1].lower(), dbs.subs()))



                fp.close()
                ret += rrrr
                if len(rrrr):
                    break

    ret_indirect_and_direct = [ r for r in ret if contains(r, "/") ]
    for prio, r in ret_indirect_and_direct:
        if (prio, r.split("/")[0]) in ret:
            ret.remove((prio, r.split("/")[0]))
        if [prio, r.split("/")[0]] in ret:
            ret.remove([prio, r.split("/")[0]])

    print "ret:", ret
    return ret
def getAgents(sub, verb):
    ret = []
    subj_list = get_subj_list([ sub ])

    ret += get_agen_impl(subj_list, verb)

    if get_use_online_db() and len(ret) == 0:
        from defs import get_online_semantic_net_urls
        online_fact_urls = get_online_semantic_net_urls()
        for host, ofu in online_fact_urls:
            if len(ofu):
                th = background_do(online_get_objects, host, ofu, ",".join(subj_list), ",".join(verb_synonyms(verb)))
                th.start()
            else:
                th = background_do(online_get_objects, host, ofu, sub, verb)
                th.start()

            for x in range(1, 8):
                import time
                time.sleep(0.1)

                fp = open("temp/down_tmp.tmp")
                rrr = [ l.split(";") for l in fp.read().split("\n") if len(l.strip()) > 0 ]
                fp.close()
                ret += rrr
                if len(rrr):
                    break


    return ret
def get_advs(sub, _verb):
    ret = []
    subj_list = get_subj_list([ sub ])
    arr = verb_synonyms(_verb)
    u = 0
    ret += get_advs_impl(subj_list, _verb)
    ret = [ str(rr) for rr in ret ]

    return ret
def is_true_impl(sub, verb, obj, prio = 50):
    arr = [verb]
    u = 0
    subj_list = get_subj_list([ sub ])

    u += 1
    r = call(subj_list, verb, obj)
    if r:
        return r
    return False
def get_list_subs_impl(n):
#    acc_dict(subj_verb_dbs, n.lower(), {})
#    r = acc_dict(subj_verb_dbs, n.lower(), {})
#    print "subj_verb_dbs:", subj_verb_dbs

    try:
        r = subj_verb_dbs

        return r
    except KeyError:
        return []

