#!/usr/bin/perl -w

$| = 1;

use strict;
use warnings;
use CGI;
use CGI::Carp qw(fatalsToBrowser);

our $cgi = new CGI;
print $cgi->header();

exit 0 if !$cgi->param('q');

open I, "<", "lang_de/facts.pro";
my @lines = <I>;
close I;
my $q = $cgi->param('q');
print $q . "\n";
print grep { $_ =~ /$q/i } @lines;
@lines = grep { $_ !~ /$q/i } @lines;
open O, ">", "lang_de/facts.pro";
print O @lines;
close O;

open I, "<", "lang_de/word_types.dic";
my @lines = <I>;
close I;
my $q = $cgi->param('q');
print grep { $_ =~ /$q/i } @lines;
@lines = grep { $_ !~ /$q/i } @lines;
open O, ">", "lang_de/word_types.dic";
print O @lines;
close O;

