#!/usr/bin/perl -w

$| = 1;

use strict;
use warnings;

our $dir = './';
sub LANGUAGE {
	return 'de';
}

sub impl_get_genus {
	my ( $CLIENT_ref, $word ) = @_;

	print "
 Which gender is '" . $word . "'?
 
 1. male
 2. female
 3. neuter
 
 Please enter the number above and press ENTER;
 
 Number:\n";	
	my $num = <STDIN>;
	chomp $num;
	
	return $num;
}

sub impl_get_noun_or_not {
	my ( $CLIENT_ref, $word ) = @_;

	print "
 Is '" . $word . "' meant as a noun here?
 
 1. '" . $word . "' is a noun
 2. '" . $word . "' is not a noun
 
 Please enter the number above and press ENTER;
 
 Number:\n";
	my $num = <STDIN>;
	chomp $num;
	
	return $num;
}

sub impl_get_word_type {
	my ( $CLIENT_ref, $word ) = @_;

					print "
 Which word type is '" . $word . "'?
 
 1. verb
 2. noun oder name
 3. adjective oder adverb
 4. pronoun
 5. question word or conjunction
 6. preposition
 7. interjection
 
 Please enter the number above and press ENTER;
 
 Number:\n";
	my $num = <STDIN>;
	chomp $num;
	
	return $num;
}

require 'jeliza-engine.pl';

no strict;
no warnings;
print << "EOF";
This is JEliza Perl rev. $FULL_VERSION

EOF
use strict;
use warnings;

open my $CLIENT, ">", "to-server.log";
close $CLIENT;

load_word_types();
load_database_file( $dir . "/lang_" . LANGUAGE() . "/facts.pro" );

print "\n";
print "> ";
my $display_str = q{}; # empty

while (my $line = <STDIN>) {
	chomp $line;
	open my $CLIENT, ">>", "to-server.log";

	my $dialog = ask( \$CLIENT, $line, \$display_str );
	$dialog =~ s/[:]+/:/igm;
	$dialog =~ s/[<]br[>]/\n/igm; 
	$dialog =~ s/[<](.*?)[>]//igm;
	$dialog =~ s/\s*$//igm;
	$dialog =~ s/^\s*//igm;
	
	print `clear`;
	
	print $dialog . "\n";

	print "> ";
}
