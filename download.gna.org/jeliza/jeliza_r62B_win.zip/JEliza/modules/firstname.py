#-------------------------------------------------->
# JEliza Module
#
#-> name: firstname
#-> compatible: r59
#-> author: Tobias Schulz
#-> copyright: JEliza Team
#-> date: 01.2008
#-------------------------------------------------->

# librarys to import
import random
from defs import containsWord, save_override_sentence, load_override_sentence, save_clear_override_sentence, load_clear_override_sentence
from utilities import get_first_names, get_not_first_names, add_first_name, add_not_first_name

def save_firstname_listenmode(x):
	fp = open("temp/firstname_listenmode.tmp", "w")
	fp.write(str(x))
	fp.close()

def load_firstname_listenmode():
	try:
		fp = open("temp/firstname_listenmode.tmp")
		a = fp.read().strip()
		fp.close()
		return a
	except IOError:
		save_firstname_listenmode(0)
		return 0

def reset_firstname_listenmode(x = None, y = None, z = None, a = None, b = None):
    save_firstname_listenmode(0)
    save_override_sentence("")

def firstname(question, orig_fra, db, is_positive):
    if len(orig_fra.split(" ")) < 3:
        return ""

    dbs = db_sentence()
    dbs.copy_tupel(cpp_to_db_sentence(question))
    dbs = divide(dbs, False)

    if load_firstname_listenmode() == str(0) and len(dbs.parts) >= 2:
        fn = get_first_names()
        nfn = get_not_first_names()

        if len(dbs.parts[0][0].split(" ")) == 1 and dbs.parts[0][0].lower() not in nfn and dbs.parts[1][0].lower() not in ['nothing'] and dbs.parts[0][0].lower() not in fn:
            save_firstname_listenmode(dbs.parts[0][0] + "," + dbs.parts[1][0])
            save_override_sentence(question + "||||||" + orig_fra)
            save_do_learn(0)
            save_clear_override_sentence(0)
            return "Ist \"" + dbs.parts[0][0] + "\" ein Vorname und ist \"" + dbs.parts[1][0] + "\" der dazugehoerige Nachname?"
    if str(load_firstname_listenmode()) != "0":
        if is_positive == -1:
            add_not_first_name(load_firstname_listenmode().split(",")[0])
            save_clear_override_sentence(1)
            save_firstname_listenmode("0")
        elif is_positive == 1:
            add_first_name(load_firstname_listenmode().split(",")[0])
            save_clear_override_sentence(1)
            save_firstname_listenmode("0")
        else:
            try:
                return "Ist \"" + load_firstname_listenmode().split(",")[0] + "\" ein Vorname und ist \"" + load_firstname_listenmode().split(",")[1] + "\" der dazugehoerige Nachname?"
            except IndexError:
                pass

    return ""

funcs_module.append(firstname)
funcs_init.append(reset_firstname_listenmode)
#funcs_direct_after.append(learn_override_sentence)
