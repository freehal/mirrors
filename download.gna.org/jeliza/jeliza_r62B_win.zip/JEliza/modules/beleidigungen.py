#-------------------------------------------------->
# JEliza Module
#
#-> name: Beleidigungen
#-> compatible: 2.4
#-> author: JEliza Team
#-> copyright: Marcel Kunzmann
#-> date: 08.2007
#-------------------------------------------------->

import random



blacklist1 = [ "dumm", "scheisse", "Arschloch", "schwul", "scheise", "bescheuert", "krank", "bloed", "schwuchtel", "lesbe", "hure", "krank im kopf", "dummes Programm", "wixer", "wixxer", "wichser", "penner", "depp", "idiot", "volltrottel", "spast", "arschloch"]

def beleidigungsmodul(question, orig_fra, db, is_positive):
    found = False

    log("")
    log("Beleidigungsmodul...")

    for word in blacklist1:
        if contains(question.lower(), "ich bin") and contains(question.lower(), word.lower()):
            answeren = []
            answeren.append("Du hast kein Recht, mich mit " + word + " zu beleidigen, du dummer Mensch!")
            answeren.append("Selber " + word + "!")
            answeren.append("Sei mal hoeflich!")
            answeren.append(word + "?? Was soll das denn?")
            answeren.append("Du fuehlst dich jetzt cool, oder?")
            answeren.append("Du mich auch")
            answeren.append("Pfui! Nicht dieses Wort!")
            answeren.append("Nenn mich nicht " + word + "!")

            random.shuffle(answeren)
            answer = answeren[0]

            log("Ich wurde beleidigt mit " + word)

            return str(answer)

            found = True

            break

    if not found:
        log("Ich wurde nicht beleidigt...")
        return ""

funcs_module.append(beleidigungsmodul)


log("")
