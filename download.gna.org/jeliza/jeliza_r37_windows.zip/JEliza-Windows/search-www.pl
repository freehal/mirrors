#!/usr/bin/perl -w

$| = 1;

print "Content-type: text/plain\n\n";
use strict;
use warnings;
use CGI;
use CGI::Carp qw(fatalsToBrowser);

our $cgi = new CGI;
my $key = $cgi->param('q') || <STDIN>;
print $key . "\n";

use WWW::Search;
my $search = WWW::Search->new('Yahoo::DE');
$search->native_query($key);
while (my $result = $search->next_result()) {
    print $result->title, "\n";
    print $result->url, "\n";
    print $result->description, "\n";
    print "\n";
}
