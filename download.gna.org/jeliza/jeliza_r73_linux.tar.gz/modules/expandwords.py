#!/usr/bin/python

zuordnungen = {}
defs = []
deffile = "modules/sentences.jel"
ergebnisfile = "temp/sentences.tmp"

fp = open(ergebnisfile, "w")

def makeDefs():
	lines = file(deffile)

	for line in lines:
		line = line.strip()
		parts = line.split("=")

		if len(parts) == 2:
			parts[0] = parts[0].strip()
			parts[1] = parts[1].strip()

			if zuordnungen.get(parts[0]) == None:
				zuordnungen[parts[0]] = ""
			else:
				zuordnungen[parts[0]] += "##"
			zuordnungen[parts[0]] += parts[1]

#	for z1, z2 in zuordnungen.items():
#		print z1, "=", z2


def expandHelper(words, anz):
	if len(words) == 0:
		fp.write(sent)
		fp.write("\n")
		print sent

	else:
		try:
			zuordnungen[words[anz]]

			for zuo in zuordnungen[words[anz]].split("##"):
				words2 = " ".join(words[:])
#				words2 = words2.replace("'''" + words[anz] + "''' ", "++++++", 1)
				words2 = words2.replace("'''" + words[anz] + "'''", "++++++")
				words2 = words2.replace(words[anz], "###", 1)
				words2 = words2.replace("###", "'''" + words[anz] + "''' " + zuo, 1)
				words2 = words2.replace("++++++", "'''" + words[anz] + "'''")
#				print words2
				words2 = words2.split(" ")

				expandHelper(words2, anz)

		except KeyError:
			anz = anz + 1
			if anz >= len(words):
				fp.write(" ".join(words))
				fp.write("\n")
				print " ".join(words)
			else:
				expandHelper(words[:], anz)


def expandDefs():
#	print "---------"
	expandHelper(["S"], 0)

#	for deff in defs:
#		fp.write(deff + "\n")


makeDefs()
expandDefs()


fp.close()
