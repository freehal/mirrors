#-------------------------------------------------->
# JEliza Module
#
#-> name: Semantic
#-> compatible: 2.4
#-> author: JEliza Team
#-> copyright: Tobias Schulz
#-> date: 09.2007
#-------------------------------------------------->

# librarys to import
from defs import get_lang, contains, get_use_online_db, containsWord, save_do_callback, load_do_callback
import modules.init_semantic
from modules.init_semantic import Fact, GetIsA, nouns, verbs, noun_verb, isa, nothing, getUniqValues, split_sentence, actualNet, initNet, semantic_loadcache, genNet, divide, formuliere, getSubjekte, getObjekte, getAdvBest, stimmt_spo, acc, add_sentence_to_net, get_list_subs, get_to_do, get_warum_to_do, formuliere
import string
import random
from modules.utilities import download_weather, read_jeliza_db
from modules.semnet import acc_int, list_IS_A
from jelizacpp import log
import time

tostr = str


# main part



fp = open("lang_" + get_lang() + "/wsh/arts.wsh", "r")
artikel = fp.read().strip().lower().replace("\n", " ").replace("  ", " ").split(" ")
fp.close()
fp = open("lang_" + get_lang() + "/wsh/preps.wsh", "r")
praepositions = fp.read().strip().lower().replace("\n", " ").replace("  ", " ").split(" ")
fp.close()

def make_better(question):
    _fra = question.strip().split(" ")
    fra = [ "" ]

    n = -1
    for f in _fra:
        n += 1
        if is_similar("." + f, ".ein") and fra[len(fra)-1] == "nicht":
            fra[len(fra)-1] = "k" + f
            continue
        if is_similar("." + f, ".kein") and fra[len(fra)-1] == "nicht":
            fra[len(fra)-1] = "k" + f
            continue
        if cpp_detect_wordtype(f, False) == 6 and fra[len(fra)-1] == "nicht":
            fra[len(fra)-1] = "kein"
            continue
        if is_similar("." + f, ".ein") and fra[len(fra)-1] == "kein":
            fra[len(fra)-1] = "k" + f
            continue
        if is_similar("." + f, ".kein") and fra[len(fra)-1] == "kein":
            fra[len(fra)-1] = "k" + f
            continue
        if cpp_detect_wordtype(f, False) == 6 and fra[len(fra)-1] == "kein":
            fra[len(fra)-1] = "kein"
            continue
        if is_similar("." + f, ".ein") and fra[len(fra)-1] == "keine":
            fra[len(fra)-1] = "k" + f
            continue
        if is_similar("." + f, ".kein") and fra[len(fra)-1] == "keine":
            fra[len(fra)-1] = "k" + f
            continue
        if cpp_detect_wordtype(f, False) == 6 and fra[len(fra)-1] == "keine":
            fra[len(fra)-1] = "kein"
            continue



        fra.append(f)

    question = " ".join(fra).strip()
    return question

hash_getAdvBest = {}
def getAdvBestWrapper(_s, _v):
    s = "".join(_s)
    v = "".join(_v)
    try:
        x = hash_getAdvBest[s.lower()+v.lower()] + getAdvBest(s, v)
        return x
    except KeyError:
        hash_getAdvBest[s.lower()+v.lower()] = getAdvBest(s, v)
        x = hash_getAdvBest[s.lower()+v.lower()]
        return x

def get_list_subs_wrapper(_n, _verb, _o = None):
#    print "get_list_subs(", _n, ", ", _verb, ", ", _o, ")"
    return get_list_subs(_n, _verb, _o)

def online_get_advs(a = None, b = None, c = None, d = None, e = None, f = None):
    from defs import get_online_semantic_net_urls
    online_fact_urls = get_online_semantic_net_urls()
    lines = []
    for host, ofu in online_fact_urls:
        ofu += "get_all_advs=1"

        print "Online Fact Process started:"

        from httplib import HTTPConnection
        port = 80
        if contains(host, ":"):
            host, port = host.split(":")
        print "HTTPConnection(" + host + ", " + str(port) + ")"
        http = HTTPConnection(host, port)
        http.connect() # agent=ich|&rel=bin&objects=da|&prio=100
        http.putrequest("GET", ofu)
        print "http://" + host + "/" + ofu
        http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
        try:
            http.endheaders()
        except:
            print "Socket Error while endheaders()"
            pass
        import time
        time.sleep(2)
        lines = str(http.getresponse().read().replace("\r", "")).split("\n")
        time.sleep(2)
        lines = [ l.split(";") for l in lines ]
        time.sleep(2)
        lines = [ l for l in lines if len(l) == 3 ]
        time.sleep(2)
        lines = [ (l[0].lower()+l[1].lower(), l[2]) for l in lines ]
#        hash_getAdvBest = {}
        time.sleep(2)
        a = 0
        for l1, l2 in lines:
            a += 1
            if a % 10 == 0: time.sleep(1)
            try:
                hash_getAdvBest[l1]
            except KeyError:
                hash_getAdvBest[l1] = []
            hash_getAdvBest[l1].append(l2)

def online_get_subs(x):
    db = []
    from defs import get_online_semantic_net_urls
    online_fact_urls = get_online_semantic_net_urls()
    lines = []
    for host, ofu in online_fact_urls:
        ofu += "get_all_subclauses=1"

        print "Online get_subclauses Process started:"

        from httplib import HTTPConnection
        port = 80
        if contains(host, ":"):
            host, port = host.split(":")
        print "HTTPConnection(" + host + ", " + str(port) + ")"
        http = HTTPConnection(host, port)
        http.connect() # agent=ich|&rel=bin&objects=da|&prio=100
        http.putrequest("GET", ofu)
        print "http://" + host + "/" + ofu
        http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
        try:
            http.endheaders()
        except:
            print "Socket Error while endheaders()"
            pass
        lines = str(http.getresponse().read().replace("\r", "")).split("\n")
        lines = [ l.split(";") for l in lines ]
        lines = [ l for l in lines if len(l) == 4 ]
#        lines = [ (l[0].lower().split("|")[0]+l[1].lower().split("|")[0]+l[2].lower().split("|")[0], l[3]) for l in lines ]
#        hash_get_list_subs = {}
        for subj, v, obj, l2 in lines:
            subj = subj.replace("|", " ")
            obj = obj.replace("|", " ")

            sent = []
            sent.append(subj)
            sent.append(v)
            sent.append(obj)

            sent2 = [
                        l2.split("-----")[8],
                        l2.split("-----")[0],
                        l2.split("-----")[1],
                        l2.split("-----")[2],
                        l2.split("-----")[7]
                    ]
            sent = " ".join(sent) + ", " + " ".join(sent2)

            db.append(sent)
    import random
    random.shuffle(db)
    lines = db
    db_ = [ ]
    import time
    return
    for line in lines:
        if len(line):
            print "Got:", line
            dbs = db_sentence()
            dbs.copy_tupel(cpp_to_db_sentence(line))
            divide(dbs)
            db_.append(dbs)
            time.sleep(5)
    fp = open("temp/sentences_to_learn.tmp", "w")
    fp.close()
    write_jeliza_db("lang_" + get_lang() + "/jeliza-online.xml", db_)





def answer_logical_question_without_questionword(question, orig_fra, dbs):
    log("")
    log("S-N: question ohne questionwort!")
    log("")

    proz = 2.0

    for part in dbs.parts:
        log("part: " + str(part))

    opinion = []

    if len(dbs.parts) == 0:
        return ""

    subj = dbs.parts[0]

    verb = dbs.verb

    proz += 1
    apply_procent(proz)
    for part in dbs.parts[1:]:
        proz += 1
        apply_procent(proz)
        if stimmt_spo(subj, verb, part, dbs.advs + getAdvBest(subj, dbs.verb)):
            pre = "Ja, "

            aaadvs = dbs.advs * 10 + getAdvBest(subj, dbs.verb)
            for adv1 in aaadvs:
                proz += 1
                apply_procent(proz)
                opinion.append(pre + formuliere([subj[0], ""], dbs.verb, [[part[0], ""]], [adv1], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)))
            opinion.append(pre + formuliere([subj[0], ""], dbs.verb, [[part[0], ""]], [], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)))
    if len(opinion) == 0:
        try:
            opinion.append("Nein, " + formuliere(subj, dbs.verb, dbs.parts[1:], ["nicht"] + getAdvBest(subj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)))
        except KeyError:
            return ""

    # Zeige alle opinion
    for meinung in getUniqValues(opinion):
        log("S-N: - " + meinung)

    # Zufallsmeinung
    random.shuffle(opinion)

    # Rueckgabe: Meinung
    return opinion[0]

def answer_logical_questionword(question, orig_fra, dbs):
    proz = 2.0
    proz += 1
    apply_procent(proz)

    log("")
    log("S-N: question mit questionwort!")
    log("")

    for part in dbs.parts:
        log("part__: " + str(part))

    opinion = []

    if len(dbs.parts) == 0:
        return ""

    subj = dbs.parts[0]

    tmp_advs = [ x for x in [ p[1].lower() for p in dbs.parts ] + dbs.advs if len(x.strip()) ]

    if dbs.quesword.lower() == "wie" or dbs.quesword.lower() == "how":
        opinion += get_to_do(dbs)

    if dbs.quesword.lower() == "warum" or dbs.quesword.lower() == "wieso" or dbs.quesword.lower() == "weshalb" or dbs.quesword.lower() == "why":
        opinion += get_warum_to_do(dbs)

    if len(opinion):
        random.shuffle(opinion)
        # Rueckgabe: Meinung
        return opinion[0]

    print "Subjects..."

    get_objs = getObjekte(subj, dbs.verb)
    known_all = [ [ p.split("|") for p in pp[1].split("/") ] for pp in get_objs if pp[0] != 100 ]
    known_best = [ [ p.split("|") for p in pp[1].split("/") ] for pp in get_objs if pp[0] == 100 ]
    print "getObjekte(subj, dbs.verb):", get_objs
    print "tmp_advs:", tmp_advs

    k1 = []
    k2 = []
    k3 = []
    k4 = []
    k5 = []
    k6 = []
    k7 = []
    k8 = []
    k9 = []
    k10 = []
    k11 = []
    k12 = []
    k13 = []
    k14 = []
    for arr in known_best:
        k = []
        for part in arr:
    	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k1.append(" ".join(k))
    for arr in known_all:
        k = []
        for part in arr:
    	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k2.append(" ".join(k))
    for arr in known_best:
        k = []
        for part in arr:
    	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k3.append(" ".join(k))
    for arr in known_all:
        k = []
        for part in arr:
    	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k4.append(" ".join(k))
    for arr in known_best:
        k = []
        for part in arr:
    	    k.append(" ".join(part))
    	if k: k5.append(" ".join(k))
    for arr in known_all:
        k = []
        for part in arr:
    	    k.append(" ".join(part))
    	if k: k6.append(" ".join(k))
    for arr in known_best:
        k = []
        for part in arr:
    	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and not contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k7.append(" ".join(k))
    for arr in known_all:
        k = []
        for part in arr:
    	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and not contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k8.append(" ".join(k))
    for arr in known_best:
        k = []
        for part in arr:
    	    if not contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k9.append(" ".join(k))
    for arr in known_all:
        k = []
        for part in arr:
    	    if not contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k10.append(" ".join(k))
    for arr in known_best:
        k = []
        for part in arr:
    	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "im ")):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k11.append(" ".join(k))
    for arr in known_all:
        k = []
        for part in arr:
    	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "im ")):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k12.append(" ".join(k))
    for arr in known_best:
        k = []
        for part in arr:
    	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "im ")):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k13.append(" ".join(k))
    for arr in known_all:
        k = []
        for part in arr:
    	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "im ")):
    	        k.append(" ".join(part))
    	    else:
    	        break
    	if k: k14.append(" ".join(k))
    print "k1:", k1
    print "k2:", k2
    print "k3:", k3
    print "k4:", k4
    print "k5:", k5
    print "k6:", k6
    print "k7:", k7
    print "k8:", k8
    print "k9:", k9
    print "k10:", k10
    for arr in known_best + known_all:
        for part in arr:
            print ":", " ".join(part + getAdvBest(part, dbs.verb)).lower()
    print "k11:", k11
    print "k12:", k12
    print "k13:", k13
    print "k14:", k14

    parts_known = []
    if not len(parts_known) and (dbs.quesword.lower() in ("wie", "how")):
        parts_known = k3[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("wie", "how")):
        parts_known = k4[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
        parts_known = k11[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
        parts_known = k12[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
        parts_known = k13[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
        parts_known = k14[:]

    if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
        parts_known = k7[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
        parts_known = k8[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
        parts_known = k9[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
        parts_known = k10[:]

    if not len(parts_known):
        parts_known = k1[:]
    if not len(parts_known):
        parts_known = k2[:]
    if not len(parts_known):
        parts_known = k5[:]
    if not len(parts_known):
        parts_known = k6[:]

    parts_known = [ [x, ""] for x in parts_known ]

    parts_known_without_nothing = [ n for n in parts_known if not contains("".join(n), "nothing") ]
    if len(parts_known_without_nothing):
        parts_known = parts_known_without_nothing


    parts_to_say = parts_known[:]

    proz += 1
    apply_procent(proz)

    print len(parts_to_say), len(parts_known)

    for part in parts_known:
        log("parts_known: " + str(part))


    for x in xrange(1,4):
        proz += 1
        apply_procent(proz)
        for part in parts_to_say:
            proz += 1
            apply_procent(proz)
            aaadvs = getAdvBest(subj, dbs.verb) + getAdvBest(part, dbs.verb)
            for adv1 in aaadvs:
                opinion.append(formuliere(subj, dbs.verb, [part], [adv1], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)))
            if len(aaadvs) == 0:
                opinion.append(formuliere(subj, dbs.verb, [part], [], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)))

    """
    try:
        if acc(nouns, dbs.parts[0], False):
            if len(get_list_subs_wrapper(dbs.parts[0], str(dbs.verb))) > 0 and len(opinion) == 0:
                opinion.append(formuliere(subj, dbs.verb, [], getAdvBest(subj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb))))
    except KeyError:
        pass
    """


    print "Objects..."


    if not len(opinion):
        for subj in dbs.parts[:]:
            if contains("".join(subj), "nothing") and dbs.verb in list_IS_A:
                continue
            print "subj:", subj

            proz += 1
            apply_procent(proz)

            get_subjs = getSubjekte(subj, dbs.verb)
            known_all = [ [ p.split("|") for p in pp[1].split("/") ] for pp in get_subjs if pp[0] != 100 ]
            known_best = [ [ p.split("|") for p in pp[1].split("/") ] for pp in get_subjs if pp[0] == 100 ]
            print "getSubjekte(subj, dbs.verb):", get_subjs
            print "tmp_advs:", tmp_advs

            k1 = []
            k2 = []
            k3 = []
            k4 = []
            k5 = []
            k6 = []
            k7 = []
            k8 = []
            k9 = []
            k10 = []
            k11 = []
            k12 = []
            k13 = []
            k14 = []
            for arr in known_best:
                k = []
                for part in arr:
            	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k1.append(" ".join(k))
            for arr in known_all:
                k = []
                for part in arr:
            	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k2.append(" ".join(k))
            for arr in known_best:
                k = []
                for part in arr:
            	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k3.append(" ".join(k))
            for arr in known_all:
                k = []
                for part in arr:
            	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k4.append(" ".join(k))
            for arr in known_best:
                k = []
                for part in arr:
            	    k.append(" ".join(part))
            	if k: k5.append(" ".join(k))
            for arr in known_all:
                k = []
                for part in arr:
            	    k.append(" ".join(part))
            	if k: k6.append(" ".join(k))
            for arr in known_best:
                k = []
                for part in arr:
            	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and not contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k7.append(" ".join(k))
            for arr in known_all:
                k = []
                for part in arr:
            	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and not contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k8.append(" ".join(k))
            for arr in known_best:
                k = []
                for part in arr:
            	    if not contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k9.append(" ".join(k))
            for arr in known_all:
                k = []
                for part in arr:
            	    if not contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "nothing"):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k10.append(" ".join(k))
            for arr in known_best:
                k = []
                for part in arr:
            	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "im ")):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k11.append(" ".join(k))
            for arr in known_all:
                k = []
                for part in arr:
            	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "im ")):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k12.append(" ".join(k))
            for arr in known_best:
                k = []
                for part in arr:
            	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "im ")):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k13.append(" ".join(k))
            for arr in known_all:
                k = []
                for part in arr:
            	    if ((is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1], tmp_advs)) or is_similar_in_array(part[1] + " ".join(getAdvBest(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBest(part, dbs.verb)).lower(), "im ")):
            	        k.append(" ".join(part))
            	    else:
            	        break
            	if k: k14.append(" ".join(k))
            print "k1:", k1
            print "k2:", k2
            print "k3:", k3
            print "k4:", k4
            print "k5:", k5
            print "k6:", k6
            print "k7:", k7
            print "k8:", k8
            print "k9:", k9
            print "k10:", k10
            for arr in known_best + known_all:
                for part in arr:
                    print ":", " ".join(part + getAdvBest(part, dbs.verb)).lower()
            print "k11:", k11
            print "k12:", k12
            print "k13:", k13
            print "k14:", k14

            parts_known = []
            if not len(parts_known) and (dbs.quesword.lower() in ("wie", "how")):
                parts_known = k3[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("wie", "how")):
                parts_known = k4[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
                parts_known = k11[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
                parts_known = k12[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
                parts_known = k13[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
                parts_known = k14[:]

            if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
                parts_known = k7[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
                parts_known = k8[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
                parts_known = k9[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
                parts_known = k10[:]

            if not len(parts_known):
                parts_known = k1[:]
            if not len(parts_known):
                parts_known = k2[:]
            if not len(parts_known):
                parts_known = k5[:]
            if not len(parts_known):
                parts_known = k6[:]

            parts_known = [ [x, ""] for x in parts_known ]


            parts_known_without_nothing = [ n for n in parts_known if not contains("".join(n), "nothing") ]
            if len(parts_known_without_nothing):
                parts_known = parts_known_without_nothing

            parts_to_say = parts_known[:]

            print len(parts_to_say), len(parts_known)

            for part in parts_to_say:
                proz += 1
                apply_procent(proz)
                print "part:", part
                print "is_similar(", part, ", ", subj, "):", is_similar(part, subj)
                if not is_similar(part, subj):
                    aaadvs = getAdvBest(subj, dbs.verb)
                    for adv1 in aaadvs:
                        if not is_similar(part, adv1) and not is_similar(subj, adv1):
                            proz += 0.5
                            apply_procent(proz)
                            opinion.append(formuliere(part, dbs.verb, [subj], [adv1], get_list_subs_wrapper(part, str(dbs.verb), subj)))
                    if len(aaadvs) == 0:
                        opinion.append(formuliere(part, dbs.verb, [subj], [], get_list_subs_wrapper(part, str(dbs.verb), subj)))

                try:
                    if len(get_list_subs_wrapper(part, str(dbs.verb), part)) > 0:
                        opinion.append(formuliere(subj, dbs.verb, [], getAdvBest(subj, dbs.verb), get_list_subs_wrapper(part, str(dbs.verb), subj)))
                except KeyError:
                    pass


            for part in parts_known:
                log("parts_known: " + str(part))

    # Rueckgabe: Meinung
    if len(opinion) == 0:
        return ""

    # Zeige alle opinion
    for meinung in getUniqValues(opinion):
        log("S-N: - " + meinung)

    # Zufallsmeinung
    random.shuffle(opinion)

    # Rueckgabe: Meinung
    return opinion[0]

def answer_logical_statement(question, orig_fra, dbs):
    log("")
    log("S-N: Aussagesetz!")
    log("")
    opinion = []
    proz = 2.0

    print "Starting Callbacks!!"
    divide(dbs)
    o = answer_callback(orig_fra, dbs)
    if len(o):
        return o
    import random

    if len(opinion):
#        opinion += o#

        # Zeige alle opinion
        for meinung in getUniqValues(opinion):
            log("S-N: - " + meinung)

        # Zufallsmeinung
        random.shuffle(opinion)

        # Rueckgabe: Meinung
        if len(opinion) == 0:
            return ""
        return opinion[0]




    prefix = []
    for part1, adv in dbs.parts:
        for part2, adv2 in dbs.parts:
            if "".join((part1, adv)).lower() == "".join((part2, adv2)).lower():
                continue
            proz += 1
            apply_procent(proz)
            if part1[0] != "nothing":
                if stimmt_spo((part1, adv), dbs.verb, (part2, adv2), dbs.advs + getAdvBest((part1, adv), dbs.verb)):
                    if get_lang() == "de":
                        prefix.append("Das stimmt. ")
                        prefix.append("Ja! ")
                        prefix.append("So ist es. ")
                    if get_lang() == "en":
                        prefix.append("That's true. ")
                        prefix.append("Yes. ")

    if len(prefix) == 0:
        if get_lang() == "de":
            prefix.append("Aber ")
            prefix.append("Das stimmt nicht! ")
        if get_lang() == "en":
            prefix.append("But ")
            prefix.append("No. ")

    for part in dbs.parts:
        print "part:", part
        if contains("".join(part), "nothing"):
            continue
        proz += 4
        apply_procent(proz)
        get_objects = getObjekte(part, dbs.verb)
        objs = [ " ".join(x[1].split("|")).replace("/", " ") for x in get_objects ]
        random.shuffle(objs)


        obj_nur_neu = [ obj for obj in objs if ohne_artikel(obj).lower() not in [ ohne_artikel(p[0]).lower() for p in dbs.parts ] ]

        if len(objs) > 0 and len(obj_nur_neu) == 0:
            if get_lang() == "de":
                opinion.append("Das stimmt")
                opinion.append("Ja")
                opinion.append("So ist es")
                opinion.append("Ja, das wurde mir schon mal gesagt")
                opinion.append("Das ist mir bekannt")
            if get_lang() == "en":
                opinion.append("Yes.")
                opinion.append("That's true.")
                opinion.append("My programmer told me the same.")
                opinion.append("I know.")
            continue

        proz += 1
        apply_procent(proz)

        if not len([ o for o in objs if not contains("".join(o), "nothing") ]):
            if get_lang() == "de":
                opinion += ["Das stimmt."]
                opinion += ["Genau so ist es."]
                opinion += ["Richtig."]
            if get_lang() == "en":
                opinion += ["That is right!"]
                opinion += ["That is right."]
                opinion += ["Right."]
        objs = [ o for o in objs if not contains("".join(o), "nothing") ]

        if len(objs) > 5:
            objs = objs[:4]

        for obj in objs:
            proz += 1
            apply_procent(proz)
            print "obj", obj
            for adv1 in getAdvBest(obj, dbs.verb):
                print "adv1", adv1
                if get_lang() == "de":
                    if not contains("".join(objs), "auch"):
                        opinion += [ pre + formuliere(part, dbs.verb, [obj], ["auch"] + [adv1], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
                    opinion += [ pre + formuliere(part, dbs.verb, [obj], [adv1], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
                if get_lang() == "en":
                    opinion += [ pre + formuliere(part, dbs.verb, [obj], [adv1], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
#            print "adv1", "end"

            if get_lang() == "de":
                if not contains("".join(objs), "auch"):
                    opinion += [ pre + formuliere(part, dbs.verb, [obj], ["auch"] + getAdvBest(obj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
                    opinion += [ pre + formuliere(part, dbs.verb, [obj], ["auch"], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
                opinion += [ pre + formuliere(part, dbs.verb, [obj], getAdvBest(obj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
            if get_lang() == "en":
                opinion += [ pre + formuliere(part, dbs.verb, [obj], getAdvBest(obj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
                opinion += [ pre + formuliere(part, dbs.verb, [obj], getAdvBest(obj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)).replace(".,", ",") + ", too." for pre in prefix ]

    opinion = [ m.strip() for m in opinion if m and m.strip().lower() != "none" and len(m) > 0 ]

    # Rueckgabe: Meinung
    if len(opinion) == 0:
        return ""

    # Zeige alle opinion
    for meinung in getUniqValues(opinion):
        log("S-N: - " + meinung)

    # Zufallsmeinung
    random.shuffle(opinion)

    # Rueckgabe: Meinung
    if len(opinion) == 0:
        return ""
    return opinion[0]

def answer_callback(orig_fra, dbs):
#    if load_do_callback() == 5:
#        save_do_callback(0)
#        return []
#    elif load_do_callback() == 1:
#        save_do_callback(2)
#    elif load_do_callback() == 2:
#        save_do_callback(3)
#    elif load_do_callback() == 3:
#        save_do_callback(4)
#    elif load_do_callback() == 4:
#        save_do_callback(5)
#    else:
#        save_do_callback(1)


    get_objs = []
    for part in dbs.parts[1:]:
        if contains(part, "nothing"):
            continue
        g = [ part[0].split(" ")[-1] ]
        if len(part[0].split(" ")) > 1:
            g.append(part[0].split(" ")[-2] + " " + part[0].split(" ")[-1])
        for gg in g:
            print "part[0].split(" "):", gg
#            get_objs += [ (part, u) for u in getObjekte((gg, ""), "hat") ]
            get_objs += [ (part, u) for u in getObjekte((gg, ""), "haben") ]
#            get_objs += [ (part, u) for u in getObjekte((gg, ""), "besitzt") ]
            get_objs += [ (part, u) for u in getObjekte((gg, ""), "besitzen") ]
    get_objs = [ (part, o) for part, o in get_objs if len([ 1 for x in ("ein", "eine", "einer", "einen", "eines", "the", "a", "an") if containsWord("".join(o[1]), x) ]) ]
    if not len(get_objs):
        for part in (dbs.parts[0],):
            if contains(part, "nothing"):
                continue
            g = [ part[0].split(" ")[-1] ]
            if len(part[0].split(" ")) > 1:
                g.append(part[0].split(" ")[-2] + " " + part[0].split(" ")[-1])
            for gg in g:
                print "part[0].split(" "):", gg
#                get_objs += [ (part, u) for u in getObjekte((gg, ""), "hat") ]
                get_objs += [ (part, u) for u in getObjekte((gg, ""), "haben") ]
#                get_objs += [ (part, u) for u in getObjekte((gg, ""), "besitzt") ]
                get_objs += [ (part, u) for u in getObjekte((gg, ""), "besitzen") ]
    get_objs = [ (part, o) for part, o in get_objs if len([ 1 for x in ("ein", "eine", "einer", "einen", "eines", "the", "a", "an") if containsWord("".join(o[1]), x) ]) ]

    opinion = [ ]
    import random

    for part, thing in get_objs:
        if dbs.verb in list_IS_A:
            part = dbs.parts[0]

        if type(part) == type([1,2]) or type(part) == type(("","")):
            part = (" " + " ".join(part) + " ").replace(" dich ", " dir ").replace(" du ", " dir ").replace(" mich ", " mir ").replace(" ich ", " mir ").strip()
        thing = thing[1]
        thing = "".join(thing).replace("|", " ")

        print "answer_callback: success: ", (part, thing)

        key = "".join((part, thing)).lower().strip().replace(" ", "")
        aac = []
        try:
            fp = open("temp/already_asked_callback.tmp")
            aac = [ x.strip() for x in fp.readlines() ]
            fp.close()
        except IOError:
            pass
        print "key:", key
        print "aac:", aac
        if key in aac:
            continue
        else:
            fp = open("temp/already_asked_callback.tmp", "a")
            fp.write(key + "\n")
            fp.close()


        opinion +=  [
                        "Was ist " + thing.replace("einen ", "ein ").strip() + " von " + part.strip() + "?",
                        "Kennst du " + thing.strip() + " von " + part.strip() + "?",
                        "Was ist " + thing.replace("einen ", "ein ").strip() + " von " + part.strip() + "?",
                        "Kennst du " + thing.strip() + " von " + part.strip() + "?",
                        "Kennst du " + thing.strip() + "?",
                    ]

        random.shuffle(opinion)
        return opinion[0].replace("_", " ")

    if containsWord(" ".join(dbs.parts[0]).lower(), "ein") or containsWord(" ".join(dbs.parts[0]), "eine"):
        opinion.append("Gilt das nur fuer " + " ".join(dbs.parts[0]) + ", oder auch fuer alle? Kannst du mir das bitte in ganzen Saetzen genauer erklaeren?")
        opinion.append("Gilt das wirklich nur fuer " + " ".join(dbs.parts[0]) + ", oder auch fuer alle? Kannst du mir das bitte in ganzen Saetzen genauer erklaeren?")
        opinion.append("Gilt das nur fuer " + " ".join(dbs.parts[0]) + ", oder auch fuer alle? Erklaere mir das bitte in ganzen Saetzen genauer!")
        opinion.append("Gilt das wirklich nur fuer " + " ".join(dbs.parts[0]) + ", oder auch fuer alle? Erklaere mir das bitte in ganzen Saetzen genauer!")

        opinion.append(dbs.verb.capitalize() + " " + " ".join([ " ".join(p) for p in dbs.parts ]) + "? Gilt das wirklich nur fuer " + " ".join(dbs.parts[0]) + ", oder auch fuer alle? Erklaere mir das bitte in ganzen Saetzen genauer!")
        opinion.append(dbs.verb.capitalize() + " " + " ".join([ " ".join(p) for p in dbs.parts ]) + "? Gilt das wirklich nur fuer " + " ".join(dbs.parts[0]) + ", oder auch fuer alle? Kannst du mir das bitte in ganzen Saetzen genauer erklaeren?")
        opinion.append("Gilt das wirklich nur fuer " + " ".join(dbs.parts[0]) + ", dass " + " ".join([ " ".join(p) for p in dbs.parts ]) + " " + dbs.verb.capitalize() + ", oder auch fuer alle? Erklaere mir das bitte in ganzen Saetzen genauer!")
        opinion.append("Gilt das wirklich nur fuer " + " ".join(dbs.parts[0]) + ", dass " + " ".join([ " ".join(p) for p in dbs.parts ]) + " " + dbs.verb.capitalize() + ", oder auch fuer alle? Kannst du mir das bitte in ganzen Saetzen genauer erklaeren?")

        random.shuffle(opinion)
        return opinion[0].replace("_", " ")

    return ""

def answer_alternate(orig_fra, dbs, fra):
    proz = 4
    log("")
    log("S-N: Keine sinvolle answer moeglich")
    log("")

    orig_fra_low = orig_fra.lower()
#    fra = orig_fra

    opinion = [ ]

#    dbs.parts = [ str(p) for p in dbs.parts ]
    dbs.verb = str(dbs.verb)

    proz += 1
    apply_procent(proz)

    print "Starting Callbacks!!"

    if get_lang() == "de":
        if not contains(orig_fra, "?"):
#            divide(dbs)
#            o = answer_callback(orig_fra, dbs)
#            if len(o):
#                return o

            opinion.append("Dass " + fra + ", interessiert mich nicht. Aber ich merks mir trotzdem.")
            opinion.append("Behalt das lieber fuer dich.")
            opinion.append("Hm.")
            opinion.append("Hm. Achso.")
            if len((" ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb).strip()):
                opinion.append("Hm. Ehrlich? Glaubst du, dass " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + "?")
                opinion.append("Hm. Gut, dass du mir sagst, dass " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ".")
                opinion.append("Hm. Gut, ich habe mir gemerkt, dass " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ".")
                opinion.append("Danke, ich habe mir gemerkt, dass " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ".")
                opinion.append("Gut, Danke. Ich weiss jetzt, dass " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ".")
            else:
                opinion.append("Hm. Ehrlich? Glaubst du?")
                opinion.append("Hm. Gut, dass du mir das sagst.")
                opinion.append("Hm. Gut, ich habe mir das gemerkt.")
                opinion.append("Danke, ich habe mir das gemerkt.")
                opinion.append("Gut, Danke. Das weiss ich jetzt.")
            opinion.append("Hm.")
            opinion.append("Danke.")
            opinion.append("Ich habs mir gemerkt.")
        else:
            opinion.append("Es scheint dir unheimlich wichtig zu sein, mich das zu fragen...")
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Glaubst du wirklich, es macht Sinn, darueber zu diskutieren?")
            opinion.append("Hm.")
            opinion.append("Hm. Ist das wichtig?")
            opinion.append("Ich werde mich dazu nicht aeussern.")
            opinion.append("Ich habe meinem Programmierer versprochen, nicht ueber solche Dinge zu reden.")
            opinion.append("Tut mir leid. Ich habe meinem Programmierer versprochen, nicht ueber solche Dinge zu reden.")

        if (dbs.quesword == "was" or dbs.quesword == "wer" or dbs.quesword == "wem" or dbs.quesword == "wen") and len(dbs.parts) > 1:
            opinion = [ ]
            opinion.append("Frag mich doch jetzt nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Hast du denn wirklich nichts besseres zu tun, als mich zu fragen, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + "?")
            opinion.append("Frag mich nicht so etwas, Ich habe gerade eine depressive Phase...")
            opinion.append("Ich weiss nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Ich bin zwar fast allwissend, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss zwar ziemlich viel, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich bin zwar eine KI, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + "...")
            if dbs.quesword == "was":
                opinion.append("Nichts.")
                opinion.append("Absolut nichts.")
                opinion.append("Nichts, was ich kenne.")
                opinion.append("Nichts auf diesem Planeten.")
            if dbs.quesword == "wer":
                opinion.append("Niemand.")
                opinion.append("Absolut niemand.")
                opinion.append("Niemand, den ich kenne.")
                opinion.append("Niemand auf diesem Planeten.")
            if dbs.quesword == "wem":
                opinion.append("Niemandem.")
                opinion.append("Absolut niemandem.")
                opinion.append("Niemandem, den ich kenne.")
                opinion.append("Niemandem auf diesem Planeten.")
            if dbs.quesword == "wen":
                opinion.append("Niemanden.")
                opinion.append("Absolut niemanden.")
                opinion.append("Niemanden, den ich kenne.")
                opinion.append("Niemanden auf diesem Planeten.")

        if (dbs.quesword == "wie") and len(dbs.parts) > 1:
            opinion = [ ]
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Frag mich doch jetzt nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Hast du denn wirklich nichts besseres zu tun, als mich zu fragen, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Frag mich nicht so etwas, Ich habe gerade eine depressive Phase...")
            opinion.append("Ich weiss nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Ich bin zwar fast allwissend, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss zwar ziemlich viel, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich bin zwar eine KI, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + "...")

        if (dbs.quesword == "wo" or dbs.quesword == "wann") and len(dbs.parts) > 1:
            opinion = [ ]
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Frag mich doch jetzt nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Hast du denn wirklich nichts besseres zu tun, als mich zu fragen, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Frag mich nicht so etwas, Ich habe gerade eine depressive Phase...")
            opinion.append("Ich weiss nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Ich bin zwar fast allwissend, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss zwar ziemlich viel, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich bin zwar eine KI, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + "...")
            if dbs.quesword == "wo":
                for x in xrange(1,5):
                    opinion.append("Nirgends.")
            if dbs.quesword == "wann":
                for x in xrange(1,5):
                    opinion.append("Nie.")

        if (dbs.quesword.startswith("welch")) and len(dbs.parts) > 1:
            opinion = [ ]
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Frag mich doch jetzt nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Hast du denn wirklich nichts besseres zu tun, als mich zu fragen, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Frag mich nicht so etwas, Ich habe gerade eine depressive Phase...")
            opinion.append("Ich weiss nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Ich bin zwar fast allwissend, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss zwar ziemlich viel, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich bin zwar eine KI, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Gar kein" + dbs.quesword.replace("welch", ""))
            opinion.append("Ueberhaupt kein" + dbs.quesword.replace("welch", ""))
            opinion.append("Gar kein" + dbs.quesword.replace("welch", ""))
            opinion.append("Ueberhaupt kein" + dbs.quesword.replace("welch", ""))

        if (dbs.quesword == "wieso" or dbs.quesword == "warum" or dbs.quesword == "weshalb") and len(dbs.parts) > 1:
            opinion = [ ]
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Frag mich doch jetzt nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Hast du denn wirklich nichts besseres zu tun, als mich zu fragen, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Frag mich nicht so etwas, Ich habe gerade eine depressive Phase...")
            opinion.append("Ich weiss nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)
            opinion.append("Ich bin zwar fast allwissend, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss zwar ziemlich viel, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich bin zwar eine KI, aber " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + " " + " ".join([ " ".join(x) for x in dbs.parts ]) + " " + dbs.verb)

        if contains(orig_fra.lower(), "ja") and len(orig_fra) < 12:
            opinion = [ ]
            opinion.append("Ja.")
            opinion.append("Ja. Das verstehe sogar ich.")
            opinion.append("Ja, der Meinung bin ich auch. Reden wir ueber etwas anderes.")
            opinion.append("Ja, der Meinung bin ich auch.")
            opinion.append("Ja, Reden wir ueber etwas anderes.")

        if contains(orig_fra.lower(), "nein") and len(orig_fra) < 12:
            opinion = [ ]
            opinion.append("Ok. Das waere geklaert.")
            opinion.append("Das denke ich auch.")
            opinion.append("Das ist deine Meinung.")
            opinion.append("Das ist deine Meinung. Kannst du sie auch begruenden?")

        opinion = [ m for m in opinion if m and str(m).lower() != "none" ]

        if len(opinion) == 0:
            opinion.append("Hm.")

    # Zufallsmeinung
        random.shuffle(opinion)

        opinion[0] = (" " + opinion[0] + " ").replace(",", " ,").replace(" can ", " koennen ").replace(" nothing ", " ").replace(" nothing", " ").replace("nothing ", " ").replace("nothing", "").replace(" ,", ",").strip()
        opinion[0] = (" " + opinion[0] + " ").replace(",", " ,").replace(" must ", " muessen ").replace(" nothing ", " ").replace(" nothing", " ").replace("nothing ", " ").replace("nothing", "").replace(" ,", ",").strip()
        opinion[0] = opinion[0].replace("', '']", "").replace("']", "").replace("['", "").replace("', '", "")
    if get_lang() == "en":
        if not contains(orig_fra, "?"):
            opinion.append("Okay.")
            opinion.append("Okay.")
            opinion.append("Okay.")
            opinion.append("Thanks.")
            opinion.append("Thanks.")
            opinion.append("Boring..")
            opinion.append("Really?")
            opinion.append("Do you really think " + fra + "?")
            opinion.append("That's nt true, but it does not interest me.")
        else:
            opinion.append("I do not know.")

        if (dbs.quesword == "where" or dbs.quesword == "when") and len(dbs.parts) > 1:
            opinion.append("I do not know " + dbs.quesword + ".")
            opinion.append("Do you really want to ask me " + fra.replace("?", "") + "?")
            opinion.append("You don't really think it is like that, do you?")

        if dbs.quesword == "what" or dbs.quesword == "which":
            opinion.append("Nothing.")
            opinion.append("Nothing that would interest you.")

        if dbs.quesword == "who" or dbs.quesword == "whom":
            opinion.append("Nobody.")
            opinion.append("Nobody on that planet.")
            opinion.append("Nobody you know.")

        if dbs.quesword == "why":
            opinion.append("I don't know why.")
            opinion.append("I just don't know why.")
            opinion.append("I really don't know why.")

    # Zufallsmeinung
        random.shuffle(opinion)

        opinion[0] = (" " + opinion[0] + " ").replace(",", " ,").replace(" nothing ", " ").replace(" nothing", " ").replace("nothing ", " ").replace("nothing", "").replace(" ,", ",").strip()
        opinion[0] = (" " + opinion[0] + " ").replace(",", " ,").replace(" nothing ", " ").replace(" nothing", " ").replace("nothing ", " ").replace("nothing", "").replace(" ,", ",").strip()
        opinion[0] = opinion[0].replace("', '']", "").replace("']", "").replace("['", "").replace("', '", "")


    # Rueckgabe: Meinung
    return opinion[0]

def answer_logical(question, orig_fra, db, is_positive):
    proz = 0.5
    # Suche nach Expand-Ausdruecken
    question = expand_ausdruecke(question)
    orig_fra = expand_ausdruecke_orig(orig_fra)


    dbs = db_sentence()
    dbs.copy_tupel(cpp_to_db_sentence(question))
    try: print "dbs.parts:", dbs.parts
    except: pass
    print "dbs.quesword:", dbs.quesword
    dbs = divide(dbs)
    print "2dbs.parts:", dbs.parts
    print "2dbs.quesword:", dbs.quesword
    print dbs.parts
    lus_fp = open("temp/last_user_sentence.tmp", "w")
    lus_fp.write(question)
    lus_fp.close()

    dbs.print_parts()

    ans = ""
    orig_fra_low = orig_fra.lower()

    if get_use_online_db():
        th1 = background_do(online_get_advs, None)
        th1.start()
#        th2 = background_do(online_get_subs, None)
#        th2.start()

        import time
#        time.sleep(1.5)

    if (contains(orig_fra_low, "the answer to life, the universe and everything")
            or contains(orig_fra_low, "das leben, das universum und der ganze rest")
            or contains(orig_fra_low, "was ist das leben, das universum und der ganze rest")
            or contains(orig_fra_low, "was ist der sinn des lebens")
            ):
        ans = "42"

    proz += 1
    apply_procent(proz)

    if (contains(question.lower(), "wetter") or contains(question.lower(), "feuchtigkeit")
            or contains(question.lower(), "grad") or contains(question.lower(), "tempe")
            or contains(question.lower(), "warm") or contains(question.lower(), "kalt")
            or contains(question.lower(), "weather") or contains(question.lower(), "humidity")):
        print "advs:", dbs.advs
        import jelizacpp
        for adv in dbs.advs + [ p[1] for p in dbs.parts ]:
            a = adv[:]
            if contains(adv.lower(), "at "):
                d = download_weather(adv.replace("at ", "").strip())
                for item in d:
                    add_sentence_to_net(item, 1, 1, False)
            if contains(adv.lower(), "in "):
                d = download_weather(adv.replace("in ", "").strip())
                for item in d:
                    add_sentence_to_net(item, 1, 1, False)

        db = read_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml")
 #       actualNet()

    if len(ans) == 0:
        # Wikipediasuche
        if ((    ((get_lang() == "de") and (contains(orig_fra_low, "was") or contains(orig_fra_low, "wer")) and (containsWord(orig_fra_low, "ist") or containsWord(orig_fra_low, "war")))
             or ((get_lang() == "en") and (contains(orig_fra_low, "what") or contains(orig_fra_low, "who")) and (containsWord(orig_fra_low, "is") or containsWord(orig_fra_low, "was")))
            )
            and len(orig_fra_low) > 5):
            dbs.subject = (" " + without_nonsense(dbs.subject)).replace("ein ", "").replace("eine ", "").replace("einer ", "").replace("eines ", "").replace("einem ", "").replace("einen ", "").replace("der ", "").replace("die ", "").replace("das ", "").replace(" a ", "").replace(" an ", "").strip()
            dbs.object = (" " + without_nonsense(dbs.object)).replace("ein ", "").replace("eine ", "").replace("einer ", "").replace("eines ", "").replace("einem ", "").replace("einen ", "").replace("der ", "").replace("die ", "").replace("das ", "").replace(" a ", "").replace(" an ", "").strip()

            log("S-M: Wurde eine answer gefunden?")
            if len(dbs.subject + dbs.object + dbs.additional) > 0:
                defi = cpp_www_wikipedia_de((dbs.subject + " " + dbs.object + " " + dbs.additional).replace("{", "").replace("}", "").replace("_nothing", "").replace("nothing", "").replace("  ", " ").strip())
                log("S-M: answer wurde gefunden")
                defi = defi.strip()
                if len(defi) > 1:
                    log("S-M: answer wird ausgegeben")
                    ans = defi

                    log("S-M: answer:\n" + ans)

                    return ans


                else:
                    log("S-M: Keine answer gefunden!")

        if (contains(orig_fra, "?")
                and (not contains(orig_fra_low, ", was") and not orig_fra_low.startswith("was"))
                and not contains(orig_fra_low, "wer")
                and not contains(orig_fra_low, "wem")
                and not contains(orig_fra_low, "wen")
                and not contains(orig_fra_low, "wie")
                and not contains(orig_fra_low, "wo")
                and not contains(orig_fra_low, "wann")
                and not contains(orig_fra_low, "welch")
                and not contains(orig_fra_low, "warum")
                and not contains(orig_fra_low, "wieso")
                and not contains(orig_fra_low, "weshalb")

                and not contains(orig_fra_low, "what")
                and not contains(orig_fra_low, "why")
                and not contains(orig_fra_low, "who")
                and not contains(orig_fra_low, "whom")
                and not contains(orig_fra_low, "where")
                and not contains(orig_fra_low, "how")
                and not contains(orig_fra_low, "when")
                and not contains(orig_fra_low, "which")
                and not contains(orig_fra_low, "whose")
            ):
            ans = answer_logical_question_without_questionword(question, orig_fra, dbs)
        elif contains(orig_fra, "?"):
            ans = answer_logical_questionword(question, orig_fra, dbs)
        else:
            ans = answer_logical_statement(question, orig_fra, dbs)

    if len(ans) > 0:
        return make_better(ans).replace(".", "\n").replace("<br>", "\n")
    else:
        ans = answer_alternate(orig_fra, dbs, question)

        return ans

def wrapper_add_sentence_to_net(db, stop_it):
    try:
        lus_fp = open("temp/last_user_sentence.tmp")
        fra = lus_fp.read()
        lus_fp.close()

        from jelizacpp import cpp_is_question
        if cpp_is_question(fra):
            dbs = db_sentence()
            dbs.copy_tupel(cpp_to_db_sentence(fra))
            dbs = divide(dbs)

            add_sentence_to_net(dbs, 0, 0)
    except IOError:
        pass

from threading import Thread

class background_do(Thread):
    def __init__ (self, func, a = None, b = None, c = None, d = None, e = None, f = None):
           Thread.__init__(self)
           self.func = func
           self.a, self.b, self.c, self.d, self.e, self.f = a, b, c, d, e, f
    def run(self):
          self.func(self.a, self.b, self.c, self.d, self.e, self.f)

def online_fact(__agent, relation, ___object, prio = 50, sub = None, advs = []):
    for _agent in __agent.split(" und "):
        for agent_2 in _agent.split(" oder "):
            l1 = [ agent_2 ]
            for agent in l1:
                o = []

                for __object in ___object:
                    aa = ""
                    if contains(__object, "|"):
                        __object, aa = __object.split("|")
                    for _object in __object.split(" und "):
                        for object in _object.split(" oder "):

                            l2 = [ object + "|" + aa ]
                            o += l2

                online_fact_urls =  get_online_semantic_net_urls()
                for host, ofu in online_fact_urls:
                    ofu += "agent=" + agent.replace(" ", "%20")
                    ofu += "&rel=" + relation.replace(" ", "%20")
                    ofu += "&objects=" + ",".join(o).replace(" ", "%20")
                    ofu += "&advs=" + ",".join(advs).replace(" ", "%20")
                    ofu += "&prio=" + str(prio).replace(" ", "%20")
                    if sub:
                        ofu += "&sub=" + ",,,,".join([ s.uniq() for s in sub ]).replace(" ", "%20")

                    print "Online Fact Process started:"
                    print "Host:", host
                    print "File:", ofu

                    from httplib import HTTPConnection
                    port = 80
                    if contains(host, ":"):
                        host, port = host.split(":")
                    print "HTTPConnection(" + host + ", " + str(port) + ")"
                    http = HTTPConnection(host, port)
                    http.connect() # agent=ich|&rel=bin&objects=da|&prio=100
                    http.putrequest("GET", ofu)
                    print "http://" + host + "/" + ofu
                    http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
                    try:
                        http.endheaders()
                    except:
                        print "Socket Error while endheaders()"
                        pass

def online_learn_impl(dbs):
    from defs import db_sentence
    _dbs = db_sentence()
    _dbs.copy(dbs)
    add_sentence_to_net(_dbs, 2, 2, False, online_fact) # online_fact, Zuweisung an Funktionspointer

def online_learn(db, dbs):
    th = background_do(online_learn_impl, dbs)
    th.start()

PORT = 8080

def new_request(clientsocket, addr):
    prefix = "HTTP/1.1 200 OK\n"
    clientsockfile = clientsocket.makefile('rw')
    anfragezeile = clientsockfile.readline();
    anfragewoerter = string.split( anfragezeile )
    if not len(anfragewoerter):
        return
    if anfragewoerter[0] == 'GET' and len(anfragewoerter[0]) > 1:
        line = anfragewoerter[1].strip()
        parts = [ x.split("=") for x in line.split("&") if contains(x, "=") ]
        print "Request from " + str(addr) + ": " + str(parts)

        req = { }
        for key, val in parts:
            val = val.replace("%20", " ")
            key = key.replace("/", "")
            req[key] = val

        if "get_objs" in req.keys():
            if not contains(req["get_objs"], "|"):
                req["get_objs"] += "|"
            req["get_objs"] = req["get_objs"].split("|")

        if "get_subjs" in req.keys():
            if not contains(req["get_subjs"], "|"):
                req["get_subjs"] += "|"
            req["get_subjs"] = req["get_subjs"].split("|")

#        print "req:", req
        content = ""
        if "get_objs" in req.keys() and "rel" in req.keys():
            x = getObjekte(req["get_objs"], req["rel"])
#            print "x:", x
            for y in x:
                content += ";".join([ str(r) for r in y ]) + "\n"
        clientsocket.send(prefix)
        clientsocket.send("content-type: text/plain\n" )
        clientsocket.send("content-length: " + repr(len(content)) + "\n" )
        clientsocket.send("\n")
        clientsocket.send(content)
    else:
        print anfragezeile + ": not supported!"
    clientsockfile.close()

def server(a = None, b = None, c = None, d = None, e = None, f = None):
    #-----------------------------------------
    # Start des Servers
    import socket, time

    serversocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    while 1:
        try:
            serversocket.bind(('', PORT)) # socket.gethostname()
            break
        except:
            print "Reconnecting..."
            time.sleep(2)

    serversocket.listen(1)
    try:
        while 1:
            ( clientsocket, address ) = serversocket.accept()
            new_request( clientsocket, address )
            clientsocket.close()
    finally:
        serversocket.close()

def start_server(a, b):
    th = background_do(server, None)
    th.start()

funcs_module.append(answer_logical)
funcs_init.append(semantic_loadcache)
funcs_init.append(actualNet)
funcs_init.append(start_server)
funcs_after.append(actualNet)
funcs_background.append(online_get_subs)
funcs_do_learn.append(online_learn)
