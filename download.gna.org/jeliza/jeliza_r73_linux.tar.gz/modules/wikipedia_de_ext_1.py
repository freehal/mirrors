#-------------------------------------------------->
# JEliza Module
#
#-> name: wikipedia_de_ext_1
#-> compatible: 2.4
#-> author: JEliza Team
#-> copyright: Tobias Schulz
#-> date: 08.2007
#-------------------------------------------------->

# librarys to import
import random

import string
import random
from defs import contains
from jelizacpp import log
import time

# main part

def wikipedia_de_ext_1(question, orig_fra, db, is_positive):
    try:
        num = int(question)

        defi = cpp_listen_link_urls_get(num).strip()
        if len(defi) > 0:
            log("- War eine Nummer, die die Wikipedia Erweiterung 1 verwenden kann: " + question)

            return str(defi)
    except:
        log("- War keine Nummer, die die Wikipedia Erweiterung 1 verwenden kann: " + question)

        return ""
    return ""

funcs_module.append(wikipedia_de_ext_1)
