#!/usr/bin/perl -w

$| = 1;

#use strict;
#use warnings;
use CGI;
use CGI::Carp qw(fatalsToBrowser);

our $cgi = new CGI;
print $cgi->header();

our $dir = './';

my $temp_genus       = $cgi->param('genus');
my $temp_noun_or_not = $cgi->param('noun_or_not');
my $temp_word_type   = $cgi->param('word_type');     

my $question = $cgi->param('ask');

my $log  = $cgi->param('log');
my $lang = $cgi->param('lang') || $cgi->param('language');

sub LANGUAGE {
	return $lang || 'de';
}



sub footer {
	return if $show_simple;
	
	open my $template, "<", "footer.template.html";
	print join '', <$template>;
	close $template;
}


my $submit_and_get_answer = (LANGUAGE() eq 'de') ? 'Absenden und vorherigen Satz beantworten'
                                        : 'submit and get answer';
 
sub impl_get_genus {
	my ( $CLIENT_ref, $word ) = @_;
	my $CLIENT = $$CLIENT_ref;

	if ($temp_genus) {
		my $temp = $temp_genus;
		$temp_genus = undef;
		return $temp;
	}

	print << "	EOT";
	
	--></div>
	
	<p>
	EOT
	if ( LANGUAGE() eq 'de' ) {
		print << "		EOT";
	Welches grammatische Geschlecht (der, die, das) hat das Wort "$word"?
		EOT
	}
	else {
		print << "		EOT";
	Which genus is "$word"?
		EOT
	}
	print << "	EOT";
	</p>
	
	<form method="post">
	<select name='genus' size='5'>
	EOT
	if ( LANGUAGE() eq 'de' ) {
		print << "		EOT";
 		<option value='1'>m&auml;nnlich</option>
 		<option value='2'>weiblich</option>
 		<option value='3'>s&auml;chlich</option>
		EOT
	}
	else {
		print << "		EOT";
 		<option value='1'>male</option>
 		<option value='2'>female</option>
 		<option value='3'>thing</option>
		EOT
	}
	print << "	EOT";
 	</select>	<br/>	<br/>
	<input type="hidden" name="lang" value="$lang" />
	<input type="hidden" name="log" value="$log" />
 	<input type="hidden" name="ask" value="$question" />
 	<button name="ok" type='submit'>$submit_and_get_answer</button>
	EOT
	print '<input type="hidden" name="noun_or_not" value="' . ($cgi->param('noun_or_not')) . '" />';
	
	print << "	EOT";
	</form>
	
	EOT
	
	print footer();

	exit 0;
}

sub impl_get_noun_or_not {
	my ( $CLIENT_ref, $word ) = @_;
	my $CLIENT = $$CLIENT_ref;

	if ($temp_noun_or_not) {
		my $temp = $temp_noun_or_not;
		$temp_noun_or_not = undef;
		return $temp;
	}

	print << "	EOT";

	--></div>
	
	<p>
	EOT
	if ( LANGUAGE() eq 'de' ) {
		print << "		EOT";
	Ist das Wort "$word" als Nomen gemeint ?
		EOT
	}
	else {
		print << "		EOT";
	Is "$word" meant as a noun?
		EOT
	}
	print << "	EOT";
	</p>
	
	<form method="post">
	<select name='noun_or_not' size='5'>
	EOT
	if ( LANGUAGE() eq 'de' ) {
		print << "		EOT";
 		<option value='1'>Nomen</option>
 		<option value='2'>kein Nomen</option>
		EOT
	}
	else {
		print << "		EOT";
 		<option value='1'>it is a noun</option>
 		<option value='2'>it is no noun</option>
		EOT
	}
	print << "	EOT";
 	</select>	<br/>	<br/>
	<input type="hidden" name="lang" value="$lang" />
	<input type="hidden" name="log" value="$log" />
 	<input type="hidden" name="ask" value="$question" />
 	<button name="ok" type='submit'>$submit_and_get_answer</button>
	</form>
	
	EOT

	print footer();

	exit 0;
}

sub impl_get_word_type {
	my ( $CLIENT_ref, $word ) = @_;
	my $CLIENT = $$CLIENT_ref;

	if ($temp_word_type) {
		my $temp = $temp_word_type;
		$temp_word_type = undef;
		return $temp;
	}

	print << "	EOT";
	
	--></div>

	<p>
	EOT
	if ( LANGUAGE() eq 'de' ) {
		print << "		EOT";
	Welche Wortart hat das Wort "$word"?
		EOT
	}
	else {
		print << "		EOT";
	Which word type is "$word"?
		EOT
	}
	print << "	EOT";
	</p>
	
	<form method="post">
 	<select name='word_type' size='6'>
	EOT
	if ( LANGUAGE() eq 'de' ) {
		print << "		EOT";
 		<option value='2'>Nomen oder Name oder Pronomen</option>
 		<option value='1'>Verb</option>
 		<option value='3'>Adjektiv oder Adverb</option>
 		<option value='5'>Fragewort oder Konjunktion</option>
 		<option value='6'>Pr&auml;position</option>
 		<option value='7'>Interjektion / Ausruf</option>
		EOT
	}
	else {
		print << "		EOT";
 		<option value='2'>noun or name or pronoun</option>
 		<option value='1'>verb</option>
 		<option value='3'>adjective or adverb</option>
 		<option value='5'>question word or conjunction</option>
 		<option value='6'>preposition</option>
 		<option value='7'>interjection</option>
		EOT
	}
	print << "	EOT";
 	</select><br/><br/>
	<input type="hidden" name="lang" value="$lang" />
	<input type="hidden" name="log" value="$log" />
 	<input type="hidden" name="ask" value="$question" />
 	<button name="ok" type='submit'>$submit_and_get_answer</button>
	EOT
	print '<input type="hidden" name="noun_or_not" value="' . ($cgi->param('noun_or_not')) . '" />';
	
	print << "	EOT";

	</form>		 		
	EOT

	print footer();

	exit 0;
}

if (!$show_simple) {
	open my $template, "<", "header.template.html";
	print join '', <$template>;
	close $template;
}
if ( LANGUAGE() eq 'de' && !$show_simple ) {
	print << "	EOT";
<p>Dies ist die Online Version von <i>JEliza Perl</i>. Hier k&ouml;nnen Sie die k&uuml;nstliche Open-Source-Intelligenz
in ihrem Webbrowser ausprobieren.</p>

	EOT
}
elsif ( !$show_simple ) {
	print << "	EOT";
<p>This is the online version of our artificial intelligence <i>JEliza Perl</i>.</p>
	EOT
}
print << "EOT";

EOT

require 'jeliza-engine.pl';
$in_cgi_mode = 1;

#print "LANG: ", $lang;

#print $cgi->param('log');

my $statement = << "EOT";
<p style="color: black !important; font-size: 10pt !important; line-height: 28px; margin: 15px !important; background-color: #ffca9b !important; padding: 10px !important; margin-right: 300px !important;">
	Wir bitten um seri&ouml;se Gespr&auml;che mit JEliza; <br />
	JEliza ist ein ernst gemeintes Projekt zur Entwicklung eines Gespr&auml;chssimulators. <br />
	Daher bittet das JEliza Team ausdr&uuml;cklich darum, an Beleidigungen und vulg&auml;ren Ausdr&uuml;cken zu sparen.
</p>
EOT

print $statement if !$cgi->param('ask') && !$show_simple;


if ( $cgi->param('check_is_true') ) {
	load_word_types();
	load_database_file( $dir . "/lang_" . LANGUAGE() . "/facts.pro" );

	do_check_is_true_on_facts($cgi->param('check_is_true'));
}

if ( $cgi->param('ask') ) {
	my $display_str = '';

	open my $CLIENT, ">>", "to-server.log";

	print "<div style='display:none;'><!--";

	load_word_types();
	load_database_file( $dir . "/lang_" . LANGUAGE() . "/facts.pro" );

	my $dialog = ask( \$CLIENT, $cgi->param('ask'), \$display_str );
	$log .= $dialog;

	print "--></div>\n\n";
	
	$log =~ s/[:]+/:/igm;
	
	$log =~ s/\n//gm;
	
	chomp $log;
	
	my @log_lines = split /[<]br/, $log;

	print $statement if (@log_lines <= 3 || !$log) && !$show_simple;

	print $log;

	$log = (split /[<]iframe/, $log)[0];
	open my $dialog_file, ">>", 'dialog.txt';
	chomp $dialog;
	$dialog =~ s/[<]br[>]/\n/igm; 
	chomp $dialog;
	$dialog =~ s/[<](.*?)[>]//igm;
	$dialog =~ s/\s*$//igm;
	$dialog =~ s/^\s*//igm;
	my $time = scalar localtime;
	foreach my $line (split /\n/, $dialog) {
		chomp $line;
		
		print $dialog_file $time . "\t" . $line . "\n";
	}
	close $dialog_file;

}

my $please_enter = (LANGUAGE() eq 'de') ? 'Bitte Satz eingeben:'
                                        : 'Please enter a sentence:';
                                        
my $button_answer = (LANGUAGE() eq 'de') ? 'Antworten!'
                                         : 'Get answer!';


print << "EOT" if !$show_simple;
	<p>&nbsp;</p>
	<form method="post">
	<table style="border: none;">
	<tr>
	<td style="padding-right: 20px;">
		$please_enter
	</td>
	<td colspan="2">
		<input type="text" name="ask" id="ask" value="" size="50" />
		<input type="hidden" name="log" value="$log" /><br />
	</td>
	</tr>
	<tr>
	<td>&nbsp;</td>
	<td style="width: 50px !important; padding-top: 10px !important;">
	<select name="lang">
EOT
print '	<option value="en" ' . (LANGUAGE() eq 'en' ? 'selected="selected"' : '') . '>  EN  </option>'  if !$show_simple;
print '	<option value="de" ' . (LANGUAGE() ne 'en' ? 'selected="selected"' : '') . '>  DE  </option>'  if !$show_simple;
print << "EOT" if !$show_simple;
	</select>
	</td>
	<td style="padding-top: 10px !important;">
	<button name="ok" type='submit'>$button_answer</button>
	</td>
	</tr>
	</table>
	</form>
	
	<script type="text/javascript">
		document.getElementById('ask').focus();
	</script>

EOT

if ($show_simple) {
	print "<iframe src='http://developer.jeliza.org/online/jeliza-cgi.pl' style='border: none; width: 0px; height: 0px;'></iframe";
}

print footer();
if ( $cgi->param('ask') ) {
	do_check_is_true_on_facts();
}
exit(0);


1;
