#-------------------------------------------------->
# JEliza Module
#
#-> name: webcheck
#-> compatible: r66
#-> author: Tobias Schulz
#-> copyright: JEliza Team
#-> date: 01.2008
#-------------------------------------------------->

# librarys to import
import random
from defs import contains, containsWord, save_override_sentence, load_override_sentence, save_clear_override_sentence, load_clear_override_sentence
from utilities import get_first_names, get_not_first_names, add_first_name, add_not_first_name
from jelizacpp import *

def extract_content(content):
    content = content.split("<body")
    if len(content) <= 1:
        return ("Diese Webseite scheint kaputt zu sein?? (1)", "")
    content = content[1]
    if not contains(content, ">"):
        return ("Diese Webseite scheint kaputt zu sein?? (2)", "")
    content = content.split(">")
    content = ">".join(content[1:])
    content = content.split("</body>")[0]

    only_chars = ""
    in_tag = False
    in_klammer1 = False
    in_klammer2 = False
    for c in content:
        if c == "<":
            in_tag = True
        if c == "(":
            in_klammer1 = True
        if c == "[":
            in_klammer2 = True
        if not in_tag and not in_klammer1 and not in_klammer2:
            only_chars += c
        if c == ">":
            in_tag = False
        if c == ")":
            in_klammer1 = False
        if c == "]":
            in_klammer2 = False

    only_chars = only_chars.replace("&nbsp;", " ")
    only_chars = only_chars.replace("  ", " ")
    only_chars = only_chars.replace("\r", "")
    only_chars = only_chars.replace("\n\n", "\n")
    only_chars = only_chars.replace("&ouml;", "oe")
    only_chars = only_chars.replace("&auml;", "ae")
    only_chars = only_chars.replace("&uuml;", "ue")
    only_chars = only_chars.replace("&Ouml;", "Oe")
    only_chars = only_chars.replace("&Auml;", "Ae")
    only_chars = only_chars.replace("&Uuml;", "Ue")
    for x in range(0, 11):
        only_chars = only_chars.replace(str(x), "")


    return ("", only_chars.replace("\n", "\\n").strip())

def webcheck(question, orig_fra, db, is_positive):
    if contains(orig_fra.lower(), "ueberwach") and (contains(orig_fra.lower(), "nicht") or contains(orig_fra.lower(), "nie")):
        url = ""
        orig_fra = orig_fra.replace("!", "")
        orig_fra = orig_fra.replace(",", "")
        orig_fra = orig_fra.replace("\"", "")
        orig_fra = orig_fra.replace("'", "")
        if orig_fra.endswith("."):
            orig_fra = orig_fra[:1]
        for x in orig_fra.split(" "):
            if contains(x, "http"):
                url = x
                break
            if contains(x, ".de"):
                url = x
                break
            if contains(x, ".com"):
                url = x
                break
            if contains(x, ".org"):
                url = x
                break
        if not len(url):
            return ""
        fp = open("temp/check_websites.tmp", "r")
        lines = fp.readlines()
        fp.close()
        fp = open("temp/check_websites.tmp", "w")
        for line in lines:
            if not contains(url, line.split("---------------_________________----------------------________________------------------------------")[0]):
                fp.write(line.strip() + "\n")
        fp.close()
        return "Ich werde " + url + " nicht mehr ueberwachen."
    elif contains(orig_fra.lower(), "ueberwach"):
        url = ""
        orig_fra = orig_fra.replace("!", "")
        orig_fra = orig_fra.replace(",", "")
        orig_fra = orig_fra.replace("\"", "")
        orig_fra = orig_fra.replace("'", "")
        if orig_fra.endswith("."):
            orig_fra = orig_fra[:1]
        for x in orig_fra.split(" "):
            if contains(x, "http"):
                url = x
                break
            if contains(x, ".de"):
                url = x
                break
            if contains(x, ".com"):
                url = x
                break
            if contains(x, ".org"):
                url = x
                break
        if not len(url):
            return ""
        print "URL:", url
        url = url.replace("https:", "http:")
        url = url.replace("http://", "")
        url = url.split("/")
        host = url[0][:]
        url.remove(host)
        print "Host:", host
        print "url:", url
        from httplib import HTTPConnection
        http = HTTPConnection(host, 80)
        http.connect() # agent=ich|&rel=bin&objects=da|&prio=100
        http.putrequest("GET", "/" + "/".join(url))
        http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
        try:
            http.endheaders()
        except:
            print "Socket Error while endheaders()"
            return "Sorry, ich glaube, ich habe Alzheimer bekommen."
        content = http.getresponse().read()
        err, content = extract_content(content)
        if len(err):
            return err
        print content
        fp = open("temp/check_websites.tmp", "a")
        fp.write(host)
        fp.write("---------------_________________----------------------________________------------------------------")
        fp.write("/" + "/".join(url))
        fp.write("---------------_________________----------------------________________------------------------------")
        fp.write(content)
        fp.write("\n")
        fp.close()
        print "Ok."
        return "Ok."


    return ""

def check_websites(x):
    already_performed = []
    try:
        fp = open("temp/already_performed.tmp")
        already_performed += [ x.strip() for x in fp.readlines() ]
        fp.close()
    except IOError:
        pass

    from time import sleep
    while 1:
        sleep(30)

        fp = open("temp/check_websites.tmp", "r")
        lines = fp.readlines()
        fp.close()

        his = []
        _diff_s = []

        for line in lines:
            line = line.strip()
            if len(line):
                host, url, last = line.split("---------------_________________----------------------________________------------------------------")

                from httplib import HTTPConnection
                http = HTTPConnection(host, 80)
                http.connect() # agent=ich|&rel=bin&objects=da|&prio=100
                http.putrequest("GET", url)
                print "Checking:", host, url
                http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
                try:
                    http.endheaders()
                except:
                    print "Socket Error while endheaders()"
                    pass
                content = http.getresponse().read()
                err, content = extract_content(content)

                if content != last:
                    if (host + url) not in his:
                        his.append(host + url)
                    if content in already_performed:
                        continue
                    already_performed.append(content)
                    fp = open("temp/already_performed.tmp", "a")
                    fp.write(content + "\n")
                    fp.close()

                    diff_last = last[:]
                    _diff_last = [ x.strip() for x in diff_last.split(". ") ]
                    diff_content = content[:]
                    _diff_content = [ x.strip() for x in diff_content.split(". ") ]
                    diff_last = []
                    diff_content = []
                    for x in _diff_content:
                        for y in x.split("\\n"):
                            _y = ""
                            for z in y:
                                if ord(z) < 128:
                                    _y += z
                            diff_content.append(_y.strip().replace(".", "").replace("  ", " ") + "\n")
                    for x in _diff_last:
                        for y in x.split("\\n"):
                            _y = ""
                            for z in y:
                                if ord(z) < 128:
                                    _y += z
                            diff_last.append(_y.strip().replace(".", "").replace("  ", " ") + "\n")

                    from difflib import ndiff
                    diff = ndiff([ cc for cc in diff_last ], [ cc for cc in diff_content ])
                    diff = ''.join(diff).split("\n")
                    _diff = [ x[2:] for x in diff if len(x) > 2 and x.startswith("+ ") ]
                    __diff = [ x[2:] for x in diff if len(x) > 2 and x.startswith("- ") ]

                    if len(_diff):
                        _diff = "Dieser Text wurde hinzugefuegt:\n\n" + ". ".join(_diff)
                    else:
                        _diff = ". ".join(_diff)
                    if len(__diff):
                        __diff = "Dieser Text ist verschwunden:\n\n" + ". ".join(__diff)
                    else:
                        __diff = ". ".join(__diff)
                    _diff = _diff.replace("+", "")
                    _diff_s.append(_diff)
                    __diff = __diff.replace("-", "")
                    _diff_s.append(__diff)

                    fp = open("temp/add_to_history.tmp", "a")
                    if len(his) > 1:
                        fp.write("Die Webseiten " + ", ".join(his) + " haben sich geaendert! " + "\n\n" + "\n\n".join(_diff_s))
                        display("<b>JEliza::</b> Die Webseiten " + ", ".join(his).replace(":", "ugihkjbvfguh").replace("ugihkjbvfguh", "::") + " haben sich geaendert! " + "\n\n".join(_diff_s))
                    else:
                        display("<b>JEliza::</b> Die Webseite " + ", ".join(his).replace(":", "ugihkjbvfguh").replace("ugihkjbvfguh", "::") + " hat sich geaendert! " + "\n\n".join(_diff_s))
                        fp.write("Die Webseite " + ", ".join(his) + " hat sich geaendert! " + "\n\n" + "\n\n".join(_diff_s))
                    fp.close()

funcs_module_raw.append(webcheck)
funcs_background.append(check_websites)

