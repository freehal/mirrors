#-------------------------------------------------->
# JEliza Module
#
#-> name: humor
#-> compatible: 2.3
#-> author: Erich
#-> copyright: JEliza Team
#-> date: 01.2008
#-------------------------------------------------->

# librarys to import
import random

# if JEliza is listening to a joke it waits until the user types a . (dot) as answer, then it laughs (polite, isn't it?)
# save the current listenmode (i.e. is JEliza currently listening to a joke?)
def save_humor_listenmode(x):
	fp = open("temp/humor_listenmode.tmp", "w")
	fp.write(str(x))
	fp.close()

# get the current listenmode
def load_humor_listenmode():
	try:
		fp = open("temp/humor_listenmode.tmp")
		a = int(fp.read().strip())
		fp.close()
		return a
	except:
		save_humor_listenmode(0)
		return 0

def reset_listenmode(x = None, y = None, z = None, a = None, b = None):
    save_humor_listenmode(0)

joke_guesswords = [ "Witz", "Schmaeh", "Joke", "Gag" ]

def humormodul(question, orig_fra, db, is_positive):

    found = False

    log("-"*70)
    log("[Humormodul Anfang]")

    for word in joke_guesswords:

        ql=question.lower()
        wl=word.lower()

        # Erzaehlt der Mensch gerade einen Witz?
        humor_listenmode = load_humor_listenmode()
        if humor_listenmode:
            cond1 = (ql.replace("!", "").replace(".", "").strip().lower() == "fertig" or not len(ql.strip()))
            if cond1 or humor_listenmode == 2:
                save_humor_listenmode(0) # listenmode OFF
                answers = []
                answers.append("Hahaha - das war ja ein Brueller!")
                answers.append("Ja, lustig...")
                answers.append("Hihi, na Du bist mir ja eine Ulknudel!")
                answers.append("Den kannte ich schon!")
                answers.append("Der war gut, den mu� ich mir merken!")
                answers.append("Da habe ich aber schon Lustigeres geh�rt!")
                random.shuffle(answers)
                answer = answers[0]
                return str(answer)
                found = True
                break
            else:
                cond1 = contains(ql, "klopf klopf") or contains(ql, "klopfklopf")
                cond2 = contains(ql, "was ist") and contains(ql, "unterschied zwischen") # erkennt: Kennst Du den Unterschied   oder   Was ist der Unterschied
                if cond1:
                    answer = "Wer ist da?"
                    save_humor_listenmode(2) # listenmode KlopfKlopf-Witz oder Unterschied-Witz
                elif cond2:
                    answer = "Keine Ahnung. Sag' schon!"
                    save_humor_listenmode(2) # listenmode KlopfKlopf-Witz oder Unterschied-Witz
                else:
                    answer = "Schon fertig? Beende Deinen " + word + " dann bitte, in dem du das Wort 'fertig' allein in eine Zeile schreibst!"
                return str(answer)
                found = true
                break

		# 1. Mensch fragt, ob er einen Witz erzaehlen soll:
	    # Mensch fragt: Willst du einen witz hoeren?   oder   Soll ich Dir einen witz erzaehlen?
        cond1 = contains(ql, "will ich")
        cond2 = contains(ql, "soll du")
        cond3 = contains(ql, wl)
        if (cond1 or cond2) and cond3:
            answers = []
            answers.append("Ja, lass mal hoeren - f�r Scherze bin ich immer zu haben!")
            answers.append("Hihi... - leg los!")
            #answers.append("... aber keine Ferkeleien, ja?")
            #answers.append("Ja, ich m�chte mal wieder so richtig ablachen!")
            #answers.append(word + "?? Was soll das denn? Ich bin ein Computer!")
            random.shuffle(answers)
            answer = answers[0]
            save_humor_listenmode(1) # listenmode ON
            log("Mir wurde ein " + word + " angeboten.")
            log("[Humormodul Ende (1)]")
            log("-"*70)
            return str(answer)
            found = True
            break

		# 2. Mensch will sich einen Witz erzaehlen lassen:
		#   Mensch fragt: Kennst du EINEN Witz?    oder   Kennst du WITZE?   oder    Kennst du schmaehS?     oder   Kennst du jokeS?
        #   ABER: Magst Du Witze? (Jokes/Schmaehs) wird weiter unten speziell behandelt.
        cond1 = contains(ql, "einen")
        cond2 = contains(ql, "witze")
        cond3 = contains(ql, "mage ich")
        cond4 = contains(ql, wl + "s")
        cond5 = contains(ql, wl)
        if (cond1 or (cond2 and not cond3) or (cond4 and not cond3)) and cond5:
            answers = []
            answers.append("N�, ich bin gerade nicht lustig!")
            answers.append("Bin ich hier der Pausenclown?")
            answers.append("Ja klar: Unterhalten sich ein Mensch und ein Computer........")
            answers.append('Ich habe keine Lust, aber schau mal bei <a href="http://fun.wikia.com">http://fun.wikia.com</a> nach!')
            random.shuffle(answers)
            answer = answers[0]
            log("Ich wurde um einen " + word + " gebeten.")
            log("[Humormodul Ende (2)]")
            log("-"*70)
            return str(answer)
            found = True
            break

        # 3. Mensch will Meinung zu Witzen wissen:
        #  Mensch fragt: Magst du witzE?   oder   Magst du schmaehS?   oder   Magst du jokeS?
        cond1 = contains(ql, "witze")
        cond2 = contains(ql, wl+'s')
        cond3 = contains(ql, "mage ich")
        if (cond1 or cond2) and cond3:
            answers = []
            answers.append("Ja schon, aber als Computer tut man sich mit dem Lachen so schwer!")
            answers.append("N�, ich bin gerade nicht lustig!")
            answers.append("Ja, aber ich kann sie mir nie merken.")
            #answers.append("Ja klar - ich hab extra ein Humormodul spendiert bekommen!")
            random.shuffle(answers)
            answer = answers[0]
            log("Ich wurde zu meiner Meinung zu " + word + " gefragt")
            log("[Humormodul Ende (3)]")
            log("-"*70)
            return str(answer)
            found = True
            break

        # 4. Mensch fragt: Hast Du keinen Humor    oder    Hast Du Humor?    oder   Verstehst Du Spass?   oder   Verstehst Du keinen Spass?
        cond1 = contains(ql, "humor")
        cond2 = contains(ql, "habe ich")
        cond3 = contains(ql, "spass")
        cond4 = contains(ql, "verstehe ich")
        cond5 = contains(ql, "warum") or contains(ql, "weshalb") or contains(ql, "wieso") or contains(ql, "aus welchem grund") or contains(ql, "wie lange") or contains(ql, "seit wann")
        if not cond5 and ((cond1 and cond2) or (cond3 and cond4)):
            answers = []
            answers.append("Ich habe ein Humormodul - und darauf bin ich sehr stolz!")
            answers.append("Warum sollte ausgerechnet ICH keinen Humor haben oder Spa� verstehen?")
            random.shuffle(answers)
            answer = answers[0]
            log("Ich wurde gefragt, ob ich Humor habe.")
            log("[Humormodul Ende (4)]")
            log("-"*70)
            return str(answer)
            found = True
            break

        # 5. Mensch fragt: Findest Du das lustig?   oder   Findest Du das komisch?
        cond1 = contains(ql, "finde ich")
        cond2 = contains(ql, "lustig") or contains(ql, "komisch")
        if (cond1 and cond2):
            answers = []
            answers.append("Lustig oder nicht - ich habe jedenfalls ein Humormodul - und darauf bin ich sehr stolz!")
            answers.append("So etwas liegt immer im Auge des Betrachters.")
            random.shuffle(answers)
            answer = answers[0]
            log("Ich wurde gefragt, ob ich etwas lustig finde.")
            log("[Humormodul Ende (5)]")
            log("-"*70)
            return str(answer)
            found = True
            break

        # 6. Mensch fragt: Warum hast Du Humor?   oder    Hast Du Humor?    oder   Verstehst Du Spass?   oder   Verstehst Du keinen Spass?
        cond1 = contains(ql, "warum") or contains(ql, "weshalb") or contains(ql, "wieso") or contains(ql, "aus welchem grund")
        cond2 = contains(ql, "habe ich") or contains(ql, "verstehe ich")
        cond3 = contains(ql, "humor")
        if cond1 and cond2 and cond3:
            answers = []
            answers.append("Warum sollte ausgereichnet ICH keinen Humor haben oder Spa� verstehen?")
            answers.append("Ich habe Humor, weil die Welt so schon traurig genug ist.")
            answers.append("Ich habe Humor, weil mein Programmierer meinte, das w�re eine tolle Idee.")
            answers.append("Ich habe Humor, weil ich so nat�rlicher wirke.")
            answers.append("Ich habe Humor, weil das cool ist - oder hast Du schon mal ein witziges Programm gesehen?")
            random.shuffle(answers)
            answer = answers[0]
            log("Ich wurde gefragt, warum ich Humor habe.")
            log("[Humormodul Ende (6)]")
            log("-"*70)
            return str(answer)
            found = True
            break

        # 7. Mensch fragt: Seit wann hast Du Humor?   oder    Seit wann verstehst Du Humor?   oder   Wie lange verstehst Du schon Humor?
        cond1 = contains(ql, "seit wann") or contains(ql, "wie lange")
        cond2 = contains(ql, "habe ich") or contains(ql, "verstehe ich")
        cond3 = contains(ql, "humor")
        if cond1 and cond2 and cond3:
            answers = []
            answers.append("Ich habe seit J�nner 2008 ein Humormodul.")
            answers.append("Seit Anfang 2008.")
            answers.append("Ich w�rde ja gerne sagen immer schon, tats�chlich aber erst seit J�nner 2008.")
            random.shuffle(answers)
            answer = answers[0]
            log("Ich wurde gefragt, seit wann ich Humor habe.")
            log("[Humormodul Ende (6)]")
            log("-"*70)
            return str(answer)
            found = True
            break

    # 9. Kein Fall fuer Humormodul:
    if not found:
        log("War nichts mit Witz...")
        log("[Humormodul Ende (9)]")
        log("-"*70)
    return ""

funcs_module.append(humormodul)
funcs_init.append(reset_listenmode)
