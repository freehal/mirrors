import sys
sys.path = [ "./", "./modules", "./jelizapy/lib/", "./lib/", "./jelizapy/lib-dynload", "bin" ] + sys.path
sys.argv = [ "./kernel.exe" ]
print sys.path

try:
    sys.winver
    print
    print 'Psyco: Windows'
    print
    """ Laeuft auf Windows """
    import psycowin as psyco
    psyco.log()
    psyco.full(memory=7000)
except:
    print
    print 'Psyco: Linux'
    print
    try:
        import psyco_linux as psyco
        psyco.log()
        psyco.full(memory=20000)
    except ImportError:
        print
        print 'Cannot activate Psyco'
        print


from utilities import *
from defs import *
from jelizacpp import *
from threading import *
true = True
false = False
loadcache()

from modules.defs import *

db = []

funcs_module = []
funcs_before = []
funcs_after = []
funcs_idle = []
funcs_init = []
funcs_background = []
funcs_learn = []
funcs_direct_after = []
funcs_do_learn = []
funcs_before_answer = []

fp = open("modules/index.cfg")
mods = fp.read().strip().split("\n")
fp.close()
for mod in mods:
    log("- Module: " + mod)
    mod = mod.strip()
    if len(mod) > 0:
        exec(open("modules/" + mod + ".py").read())


class background_do(Thread):
    def __init__ (self, func, db):
        Thread.__init__(self)
        self.func = func
        self.db = db
    def run(self):
        self.func(self.db)

class background_do_process(Thread):
    def __init__ (self, func, x, y, z, a, b, c):
        Thread.__init__(self)
        self.func = func
        self.x, self.y, self.z, self.a, self.b, self.c = x, y, z, a, b, c
    def run(self):
        self.func(self.x, self.y, self.z, self.a, self.b, self.c)


def exec_modules(num, question, orig_question):
    try:
        db = read_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml")
        db_ = read_jeliza_db("lang_" + get_lang() + "/jeliza-online.xml")

        db_orig = db + db_ + []

    except:
        time.sleep(1)
        db = read_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml")
        db_ = read_jeliza_db("lang_" + get_lang() + "/jeliza-online.xml")
        db_orig = db + db_ + []

    for func in funcs_before:
        db = db_orig + []
        func(question, orig_question, db)

    # -1 -> nagetive
    #  0 -> unsure
    #  1 -> positive
    is_positive = 0
    if containsWord(orig_question.lower(), "nein") or containsWord(orig_question.lower(), "no") or containsWord(orig_question.lower(), "noe") or containsWord(orig_question.lower(), "kein vorname"):
        is_positive = -1
    elif containsWord(orig_question.lower(), "ja") or containsWord(orig_question.lower(), "jo") or containsWord(orig_question.lower(), "yes") or containsWord(orig_question.lower(), "ein vorname"):
        is_positive = 1

    for func in funcs_module:
        db = db_orig + []

        try:
            if len(load_override_sentence()):
                question, orig_question = load_override_sentence().split("||||||")
            ans = func(question, orig_question, db, is_positive)
            ans = str(ans)
            if len(ans) > 0:
                return ans

        except KeyError:
            print
            print
            print "KEYERROR"
            print
            print
            raise
            return ""


class IdleThread(Thread):
    func = None
    db = None
    stop_it = None

    def setFunc(self, func, db, stop_it):
        self.func = func
        self.db = db
        self.stop_it = stop_it

    def run(self):
        self.func(self.db, self.stop_it)


def display_history(his, oldhis):
#    if his != oldhis:

    print "DISPLAY:", his

    display("<br>".join(his))
    from time import sleep

    oldhis = []
    oldhis += [ hi.strip() for hi in his ]

def process(fra, orig_fra, stop_it, num, history, oldhis):
    from utilities import split_subclause, correct_time
    s_fra = saetze_einzeln(expand_ausdruecke(fra), True)[:]
    s_orig_fra = saetze_einzeln(expand_ausdruecke_orig(orig_fra), False)[:]

    q = 0
    answeren = []
    db = read_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml")
    if len(s_fra) > 1:
        for o in s_orig_fra[1]:
            for oo in split_subclause(o)[1]:
                print "Learn:", oo
                oo = correct_time(oo)
                if not contains(oo, "?") and load_do_learn():
                    dbs = db_sentence()
                    dbs.copy_tupel(cpp_to_db_sentence(oo))
                    divide(dbs)
                    db.append(dbs)
    write_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml", db)
#                        cpp_learn(o)
    db_ = read_jeliza_db("lang_" + get_lang() + "/jeliza-online.xml")
    for func in funcs_after:
        func(db + db_, stop_it)


    for func in funcs_before_answer:
        x = func()
        db += x
        print x
    while q < len(s_fra[0]) and q < len(s_orig_fra[0]):
        print "s_fra", s_fra
        if not len(s_fra[0][q]):
            q += 1
            continue
        f = expand_ausdruecke(split_subclause(s_fra[0][q])[0])
        orig_f = expand_ausdruecke_orig(split_subclause(s_orig_fra[0][q])[0])
        f = correct_time(f)
        orig_f = correct_time(orig_f)
        print "f", f
        print "orig_f", orig_f

        if not len(f):
            q += 1
            continue

        answeren += exec_modules(num, f, orig_f).split("\n")

        if len(load_override_sentence()):
            f, orig_f = load_override_sentence().split("||||||")

        for func in funcs_learn:
            func(db, stop_it)

        if not contains(f, "?") and load_do_learn():
            dbs = db_sentence()
            dbs.copy_tupel(cpp_to_db_sentence(f))
            divide(dbs)
            print "#################################################"
            print "LEARNING:"
            print "#################################################"
            print dbs.parts
            dbs.print_parts()
            db.append(dbs)
            for func in funcs_do_learn:
                func(db, dbs)
            print "#################################################"

        q += 1
    write_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml", db)

    print answeren

    print "load_clear_override_sentence():", load_clear_override_sentence()
    if int(load_clear_override_sentence()) == 1:
        save_override_sentence("")

    cpp_say(". ".join(answeren))
    for o in orig_fra.split("."):
        o = o.strip()
        if len(o):
            history.append("<b>Mensch::</b> " + o)
    _answeren = answeren[:]
    answeren = [ "" ]
    pre = ""
    for ant in _answeren:
        if len(ant) > 3:
            answeren.append(pre.strip() + " " + ant)
            pre = ""
        else:
            pre += ant + ". "
    if len(pre) > 0:
        if len(answeren) > 0:
            answeren[-1] += pre.strip()
        else:
            answeren.append(pre.strip())
    if len(answeren):
        while len(answeren[0].strip()) == 0 and len(answeren) > 1:
            answeren.remove(answeren[0])
    history += [ "<b>JEliza::</b> " + ant.strip().replace(":", ":::") for ant in answeren if len(ant.strip()) > 0 ]
    print history
    display_history(history, [])
#    time.sleep(2)

    db_ = [ ]
    fp = open("temp/sentences_to_learn.tmp")
    lines = fp.readlines()
    fp.close()
    for line in lines:
        if len(line):
            dbs = db_sentence()
            dbs.copy_tupel(cpp_to_db_sentence(line))
            divide(dbs)
#            print "#################################################"
#            print "LEARNING (second):"
#            print "#################################################"
#            print line
            db_.append(dbs)
#            print "#################################################"
    fp = open("temp/sentences_to_learn.tmp", "w")
    fp.close()
    write_jeliza_db("lang_" + get_lang() + "/jeliza-online.xml", db_)


    db_ = read_jeliza_db("lang_" + get_lang() + "/jeliza-online.xml")
    db = read_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml")
    for func in funcs_after:
        func(db + db_, stop_it)


def loop():
    history = []
    oldhis = []

    stop_it = False

    db = read_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml")
    db_ = read_jeliza_db("lang_" + get_lang() + "/jeliza-online.xml")
    for func in funcs_init:
        func(db + db_, stop_it)

    is_ready = True
    threads_to_join = []

    for func in funcs_background:
        thread = background_do(func, db)
        thread.start()

    num = 0
    while True:
        cpp_update_prozent(0)

        while not is_ready:
            time.sleep(1)

        is_ready = False

        num += 1
        fra = ""

        hook = ""
        try:
            fp = open("temp/clear_talking.tmp")
            hook = fp.read().strip()
            fp.close()
        except:
            pass
        if len(hook) > 0:
            fp = open("temp/clear_talking.tmp", "w")
            fp.close();
            history = []
#            display_history(history, [])
            oldhis = []


        try:
            fp = open("temp/new_sentence.tmp")
            fra = fp.read().strip()
            fp.close()
        except:
            pass
        if len(fra) > 0:
            fp = open("temp/new_sentence.tmp", "w")
            fp.close()

            num = 0

            stop_it = True

            if fra == "!!init":
                old_stop_it = not (not stop_it)
                stop_it = False
                db = read_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml")
                db_ = read_jeliza_db("lang_" + get_lang() + "/jeliza-online.xml")
                for func in funcs_init:
                    func(db + db_, stop_it)
                continue
                stop_it = old_stop_it


            stop_it = True

            orig_fra = cpp_transformation(fra)
            orig_fra, fra = fra, orig_fra


            th = background_do_process(process, fra, orig_fra, stop_it, num, history, oldhis)
            th.start()

            if num % 180 == 0:
                stop_it = False
                for func in funcs_idle:
                    a = IdleThread()
                    a.setFunc(func, db, stop_it)
                    a.start()


        is_ready = True

        time.sleep(0.3)



loop()


