#-------------------------------------------------->
# JEliza Module
#
#-> name: Math
#-> compatible: 2.4
#-> author: JEliza Team
#-> copyright: Tobias Schulz
#-> date: 08.2007
#-------------------------------------------------->

# librarys to import
import random
from string import *

# main part


def zuRechnung(question):
    betterquestion = ""
    question = question.replace(",", ".")
    woerter = question.split(" ")
    for word in woerter:
        add = True
        l = len(ascii_letters)
        i = 0
        while i < l:
            let = str(ascii_letters[i])

            if contains(word, let):
                add = False
                break

            i = i + 1
        if add:
            betterquestion = betterquestion + word + " "

    betterquestion = betterquestion.replace("?", "")
    betterquestion = betterquestion.replace("!", "")
    betterquestion = betterquestion.strip()
    log("Verbesserte Rechnung: " + betterquestion)

    return betterquestion

def rechne(question, nochmal):
    answer = -1

    try:
        from math import acos, asin, atan, atan2, ceil, cos, cosh, degrees, exp, fabs, floor, fmod, frexp, hypot, ldexp, log, log10, radians, sin, sinh, sqrt, tah, tanh, e, pi
        answer = eval(question)

#        if str(answer) + 4 < str(question):
#            fp = open("temp/answer.tmp", "w")
#            fp.close()
#        else:

        log("- War eine Rechenaufgabe: " + str(question) + " = " + str(answer))

        return str(answer).strip()

    except:
        if nochmal:
            question = zuRechnung(question)
            rechne(question, False)
        else:
#            log("- War keine Rechenaufgabe (TypeError): " + str(question))

            return ""
        return ""

    log("- War keine Rechenaufgabe (unbekannter Error): " + question)
    return ""

def rechnenmodul(question, orig_fra, db, is_positive):
    return rechne(orig_fra, True)

funcs_module.append(rechnenmodul)

