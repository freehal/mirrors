# -*- coding: utf-8 -*-

#-------------------------------------------------->
# JEliza Util functions for modules
#
#-> module: _util
#-> compatible: 2.4
#-> author: JEliza Team
#-> copyright: Tobias Schulz
#-> date: 08.2007
#-------------------------------------------------->

# imports
import string
import time
from defs import get_lang, contains, containsWord
from jelizacpp import *





# help functions


def compare (s1, s2):
    return (compare_one(s1, s2) + compare_one(s2, s1)) / 2

def correct_time(i):
    import sys, re
    s =  [
             "\\1:\\2:00 ",
             "\\1:\\2:\\3",
             "\\1:00:\\2",
             "\\1:00:00 "
         ]
    p1 = [
             (re.compile('([0-9]+?)[\s,.;]+Uhr[\s,.;]+([0-9]+?)[\s,.;]*?Min[\w]*?[\s,.;]+und[\s,.;]*?([0-9]+?)[\s,.;]+sekunden', re.IGNORECASE), s[1]),
             (re.compile('([0-9]+?)[\s,.;]+Uhr[\s,.;]+([0-9]+?)[\s,.;]*?[Min]*?[\w]*?[[\s,.;]+und,;.-][\s,.;]*?([0-9]+?)[\s,.;]+sekunden', re.IGNORECASE), s[1]),
             (re.compile('([0-9]+?)[\s,.;]+Uhr[\s,.;]+und[\s,.;]+([0-9]+?)[\s,.;]+M\w+[\s,.;]', re.IGNORECASE), s[0]),
             (re.compile('([0-9]+?)[\s,.;]+Uhr[[\s,.;]+,;][\s,.;]+([0-9]+?)[\s,.;]+M\w+[\s,.;]', re.IGNORECASE), s[0]),
              (re.compile('([0-9]+?)[\s,.;]+Uhr[\s,.;]+und[\s,.;]+([0-9]+?)[\s,.;]+Se\w+[\s,.;]', re.IGNORECASE), s[2]),
             (re.compile('([0-9]+?)[\s,.;]+Uhr[[\s,.;]+,;][\s,.;]+([0-9]+?)[\s,.;]+Se\w+[\s,.;]', re.IGNORECASE), s[2]),
             (re.compile('([0-9]+?)[:,.;]([0-9]+?)[:,.;]([0-9]+?)[\s,.;]+Uhr[\s,.;]', re.IGNORECASE), s[1]),
             (re.compile('([0-9^:]+?)[:;,.]([0-9]+?)[\s,.;]+Uhr[\s,.;]', re.IGNORECASE), s[0]),
             (re.compile('([0-9]+?)[\s,.;]+Uhr[\s,.;]+([0-9]+?)[\s,.;]', re.IGNORECASE), s[0]),
             (re.compile('([0-9]+?)[\s,.;]+Uhr[\s,.;]', re.IGNORECASE), s[3]),

             (re.compile('[\s,.;]([0-9]):([0-9]+?):([0-9]+?)', re.IGNORECASE), " 0\\1:\\2:\\3"),
             (re.compile('([0-9]+?):([0-9]):([0-9]+?)', re.IGNORECASE), "\\1:0\\2:\\3"),
             (re.compile('([0-9]+?):([0-9]+?):([0-9])(.*?)', re.IGNORECASE), "\\1:\\2:0\\3\\4"),

             (re.compile('00', re.IGNORECASE), "0"),
             (re.compile(':0', re.IGNORECASE), ":00"),
            (re.compile(':00([0-9][0-9])', re.IGNORECASE), ":\\1"),
             (re.compile(':0([0-9][0-9])', re.IGNORECASE), ":\\1"),
             (re.compile(':0([0-9][0-9])', re.IGNORECASE), ":\\1"),
             (re.compile('([0-9][0-9]:[0-9][0-9]:[0-9][0-9])', re.IGNORECASE), "\\1 Uhr"),
         ]

    i = i.strip()
    i = i.replace(", ", ",")
    i = i.replace(" ,", ",")
    i = i.replace(",", " , ")

    for (p, s) in p1:
        i = "  " + i + "  "
        i = p.sub(s, i)
        i = i.replace(":", "_")
        i = i.replace("\n", "")
        i = i.strip()
#        print i

    i = i.replace(", ", ",")
    i = i.replace(" ,", ",")
    i = i.replace(",", ", ")
    i = i.replace("Uhr Uhr", "Uhr ")
    i = i.replace("Uhr", "Uhr ")
    i = i.replace("Uhr zeit", "Uhrzeit ")
    i = i.replace("  ", " ")

    import time
    tim = time.localtime()
#    print "(year,month,day,hour,min,sec,weekday(Monday=0),yearday,dls-flag)"
    r = re.compile('(.*?)([0-9][0-9]:[0-9][0-9]:[0-9][0-9])(.*)', re.IGNORECASE)
    t = r.sub("\\2", i)
    t = t.split(":")
#    print t
#    print tim
    is_jetzt = False
    if len(t) == 3:
        if int(t[1]) == 0:
            if int(t[0]) == int(tim[3]) or int(t[0]) - 12 == int(tim[3]) or int(t[0]) == int(tim[3]) - 12:
                is_jetzt = True
        else:
            if int(t[0]) == int(tim[3]) or int(t[0]) - 12 == int(tim[3]) or int(t[0]) == int(tim[3]) - 12:
                if int(t[1]) == int(tim[4]):
                    is_jetzt = True

    print "jetzt:", is_jetzt
    if is_jetzt:
        return i.replace(":".join(t) + " Uhr", "NOW Uhr").replace(":".join(t), "NOW Uhr")

    return i

def is_similar(s1_2, s2_2):
    try:
        s1 = s1_2 + ""
    except:
        return bool(len([ x for x in s1_2 if is_similar(x, s2_2) and len(x.strip()) ]))
    try:
        s2 = s2_2 + ""
    except:
        return bool(len([ x for x in s2_2 if is_similar(x, s1_2) and len(x.strip()) ]))

    s1 = s1_2 + ""
    s2 = s2_2 + ""

    if s1 == s2:
        return True

    s1 = s1.lower()
    s1 = s1.strip()
    s1 = s1.replace("_", " ")

    s2 = s2.lower()
    s2 = s2.strip()
    s2 = s2.replace("_", " ")

#    print "is_similar:", s1_2, "\t#\t", s2_2

    if len(s1) < 1 or len(s2) < 1:
#        print "False 1"
        return False

    if len(s1) < 1 and len(s2) > 0:
#        print "False 2"
        return False

    if len(s2) < 1 and len(s1) > 0:
#        print "False 3"
        return False

    if s1 == s2:
#        print "True 4"
        return True
    if containsWord(s1, s2):
#        print "True 5"
        return True
    if containsWord(s2, s1):
#        print "True 6"
        return True

#    print "False 7"
    return False

def is_similar_in_array(o, arr):
    if not len(str(o).strip()):
        return False
    return bool(len([ x for x in arr if is_similar(x, o) ]))


def apply_procent(procent):
    cpp_update_prozent(procent)
#    time.sleep(0.05)

def case_indep_replace(s, f, r):
    if s.lower().find(f.lower()) > -1:
        ss = s[:]
        sss = ""

        while ss.lower().find(f.lower()) > -1:
            sss += ss[:ss.lower().find(f.lower())]
            ss = ss[ss.lower().find(f.lower())+len(f):]
            sss += r

        sss += ss

        return sss

    else:
        return s


def expand_ausdruecke(satz):
    satz = case_indep_replace(satz, "  ", " ")
    satz = case_indep_replace(satz, "wie gehts mir", "wie gehts")
    satz = case_indep_replace(satz, "wie gehts", "wie gehts mir")
    satz = case_indep_replace(satz, "gehts", "geht es")
    satz = case_indep_replace(satz, "wieviel", "wie viel")
    satz = case_indep_replace(satz, "wie viel", "wie")
    satz = case_indep_replace(satz, "woher", "wo her")
    satz = case_indep_replace(satz, "was fr ", "was fuer ")
    satz = case_indep_replace(satz, "was fuer ein ", "was fuer einer ")
    satz = case_indep_replace(satz, "was fuer ein", "welch")
    satz = case_indep_replace(satz, "was fuer ", "welche ")
    satz = case_indep_replace(satz, "kennst du ", "was ist ")
    satz = case_indep_replace(satz, "kenne ich ", "was ist ")
    satz = case_indep_replace(satz, "kenne du ", "was ist ")
    satz = case_indep_replace(satz, "kennst ich ", "was ist ")
    satz = case_indep_replace(satz, "wie spaet", "wie Uhr")
    satz = case_indep_replace(satz, "C ", "Celsius ")
    satz = case_indep_replace(satz, "Grad C. ", "GradCelsius ")
    satz = case_indep_replace(satz, "Grad C ", "GradCelsius ")
    satz = case_indep_replace(satz, "Grad Celsius", "GradCelsius")
    satz = case_indep_replace(satz, "° Celsius", "GradCelsius")
    satz = case_indep_replace(satz, "°C", "GradCelsius")
    satz = case_indep_replace(satz, " how ", ", how ")
    satz = case_indep_replace(satz, " why ", ", why ")
    satz = case_indep_replace(satz, " which ", ", which ")
    satz = case_indep_replace(satz, " who ", ", who ")
    satz = case_indep_replace(satz, " that ", ", that ")
    satz = case_indep_replace(satz, " because ", ", because ")
    satz = case_indep_replace(satz, " weil ", ", weil ")
    satz = case_indep_replace(satz, " dass ", ", dass ")
    satz = case_indep_replace(satz, " falls ", ", falls ")
    satz = case_indep_replace(satz, " wenn ", ", wenn ")
    satz = case_indep_replace(satz, "  ", " ")
    satz = case_indep_replace(satz, ", , ", ", ")
    satz = case_indep_replace(satz, ",  , ", ", ")
    satz = case_indep_replace(satz, ",, ", ", ")
    satz = case_indep_replace("AHHIIILULOHUE" + satz, "AHHIIILULOHUE,", "")
    satz = case_indep_replace(satz, "AHHIIILULOHUE", "")
    satz = case_indep_replace(satz, "worin ", "in was ")
    satz = case_indep_replace(satz, "worauf ", "auf was ")
    satz = case_indep_replace(satz, "woran ", "an was ")
    satz = satz.replace(" im ", " in dem ")
    satz = case_indep_replace(satz, " and ", " und ")
    satz = case_indep_replace(satz, " or ", " oder ")
    satz = case_indep_replace(satz, " wozu ", " warum ")
    satz = case_indep_replace(satz, "wozu ", "warum ")
    satz = case_indep_replace(satz, " zu was ", " warum ")
    satz = case_indep_replace(satz, "zu was ", "warum ")
    satz = case_indep_replace(satz, " den selben ", " denselben ")
    satz = case_indep_replace(satz, " den gleichen ", " dengleichen ")
    satz = case_indep_replace(satz, " daran ", " ")
    satz = case_indep_replace(satz, " v. chr. ", " vor Christus ")
    satz = case_indep_replace(satz, " v chr ", " vor Christus ")
    satz = case_indep_replace(satz, " v. chr ", " vor Christus ")
    satz = case_indep_replace(satz, " v chr ", " vor Christus ")
    satz = case_indep_replace(satz, " vor chr. ", " vor Christus ")
    satz = case_indep_replace(satz, " vor chr ", " vor Christus ")
    satz = case_indep_replace(satz, " bitte ", " ")
    contains_zu_verb = len([ x for x in satz.split(" ") if cpp_detect_wordtype(x, False) == 2 and contains(x, "zu") ])
    if contains(satz, " zu ") or contains(satz, " to ") or contains_zu_verb:
        satz = case_indep_replace(satz, " faengt an, ", " ")
        satz = case_indep_replace(satz, " beginnt, ", " ")
        satz = case_indep_replace(satz, " fangen an, ", " ")
        satz = case_indep_replace(satz, " beginnen, ", " ")
        satz = case_indep_replace(satz, " started to ", " ")
        satz = case_indep_replace(satz, " began to ", " ")
        satz_ = satz[:]
        satz = []
        zu_eliminated = False
        for x in satz_.split(" "):
            if cpp_detect_wordtype(x, False) == 2 and contains(x, "zu") and not zu_eliminated:
                x = x.replace("zu", "", 1)
            if x == "zu" and not zu_eliminated:
                zu_eliminated = True
                continue
            satz.append(x)
        satz = " ".join(satz)
    satz = case_indep_replace(("--------" + satz), "--------ja, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------nein, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------doch, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------klar, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------yes, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------no, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------inwiefern ", "wie ").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------in wie fern ", "wie ").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------in wiefern ", "wie ").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------inwie fern ", "wie ").replace("--------", "")
    if len(satz) > 10:
        satz = case_indep_replace(("--------" + satz), "--------ja ", "").replace("--------", "")
        satz = case_indep_replace(("--------" + satz), "--------nein ", "").replace("--------", "")
        satz = case_indep_replace(("--------" + satz), "--------doch ", "").replace("--------", "")
        satz = case_indep_replace(("--------" + satz), "--------klar ", "").replace("--------", "")
        satz = case_indep_replace(("--------" + satz), "--------yes ", "").replace("--------", "")
        satz = case_indep_replace(("--------" + satz), "--------no ", "").replace("--------", "")
    print "satz:", satz

    satz = correct_time(satz)

    return satz


def expand_ausdruecke_orig(satz):
    satz = case_indep_replace(satz, "  ", " ")
    satz = case_indep_replace(satz, "wie gehts dir", "wie gehts")
    satz = case_indep_replace(satz, "wie gehts", "wie gehts dir")
    satz = case_indep_replace(satz, "gehts", "geht es")
    satz = case_indep_replace(satz, "wieviel", "wie viel")
    satz = case_indep_replace(satz, "wie viel", "wie")
    satz = case_indep_replace(satz, "woher", "wo her")
    satz = case_indep_replace(satz, "was fr ", "was fuer ")
    satz = case_indep_replace(satz, "was fuer ein ", "was fuer einer ")
    satz = case_indep_replace(satz, "was fuer ein", "welch")
    satz = case_indep_replace(satz, "was fuer ", "welche ")
    satz = case_indep_replace(satz, "kennst du ", "was ist ")
    satz = case_indep_replace(satz, "kenne ich ", "was ist ")
    satz = case_indep_replace(satz, "kenne du ", "was ist ")
    satz = case_indep_replace(satz, "kennst ich ", "was ist ")
    satz = case_indep_replace(satz, "wie spaet", "wie Uhr")
    satz = case_indep_replace(satz, "du spiele", "du spielst")
    satz = case_indep_replace(satz, "C ", "Celsius ")
    satz = case_indep_replace(satz, "Grad C. ", "GradCelsius ")
    satz = case_indep_replace(satz, "Grad C ", "GradCelsius ")
    satz = case_indep_replace(satz, "Grad Celsius", "GradCelsius")
    satz = case_indep_replace(satz, "° Celsius", "GradCelsius")
    satz = case_indep_replace(satz, "°C", "GradCelsius")
    satz = case_indep_replace(satz, " how ", ", how ")
    satz = case_indep_replace(satz, " why ", ", why ")
    satz = case_indep_replace(satz, " which ", ", which ")
    satz = case_indep_replace(satz, " who ", ", who ")
    satz = case_indep_replace(satz, " that ", ", that ")
    satz = case_indep_replace(satz, " because ", ", because ")
    satz = case_indep_replace(satz, " weil ", ", weil ")
    satz = case_indep_replace(satz, " dass ", ", dass ")
    satz = case_indep_replace(satz, " falls ", ", falls ")
    satz = case_indep_replace(satz, " wenn ", ", wenn ")
    satz = case_indep_replace(satz, "  ", " ")
    satz = case_indep_replace(satz, ", , ", ", ")
    satz = case_indep_replace(satz, ",  , ", ", ")
    satz = case_indep_replace(satz, ",, ", ", ")
    satz = case_indep_replace("AHHIIILULOHUE" + satz, "AHHIIILULOHUE,", "")
    satz = case_indep_replace(satz, "AHHIIILULOHUE", "")
    satz = case_indep_replace(satz, "worin ", "in was ")
    satz = case_indep_replace(satz, "worauf ", "auf was ")
    satz = case_indep_replace(satz, "woran ", "an was ")
    satz = case_indep_replace(satz, " im ", " in dem ")
    satz = case_indep_replace(satz, " and ", " und ")
    satz = case_indep_replace(satz, " or ", " oder ")
    satz = case_indep_replace(satz, " wozu ", " warum ")
    satz = case_indep_replace(satz, "wozu ", "warum ")
    satz = case_indep_replace(satz, " zu was ", " warum ")
    satz = case_indep_replace(satz, "zu was ", "warum ")
    satz = case_indep_replace(satz, " den selben ", " denselben ")
    satz = case_indep_replace(satz, " den gleichen ", " dengleichen ")
    satz = case_indep_replace(satz, " daran ", " ")
    satz = case_indep_replace(satz, " v. chr. ", " vor Christus ")
    satz = case_indep_replace(satz, " v chr ", " vor Christus ")
    satz = case_indep_replace(satz, " v. chr ", " vor Christus ")
    satz = case_indep_replace(satz, " v chr ", " vor Christus ")
    satz = case_indep_replace(satz, " vor chr. ", " vor Christus ")
    satz = case_indep_replace(satz, " vor chr ", " vor Christus ")
    satz = case_indep_replace(satz, " bitte ", " ")
    contains_zu_verb = len([ x for x in satz.split(" ") if cpp_detect_wordtype(x, False) == 2 and contains(x, "zu") ])
    if contains(satz, " zu ") or contains(satz, " to ") or contains_zu_verb:
        satz = case_indep_replace(satz, " faengt an, ", " ")
        satz = case_indep_replace(satz, " beginnt, ", " ")
        satz = case_indep_replace(satz, " fangen an, ", " ")
        satz = case_indep_replace(satz, " beginnen, ", " ")
        satz = case_indep_replace(satz, " started to ", " ")
        satz = case_indep_replace(satz, " began to ", " ")
        satz_ = satz[:]
        satz = []
        zu_eliminated = False
        for x in satz_.split(" "):
            if cpp_detect_wordtype(x, False) == 2 and contains(x, "zu") and not zu_eliminated:
                x = x.replace("zu", "", 1)
            if x == "zu" and not zu_eliminated:
                zu_eliminated = True
                continue
            satz.append(x)
        satz = " ".join(satz)
    satz = case_indep_replace(("--------" + satz), "--------ja, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------nein, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------doch, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------klar, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------yes, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------no, ", "").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------inwiefern ", "wie ").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------in wie fern ", "wie ").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------in wiefern ", "wie ").replace("--------", "")
    satz = case_indep_replace(("--------" + satz), "--------inwie fern ", "wie ").replace("--------", "")
    if len(satz) > 10:
        satz = case_indep_replace(("--------" + satz), "--------ja ", "").replace("--------", "")
        satz = case_indep_replace(("--------" + satz), "--------nein ", "").replace("--------", "")
        satz = case_indep_replace(("--------" + satz), "--------doch ", "").replace("--------", "")
        satz = case_indep_replace(("--------" + satz), "--------klar ", "").replace("--------", "")
        satz = case_indep_replace(("--------" + satz), "--------yes ", "").replace("--------", "")
        satz = case_indep_replace(("--------" + satz), "--------no ", "").replace("--------", "")

    satz = correct_time(satz)

    return satz

def enthaeltNegation(satz):
    if (contains(" " + satz + " ", " nicht ") or contains(" " + satz + " ", " nich ") or
            contains(" " + satz + " ", " kein ") or contains(" " + satz + " ", " keine ") or
            contains(" " + satz + " ", " kein")):
        return True
    return False

def ohne_artikel(_satz):
    satz = _satz[:]
    satz = satz.split(" ")
    arts = [ "der", "die", "das", "dem", "den", "ein", "eine", "einer", "einen", "eines", "the" ]
    satz = [ s for s in satz if s.lower() not in arts ]
    return " ".join(satz)

prepositions = ['in', 'auf', 'an', 'neben', 'zwischen', 'nach', 'vor', 'unten', 'oben', 'links', 'rechts', 'zu', 'ab', 'aus', 'von', 'an', 'auf', 'auer', 'ausser', 'bei', 'gegenueber', 'gegenber', 'hinter', 'in', 'neben', 'ber', 'ueber', 'unter', 'vor', 'zwischen', 'auerhalb', 'ausserhalb', 'diesseits', 'inmitten', 'innerhalb', 'jenseits', 'laengs', 'lngs', 'oberhalb', 'unterhalb', 'unweit', 'ab', 'bei', 'mit', 'nach', 'von', 'vor', 'zu', 'zwischen', 'um', 'angesichts', 'anlaesslich', 'anlsslich', 'auf', 'aus', 'bei', 'betreffs', 'bezueglich', 'bezglich', 'dank', 'durch', 'fuer', 'fr', 'gemaess', 'gem', 'gemae', 'gemss', 'halber', 'infolge', 'mangels', 'mittels', 'nach', 'seitens', 'trotz', 'um', 'unbeschadet', 'ungeachtet', 'unter', 'vermittels', 'zufolgen', 'zwecks', 'abzueglich', 'abzglich', 'ausschliesslich', 'ausschlielich', 'ausser', 'auer', 'bis', 'an', 'einschliesslich', 'einschlielich', 'entgegen', 'exklusive', 'gegen', 'gegenueber', 'gegenber', 'inklusive', 'mit', 'mitsamt', 'nebst', 'ohne', 'samt', 'statt', 'anstatt', 'zum', 'am', 'beim', 'nebem', 'im', 'zur']

arts = [ "der", "die", "das", "dem", "den", "welcher", "welche", "welches", "welchen", "who", "which", "that" ]

konj = [ "wenn", "falls", "if", "when" ]

from defs import get_lang
to_do_file = "lang_" + get_lang() + "/to_do.xml"
def read_to_do_file():
    lines = []
    try:
        fp = open(to_do_file, "r")
        lines = fp.readlines()
        fp.close()
    except IOError:
        ''
    try:
        lines = lines[3:] # XML-Header abschneiden
    except:
        ''
    lines = "\n".join(lines)
    lines = lines.replace("\r", "")
    lines = lines.replace("\n\n", "\n")
    lines = lines.replace("</to_do>", "")
    lines = lines.replace("<to_do>", "")
    lines = lines.replace("<to>", "")
    lines = lines.replace("</do>", "")
    lines = lines.replace("<pair>", "")
    lines = lines.replace("</to>\n<do>", "SCHNIPPS")
    lines = lines.strip()
    lines = lines.split("</pair>")
    to_do_pairs = [ [ o.strip() for o in l.split("SCHNIPPS") ] for l in lines if len(l) > 0 ]
#    print to_do_pairs
    return to_do_pairs

def write_to_do_file(to_do_pairs):
    fp = open(to_do_file, "w")

    fp.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n\n<to_do>\n")

    for (to, do) in to_do_pairs:
        fp.write("<pair>\n")
        fp.write("<to>" + to + "</to>\n")
        fp.write("<do>" + do + "</do>\n")
        fp.write("</pair>\n")

    fp.write("</to_do>")

    fp.close()


priority_pairs = []
priority_file = "lang_" + get_lang() + "/priorities.xml"

def read_priority_file():
    lines = []
    try:
        fp = open(priority_file, "r")
        lines = fp.readlines()
        fp.close()
    except IOError:
        ''
    try:
        lines = lines[3:] # XML-Header abschneiden
    except:
        ''
    lines = "\n".join(lines)
    lines = lines.replace("\r", "")
    lines = lines.replace("\n\n", "\n")
    lines = lines.replace("</group>", "")
    lines = lines.replace("<group>", "")
    lines = lines.replace("<exp>", "")
    lines = lines.replace("</prio>", "")
    lines = lines.replace("<part>", "")
    lines = lines.replace("</exp>\n<prio>", "SCHNIPPS")
    lines = lines.strip()
    lines = lines.split("</part>")
    priority_pairs = [ [ o.strip() for o in l.split("SCHNIPPS") ] for l in lines if len(l) > 0 ]
#    print priority_pairs
    return priority_pairs

def write_priority_file(priority_pairs):
    fp = open(priority_file, "w")

    fp.write("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n\n<group>\n")

    for (to, do) in priority_pairs:
        fp.write("<part>\n")
        fp.write("<exp>" + to + "</exp>\n")
        fp.write("<prio>" + do + "</prio>\n")
        fp.write("</pair>\n")

    fp.write("</group>")

    fp.close()

from httplib import HTTPConnection

def download_weather(city):
    import re, sys
    cities = []
    for x in xrange(0, 30):
        sys.stdout.write(".")
        sys.stdout.flush()
#        print "1"
        apply_procent(100.0 / 31.0 * (x+1))
        http = HTTPConnection("www.accuweather.com", 80)
#        print "2"
        http.connect()
#        print "3"
        if len(str(x)) == 1:
            x = "0" + str(x)
#        print "4"
        http.putrequest("GET", "/world-index-forecast.asp?partner=forecastfox&locCode=EUR|DE|GM0" + str(x) + "|" + city.upper().replace(" ", "%20") + "|&u=1")
#        print "5"
        x = int(x)
        http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
#        print "6"
        http.endheaders()
#        print "7"
        lines = str(http.getresponse().read().replace("\r", "")).split("\n")
#        print "8"


        title = "".join([ t for t in lines if re.search("cityTitle", t) ])
#        print "9"
        reg = re.compile(".*?<.*?><.*?>(.*?)<.*?><.*?>.*?")
#        print "10"
        title = reg.sub("\\1", title)
#        print "11"

        weather = "".join([ t for t in lines if re.search("quicklook_current_wxtext", t) ])
#        print "12"
        weather = weather.replace('<div id="quicklook_current_wxtext">', '')
#        print "13"
        weather = weather.replace('</div>', '')
#        print "14"
        weather = weather.strip();
#        print "15"

        temperatur = "".join([ t for t in lines if re.search("quicklook_current_temps", t) ])
#        print "16"
        temperatur = temperatur.replace('<div id="quicklook_current_temps">', '')
#        print "17"
        temperatur = temperatur.replace('</div>', '')
#        print "18"
        temperatur = temperatur.replace("&deg;C", " GradCelsius");
#        print "19"
        temperatur = temperatur.strip();
#        print "20"

        humidity = "".join([ t for t in lines if re.search("Humidity:", t) ])
#        print "21"
        humidity = humidity.replace('Humidity:', '')
#        print "22"
        humidity = humidity.replace('<br />', '')
#        print "23"
        humidity = humidity.strip();
#        print "24"

        if not len(title):
            continue
        t = (title, weather, temperatur, humidity)
        if t not in cities:
            cities.append(t)

    from defs import db_sentence

    ret = []

    for (title, weather, temperatur, humidity) in cities:
        title = title.split(",")[0]
        dbs1 = db_sentence()
        dbs2 = db_sentence()
        dbs3 = db_sentence()
        dbs4 = db_sentence()
        dbs5 = db_sentence()
        dbs6 = db_sentence()
        dbs7 = db_sentence()
        dbs8 = db_sentence()
        dbs9 = db_sentence()
        dbs10 = db_sentence()
        dbs11 = db_sentence()

        dbs1.verb = "ist"
        dbs1.parts = ["das wetter {}", " ".join((weather, "{}"))]
        dbs1.advs = [" ".join(("in", title))]

        dbs2.verb = "ist"
        dbs2.parts = ["es {}", " ".join((temperatur, "{warm}"))]
        dbs2.advs = [" ".join(("in", title))]

        dbs3.verb = "ist"
        dbs3.parts = ["es {}", " ".join((temperatur, "{kalt}"))]
        dbs3.advs = [" ".join(("in", title))]

        dbs4.verb = "sein"
        dbs4.parts = ["es {}", " ".join((temperatur, "{}"))]
        dbs4.advs = [" ".join(("in", title))]

        dbs5.verb = "sein"
        dbs5.parts = ["die temperatur {}", " ".join((temperatur, "{}"))]
        dbs5.advs = [" ".join(("in", title))]

        dbs6.verb = "sein"
        dbs6.parts = ["die temperatur {}", " ".join((temperatur, "{warm}"))]
        dbs6.advs = [" ".join(("in", title))]

        dbs7.verb = "sein"
        dbs7.parts = ["die temperatur {}", " ".join((temperatur, "{kalt}"))]
        dbs7.advs = [" ".join(("in", title))]

        dbs8.verb = "sein"
        dbs8.parts = ["die Luftfeuchtigkeit {}", " ".join((humidity, "{}"))]
        dbs8.advs = [" ".join(("in", title))]

        dbs9.verb = "sein"
        dbs9.parts = ["the humidity {}", " ".join((humidity, "{}"))]
        dbs9.advs = [" ".join(("in", title)), " ".join(("at", title))]

        dbs10.verb = "sein"
        dbs10.parts = ["the temperature {}", " ".join((temperatur, "{}"))]
        dbs10.advs = [" ".join(("in", title)), " ".join(("at", title))]

        dbs11.verb = "sein"
        dbs11.parts = ["the weather {}", " ".join((weather, "{}"))]
        dbs11.advs = [" ".join(("in", title)), " ".join(("at", title))]

        r = [dbs1, dbs2, dbs3, dbs4, dbs5, dbs6, dbs7, dbs8, dbs9, dbs10, dbs11]
        for rr in r:
            rr.subject = rr.parts[0]
            rr.object = " ".join(rr.advs + rr.parts[1:])
            rr.print_parts()

        ret += r

    print
    print cities

    return ret

def verb_remove_prefixes(n):
    prepositions = ['in', 'auf', 'an', 'neben', 'zwischen', 'nach', 'vor', 'unten', 'oben', 'links', 'rechts', 'zu', 'ab', 'aus', 'von', 'an', 'auf', 'auer', 'ausser', 'bei', 'gegenueber', 'gegenber', 'hinter', 'in', 'neben', 'ber', 'ueber', 'unter', 'vor', 'zwischen', 'auerhalb', 'ausserhalb', 'diesseits', 'inmitten', 'innerhalb', 'jenseits', 'laengs', 'lngs', 'oberhalb', 'unterhalb', 'unweit', 'ab', 'bei', 'mit', 'nach', 'von', 'vor', 'zu', 'zwischen', 'um', 'angesichts', 'anlaesslich', 'anlsslich', 'auf', 'aus', 'bei', 'betreffs', 'bezueglich', 'bezglich', 'dank', 'durch', 'fuer', 'fr', 'gemaess', 'gem', 'gemae', 'gemss', 'halber', 'infolge', 'mangels', 'mittels', 'nach', 'seitens', 'trotz', 'um', 'unbeschadet', 'ungeachtet', 'unter', 'vermittels', 'zufolgen', 'zwecks', 'abzueglich', 'abzglich', 'ausschliesslich', 'ausschlielich', 'ausser', 'auer', 'bis', 'an', 'einschliesslich', 'einschlielich', 'entgegen', 'exklusive', 'gegen', 'gegenueber', 'gegenber', 'inklusive', 'mit', 'mitsamt', 'nebst', 'ohne', 'samt', 'statt', 'anstatt', 'zum', 'am', 'beim', 'nebem', 'im', 'zur']
    first = []
    parr = [ "ge" ] + prepositions
    for x in range(1, 5):
        for p in parr:
#            print "n:", n
            _n = ("-" + n).replace("-" + p, "-", 1).replace("-", "")
            if _n != n:
                first.append(p)
            n = _n[:]
        for p in first:
            try: parr.remove(p)
            except ValueError: pass

    n = n.replace("-", "")
#    print "first:", first
    return n, first

def without_passive(_s):
    s = _s[:].replace(".", "").replace("?", " ? ").replace("  ", " ")
    s = s.split(" ")
#    print s
    prepositions = ['in', 'auf', 'an', 'neben', 'zwischen', 'nach', 'vor', 'unten', 'oben', 'links', 'rechts', 'zu', 'ab', 'aus', 'von', 'an', 'auf', 'auer', 'ausser', 'bei', 'gegenueber', 'gegenber', 'hinter', 'in', 'neben', 'ber', 'ueber', 'unter', 'vor', 'zwischen', 'auerhalb', 'ausserhalb', 'diesseits', 'inmitten', 'innerhalb', 'jenseits', 'laengs', 'lngs', 'oberhalb', 'unterhalb', 'unweit', 'ab', 'bei', 'mit', 'nach', 'von', 'vor', 'zu', 'zwischen', 'um', 'angesichts', 'anlaesslich', 'anlsslich', 'auf', 'aus', 'bei', 'betreffs', 'bezueglich', 'bezglich', 'dank', 'durch', 'fuer', 'fr', 'gemaess', 'gem', 'gemae', 'gemss', 'halber', 'infolge', 'mangels', 'mittels', 'nach', 'seitens', 'trotz', 'um', 'unbeschadet', 'ungeachtet', 'unter', 'vermittels', 'zufolgen', 'zwecks', 'abzueglich', 'abzglich', 'ausschliesslich', 'ausschlielich', 'ausser', 'auer', 'bis', 'an', 'einschliesslich', 'einschlielich', 'entgegen', 'exklusive', 'gegen', 'gegenueber', 'gegenber', 'inklusive', 'mit', 'mitsamt', 'nebst', 'ohne', 'samt', 'statt', 'anstatt', 'zum', 'am', 'beim', 'nebem', 'im', 'zur']

#    print "len([ True for n in s if cpp_detect_wordtype(n, o == 0) == 2 and len(n) > 6 and \"ge\" in verb_remove_prefixes(n)[1] ]):", len([ True for n in s if cpp_detect_wordtype(n, False) == 2 and len(n) > 6 and "ge" in verb_remove_prefixes(n)[1] ])

    if len([ True for n in s if n.lower() in ("wird", "werde", "werden", "werdet", "werdst") ]) and len([ True for n in s if cpp_detect_wordtype(n, False) == 2 and len(n) > 6 and ("ge" in verb_remove_prefixes(n)[1] or n.startswith("er")) ]):
#        print "passive!"
#        print
#        print "passive to active:"
#        print "  passive:", s
#        print

        s = [ n for n in s if n.lower() not in ("wird", "werde", "werden", "werdet", "werdst") ]
        s_new = [ ]
        subj = [ ]
        in_von = False
        o = -1
        for n in s:
            o += 1
            if cpp_detect_wordtype(n, o == 0) == 2 and (contains(n, "ge") or n.startswith("er")) and len(n) > 6:
                first = []
                n = "-" + n

                n, first = verb_remove_prefixes(n)

                n = "".join([ f for f in first if f not in ("ge") ]) + n
#            print "cpp_detect_wordtype:", 4
            if cpp_detect_wordtype(n, o == 0) == 2 and len(n) > 6:
                n = n.replace("ge", "", 1)
            if n.lower() == "von":
                in_von = True
                continue
            if in_von:
                subj.append(n)
                continue
#            print "cpp_detect_wordtype:", 5
            if cpp_detect_wordtype(n, o == 0) == 3:
                in_von = False
            if not in_von:
                s_new.append(n)
        if not len(subj):
            subj.append("_")

#        print "  active:"
#        print "    subject:", subj
#        print "    object: ", s_new
        return " ".join(subj + s_new)



#    print "active!"
#    print
    return " ".join(s)

def extract_vorgehensweise(s, learn):
    ret = [ [], [] ]
    tmp = []
    sents = []
    s = s.replace(", ", ",")
    s = s.replace(" ,", ",")
    sents = s.split(",")
    in_vorgehensweise = True
    o = -1
    for se in sents:
        o += 1
        se = se.split(" ")
        if len(se):
            if se[0].lower() == "um":
                in_vorgehensweise = False
            if len(se) >= 2:
#                print "cpp_detect_wordtype:", 6
                if se[0].lower() == "to" and cpp_detect_wordtype(se[1], False) == 2:
                    in_vorgehensweise = False

        if not in_vorgehensweise:
#            print "cpp_detect_wordtype:", 7
            if cpp_detect_wordtype(se[0].lower(), o == 0) != 5 and cpp_detect_wordtype(se[0].lower(), o == 0) != 7 and se[0].lower() not in konj:
                in_vorgehensweise = True

        if not in_vorgehensweise:
            ret[0].append(" ".join(se))
        if in_vorgehensweise:
            ret[1].append(" ".join(se))

    ret[0] = ", ".join([ without_passive(x) for x in ret[0] ])
    ret[1] = ", ".join([ without_passive(x) for x in ret[1] ])

    if not len(ret[0]):
        return ret[1]

    import re
    r1 = [
             [ re.compile("um\s(.*?\s*?[a-zA-Z]*?)zu", re.IGNORECASE), "\\1" ],
             [ re.compile("to\s", re.IGNORECASE), "" ],
         ]
    r2 = [
             [ re.compile("(musst|muessen|muss|muesse|musse|mussst)\s", re.IGNORECASE), "" ],
             [ re.compile("(hat|haben|hast|habe|habt)\s(.*?\s[a-zA-Z]*?)zu", re.IGNORECASE), "\\2" ],
             [ re.compile("(must|have|has|need|might|could)\s[t]*?[o]*?\s", re.IGNORECASE), "" ],
         ]
    for (e, s) in r1:
        ret[0] = e.sub(s, ret[0])
        ret[0] = ret[0].replace("  ", " ").strip()
    for (e, s) in r2:
        ret[1] = e.sub(s, ret[1])
        ret[1] = ret[1].replace("  ", " ").strip()
#    if learn:
    if 1:
        to_do_pairs = read_to_do_file()
        if ret not in to_do_pairs:
            to_do_pairs += [ret]
#        print to_do_pairs
        write_to_do_file(to_do_pairs)

    if len(ret[1]) <= 3:
        ret[1] = " ".join([ "man", "muss" ] + ret[1].split(" "))

    return ret[1]


def split_subclause(_fra):
    fra = _fra[:].strip()
    arts = [ "der", "die", "das", "dem", "den", "welcher", "welche", "welches", "welchen", "who", "which", "that" ]

    fra = fra.replace(", ", ",")
    fra = fra.replace(" ,", ",")
    fra = fra.replace(",", " , ")
    fra = fra.split(" , ")

    index = [ [], [] ]

    last = []
    do_komma_davor = True
    o = -1
    for actu in fra:
        o += 1
        actu = actu.strip().split(" ")

        if not len(actu):
            continue
#        print "cpp_detect_wordtype(", actu[0].lower(), "):", cpp_detect_wordtype(actu[0].lower(), o == 0)
#        print "actu:", actu
#        print   ( len([ x for x in actu[0:2] if x.lower() in arts ]) > 0 and cpp_detect_wordtype(actu[0].lower(), o == 0) == 5,
#                  "or",
#                  actu[0].lower() in arts
#                )

        if len(actu) >= 2:
            if  (
                    (
                        len([ x for x in actu[0:2] if x.lower() in arts ]) > 0
                        and cpp_detect_wordtype(actu[0].lower(), o == 0) == 5
                    )
                    or
                    (
                        actu[0].lower() in arts
                    )
                ):

                vorher = []
                for act in actu:
                    if act.lower() in arts:
                        actu.remove(act)
                        break
                    else:
                        vorher.append(act[:])

                    actu.remove(act)

                subjekt = []
                last.reverse()
                for las in last:
                    wa = int(cpp_detect_wordtype(las, False))
                    if len(subjekt):
                        if wa == 3:
                            break
                    subjekt.append(las)
                subjekt.reverse()

                index[1].append(" ".join(vorher + subjekt + actu))

#                print "index-", index

                do_komma_davor = False
            else:
                if do_komma_davor and len(index[0]):
                    index[0] += [ ss for ss in ([","] + actu[:]) if len(ss.strip()) ]
                else:
                    index[0] += [ ss for ss in (actu[:]) if len(ss.strip()) ]
                do_komma_davor = True
                last = actu[:]
                continue
        else:
            if do_komma_davor and len(index[0]):
                index[0] += [ ss for ss in ([","] + actu[:]) if len(ss.strip()) ]
            else:
                index[0] += [ ss for ss in (actu[:]) if len(ss.strip()) ]
            do_komma_davor = True
            last = actu[:]
            continue


        last = actu[:]

    index[0] = " ".join(index[0])

#    print "index", index

    if not len(index[0]):
        index[0] = ", ".join(fra)

    return index

def until_komma(_s):
    m = []
    for n in _s[:]:
        if n.strip() in (",", ".", "!", "?"):
            break
        m.append(n)
    return m[:]

def until_verb(_s, fn):
    m = []
    in_adv = False
    for n in _s[:]:
        wa = cpp_detect_wordtype(n.strip(), False)
        if n.strip() in ("und", "oder", "or", "and"):
            return False
        if wa in (5,):
            in_adv = True
        if in_adv and wa == 3 and wa not in fn:
            in_adv = False
        if not in_adv:
            m.append(n)
            if wa == 2:
                break
            if wa == 3:
                return False
    return m[:]

def back_to_wordtype_X(_s, x):
    m = []
    __s = _s[:]
    __s.reverse()
    for n in __s:
        print "n:", n, "in", __s
        if n.strip() in ("und", "oder", "or", "and"):
            return False
        m.append(n)
        if cpp_detect_wordtype(n.strip(), False) == x:
            break
    m.reverse()
    return m[:]

def extract_to_do(sent, learn = True):
    if get_lang() == "de":
        sent = extract_vorgehensweise(sent, learn)
    sent = sent.replace(",", " , ").replace("  ", " ")
    is_question = False
    if contains(sent, "?"):
        is_question = True
        sent = sent.replace("?", "")
    ___s = sent[:].split(" ")
    tmp = [ [] ]
    ___s_s = [ "" ]
    a = 0
    todo = [[]]
    s = []
    n = -1
    is_in_to = False
    no_zu = False
    fn = get_first_names()
    conjunction = []

    while n+1 < len(___s):
        n += 1

        if ___s[n].strip() in ("und", "oder", "or", "and"):
            if n+1 < len(___s):
                temp = until_verb(___s[n+1:], fn)

                subj_is_missing = False
                if n+1 < len(___s):
                    if cpp_detect_wordtype(___s[n+1], False) == 2:
                        subj_is_missing = True

                ### HIER WEITERMACHEN
                in_adv = False
                for tm in ___s[n+1:]:
                    wa = cpp_detect_wordtype(tm, False)
                    print "-->->", tm, wa
                    if wa in (4,):
                        continue
                    if wa in (5,):
                        in_adv = True
                    if in_adv and wa == 3 and wa not in fn:
                        in_adv = False
                    print "-->", tm, wa
                    if not in_adv:
                        if wa == 2:
                            subj_is_missing = True
                        break



                there_is_a_conjunction = False
                if len(tmp[a]) >= 2:
                    if cpp_detect_wordtype(tmp[a][1], False) == 8:
                        there_is_a_conjunction = True
                        conjunction = [ tmp[a][1] ]
                if len(tmp[a]) >= 3:
                    if cpp_detect_wordtype(tmp[a][2], False) == 8:
                        there_is_a_conjunction = True
                        conjunction = [ tmp[a][1], tmp[a][2] ]
                if len(tmp[a]) >= 4:
                    if cpp_detect_wordtype(tmp[a][3], False) == 8:
                        there_is_a_conjunction = True
                        conjunction = [ tmp[a][1], tmp[a][2], tmp[a][3] ]

                if not temp:
                    if ___s[n] not in conjunction:
                        tmp[a].append(___s[n])
                elif "," not in temp and back_to_wordtype_X(___s[:n+1], 2) != ___s[:n+1]:
                    tmp.append([","])
                    if there_is_a_conjunction:
                        tmp[a+1] += conjunction
                    if subj_is_missing:
                        to_be_added_to_tmp_a_plus_one = []
                        for tm in tmp[a]:
                            wa = cpp_detect_wordtype(tm, False)
                            print "cpp_detect_wordtype(", tm, ", ", False, ")", wa
                            if wa == 2:
                                break
                            if wa == 8:
                                tmp[a+1] = [","]
                            to_be_added_to_tmp_a_plus_one.append(tm)
                            if wa in (3, 6) and tm not in fn:
                                break
                                ### Hier Weitermachen!
                        tmp[a+1] += to_be_added_to_tmp_a_plus_one
                    print "added to tmp:", tmp[a+1]
                    a += 1
                else:
                    if ___s[n] not in conjunction:
                        tmp[a].append(___s[n])
            else:
                if ___s[n] not in conjunction:
                    tmp[a].append(___s[n])
        elif ___s[n].strip() in (","):
            ___s_s_ = ___s_s[:]
            ___s_s = []
            for tm in tmp:
#                tm = [___s[n]] + tm
                for ss in ___s_s_:
                    ___s_s.append((" ".join([ss] + tm)).strip())
            tmp = [ [","] ]
            conjunction = []
            a = 0
        else:
            print "tmp:", tmp
            print "a:", a
            print "___s:", ___s
            print "n:", n

            tmp[a].append(___s[n])

    if len(tmp):
        ___s_s_ = ___s_s[:]
        ___s_s = []
        for tm in tmp:
#            tm = [___s[n]] + tm
            for ss in ___s_s_:
                ___s_s.append((" ".join([ss] + tm)).strip())

    ___s_s = [ x.replace(", ,", ",").replace("und ,", ",").replace("or ,", ",").replace("and ,", ",").replace("oder ,", ",") for x in ___s_s ]

    print "___s_s:", ___s_s
#    exit(0)

    ret_ = []
    for __s in ___s_s:
        __s = __s.split(" ")
        todo = [[]]
        s = []
        n = 0
        is_in_to = False
        no_zu = False
        while n < len(__s):
            if __s[n].lower() == "to":
                if n+1 < len(__s):
                    wa = cpp_detect_wordtype(__s[n+1], False)
                    if wa == 2:
                        is_in_to = True
                        if len(todo):
                            todo.append([])
                        n += 1
                        continue

            if __s[n].strip() in (","):
                print "until_komma(__s[n:]):", until_komma(__s[n+1:])
                print "n:", n
                print "__s:", __s
                i = 0
                for c in until_komma(__s[n+1:]):
                    i += 1
                    print "c:", c
                    print "c in (\"to\", \"zu\"):", c in ("to", "zu") or (cpp_detect_wordtype(c, False) == 2 and contains(c, "zu"))
                    print "if n+i+1 < len(__s):", n+i+1 < len(__s)
                    if c in ("to", "zu") or (cpp_detect_wordtype(c, False) == 2 and contains(c, "zu")):

#        if __s[n].lower() in ("to", "zu"):
                        if n+i+1 < len(__s):
                            wa = cpp_detect_wordtype(__s[n+i+1], False)
    #                        print "__s[n+i+1]:", __s[n+i+1], "wa:", wa
                            if wa == 2:
    #                            print "is_in_to:", is_in_to
                                is_in_to = True
                                if len(todo):
                                    todo.append([])
                                n += 1
                                no_zu = True
                                continue
                        elif n+i+1 == len(__s):
                            is_in_to = True
                            if len(todo):
                                todo.append([])
                            n += 1
                            no_zu = True
                            continue
            if __s[n].lower() == "zu":
                if n+1 < len(__s):
                    wa = cpp_detect_wordtype(__s[n+1], False)
                    if wa == 2:
                        is_in_to = True
                        if len(todo):
                            todo.append([])
                        n += 1
                        continue
    #        if no_zu and __s[n] in ("zu"):
    #            n += 1
    #            continue
            if is_in_to:
                todo[len(todo)-1].append(__s[n])
            else:
                s.append(__s[n])
            n += 1

        todo = [ " ".join(x) for x in todo if len("".join(x).strip()) > 0 ]
        print
        print "s:", s
        print "todo:", todo
        if not len(todo):
            if is_question:
                s.append("?")
            ret_.append(" ".join(s))
            continue
        if is_question:
            todo.append("?")
        ret_.append((without_passive(" ".join(s)) + ", __TO__ " + without_passive(" ".join(todo))))
    return ret_


def saetze_einzeln(_s, learn):
    mainclauses = []
    questions = []
    tmp = []

    s = _s[:]
    s = extract_vorgehensweise(s, learn)
    s = s.replace("!", ".")
    s = s.replace(". ", ".")
    s = s.replace(" .", ".")
    s = s.replace(".", " . ")
    s = s.replace("? ", "?")
    s = s.replace(" ?", "?")
    s = s.replace("?", " ? ")
    s = s.split(" ")

    from defs import get_lang
    from jelizacpp import cpp_detect_wordtype

    for word in s:
        if word == "?":
            questions.append(" ".join(tmp) + word)
            tmp = []
        elif word == ".":
            mainclauses.append(" ".join(tmp) + word)
            tmp = []
        else:
            tmp.append(word)
    if len(tmp):
        mainclauses.append(" ".join(tmp))
        tmp = []



    if len(questions) == 0:
        a = [[], []]
        for x in mainclauses:
            a[0] += extract_to_do(x, learn)

        return a

    a = [[], []]
    for x in questions:
        a[0] += extract_to_do(x, learn)
    for x in mainclauses:
        a[1] += extract_to_do(x, learn)

    return a



def read_jeliza_db(file):
    import re
    from defs import db_sentence

    content = ""
    try:
        fp = open(file, "r")
        content = fp.read()
        fp.close()
    except IOError:
        pass

    r1 = re.compile("<[?]+?xml(.*?)>", re.IGNORECASE)
    content = r1.sub("", content).strip()

    content = content.replace("\r", "<")
    content = content.replace("\n", "<")
    content = content.replace(">", "<")
    content = content.split("<")
    content = [ c.strip() for c in content ]
    content = [ c for c in content if len(c) ]

#    print content

    act_sent_vor_sub = [ db_sentence() ]
    act_sent = [ db_sentence() ]
    sub_mode = False
    sentences = []

    do_continue = False
    old_line = ""
    contains_slash = re.compile("[/]")
    for line in content:
        if old_line == "priority" and not contains_slash.search(line):
            try: act_sent[len(act_sent)-1].priority = int(line)
            except: act_sent[len(act_sent)-1].priority = 50

        if old_line == "subject" and not contains_slash.search(line):
            act_sent[len(act_sent)-1].subject = line
        if old_line == "verb" and not contains_slash.search(line):
            act_sent[len(act_sent)-1].verb = line
        if old_line == "object" and not contains_slash.search(line):
            act_sent[len(act_sent)-1].object = line
        if old_line == "feeling" and not contains_slash.search(line):
            act_sent[len(act_sent)-1].feeling = line
        if old_line == "prefix" and not contains_slash.search(line):
            act_sent[len(act_sent)-1].prefix = line
        if old_line == "suffix" and not contains_slash.search(line):
            act_sent[len(act_sent)-1].suffix = line
        if old_line == "category" and not contains_slash.search(line):
            act_sent[len(act_sent)-1].category = line
        if old_line == "additional" and not contains_slash.search(line):
            act_sent[len(act_sent)-1].additional = line
        if old_line == "quesword" and not contains_slash.search(line):
            act_sent[len(act_sent)-1].quesword = line
        if line == "/fact":
            if not sub_mode:
                act_sent[len(act_sent)-1].strip()
                dbs = db_sentence()
                dbs.copy(act_sent[len(act_sent)-1])
                sentences.append(dbs)
                act_sent.append(db_sentence())
        if line == "/sub":
            act_sent[len(act_sent)-1].strip()
            dbs = db_sentence()
            dbs.copy(act_sent[len(act_sent)-1])
            if not act_sent_vor_sub[len(act_sent_vor_sub)-1].has1_sub:
                act_sent_vor_sub[len(act_sent_vor_sub)-1].has1_sub = True
                act_sent_vor_sub[len(act_sent_vor_sub)-1].sub1 = dbs
            elif not act_sent_vor_sub[len(act_sent_vor_sub)-1].has2_sub:
                act_sent_vor_sub[len(act_sent_vor_sub)-1].has2_sub = True
                act_sent_vor_sub[len(act_sent_vor_sub)-1].sub2 = dbs
            elif not act_sent_vor_sub[len(act_sent_vor_sub)-1].has3_sub:
                act_sent_vor_sub[len(act_sent_vor_sub)-1].has3_sub = True
                act_sent_vor_sub[len(act_sent_vor_sub)-1].sub3 = dbs
            elif not act_sent_vor_sub[len(act_sent_vor_sub)-1].has4_sub:
                act_sent_vor_sub[len(act_sent_vor_sub)-1].has4_sub = True
                act_sent_vor_sub[len(act_sent_vor_sub)-1].sub4 = dbs
            elif not act_sent_vor_sub[len(act_sent_vor_sub)-1].has5_sub:
                act_sent_vor_sub[len(act_sent_vor_sub)-1].has5_sub = True
                act_sent_vor_sub[len(act_sent_vor_sub)-1].sub5 = dbs
            act_sent.append(db_sentence())
            act_sent[len(act_sent)-1].copy(act_sent_vor_sub[len(act_sent_vor_sub)-1])
            sub_mode = False
        if line == "sub":
            act_sent_vor_sub.append(db_sentence())
            act_sent_vor_sub[len(act_sent_vor_sub)-1].copy(act_sent[len(act_sent)-1])
            act_sent.append(db_sentence())
            sub_mode = True

        old_line = line

#    for sent in sentences:
#        sent.print_parts()
#        print
    return sentences


def write_jeliza_db(file, sentences):
    all = ""

    for sent in sentences:
        if not len(sent.quesword.strip()):
            all += sent.to_xml()
            all += "\n"

    fp = open(file, "w")
    fp.write(all)
    fp.close()

def get_first_names():
    try:
        fp = open("lang_" + get_lang() + "/wsh/first_names.wsh", "r")
        names = fp.read().split(" ")
        names = [ n.strip().lower() for n in names ]
        fp.close()
        return names
    except IOError:
        return []

def get_not_first_names():
    try:
        fp = open("lang_" + get_lang() + "/wsh/not_first_names.wsh", "r")
        names = fp.read().split(" ")
        names = [ n.strip().lower() for n in names ]
        fp.close()
        return names
    except IOError:
        return []

def add_first_name(n):
    fp = open("lang_" + get_lang() + "/wsh/first_names.wsh", "a")
    fp.write(" " + n.lower().strip() + "\n")
    fp.close()
    return n

def add_not_first_name(n):
    fp = open("lang_" + get_lang() + "/wsh/not_first_names.wsh", "a")
    fp.write(" " + n.lower().strip() + "\n")
    fp.close()
    return n


#db = read_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml")
#db = read_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml")
#write_jeliza_db("jeliza-standard.xml", sentences)

