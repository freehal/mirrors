# librarys to import
import sys
import modules
from modules.semnet import Fact, fact, GetIsA, anything, verb_synonyms, nouns, verbs, noun_verb, acc, set_acc, getObjects, getAgents, get_advs, is_true_impl, nothing, getUniqValues, get_list_subs_impl, split_sentence, divide, something_words
import modules.semnet
import string
import random
from defs import get_lang, contains, without_nonsense, get_use_online_db
from utilities import get_first_names, get_not_first_names, add_first_name, add_not_first_name, is_similar
from modules.utilities import ohne_artikel
from jelizacpp import log

tostr = str

# main part

isa = GetIsA()


if_then = {}
if_words = [ "wenn", "falls", "sobald", "if", "when" ]



def getUniqSentences(dic):
    unique = {} # dictionary
    for item in dic:
        unique[("".join([ p[0].strip() for p in item.parts ])).replace(" ", "").lower()] = item
    mylist=unique.values()
    mylist.sort()
    return mylist

fp = open("lang_" + get_lang() + "/wsh/arts.wsh", "r")
artikel = fp.read().strip().lower().replace("\n", " ").replace("  ", " ").split(" ")
fp.close()
fp = open("lang_" + get_lang() + "/wsh/preps.wsh", "r")
praepositions = fp.read().strip().lower().replace("\n", " ").replace("  ", " ").split(" ")
fp.close()

from jelizacpp import cpp_detect_wordtype

def capitalize_or_not(the_list):
    tmp = []
    n = -1
    for _item in the_list:
        n += 1
        m = -1
        for item in _item.split(" "):
            m += 1
            item = item.lower()
#            print "cpp_detect_wordtype:", 1
            wa = cpp_detect_wordtype(item, n == 0 and m == 0)
#            print "cpp_detect_wordtype(", item, item.capitalize(), "):", wa, type(wa)
            if int(wa) == 3:
                tmp.append(item.capitalize())
            else:
                tmp.append(item.lower())

#    print tmp

    return tmp

def formuliere(sub, verb, objs = [], advs = [], subs = []):
    from jelizacpp import cpp_detect_wordtype
    try:
        if sub[0].strip().lower() in [ o[0].strip().lower() for o in objs ]:
            print "Verwirrender Rekursionsfehler! Abbruch..."
            return ""
    except IndexError:
        pass

    if sub == "_":
        sub = "etwas"

    tmp = objs[:]
    objs = []
    anfang_advs = ["  "]
    i = -1
    for part in tmp:
        i += 1
        try:
            part.lower()
        except:
            part.reverse()
            w = part[1][:]
            part[1] = []
            in_anfang_adv = False
            b = -1
            for g in w.split(" "):
                b += 1
#                print "cpp_detect_wordtype:", 2
                wa = cpp_detect_wordtype(g, False)
                if wa == 5:
                    in_anfang_adv = True
                if in_anfang_adv:
                    anfang_advs.append(g)
                else:
                    part[1].append(g)
                if wa == 3:
                    in_anfang_adv = False

            part[1] = " ".join(part[1])
            part = " ".join(part)
        if part.lower() == "nothing":
            continue
        if str(part).lower().strip() == "_":
            part = "etwas"
        if i > 0:
            if part.lower() == "ihm": part = "er"
            if part.lower() == "ihr": part = "sie"
        if i == 0:
            if part.lower() == "er": part = "ihm"
            if part.lower() == "sie": part = "ihr"

        objs.append(part)

    tmp = advs[:]
    advs = []
    for part in tmp:
        if part.lower() == "nothing":
            continue
        if str(part).lower().strip() == "_":
            part = "etwas"
        advs.append(part)

    satz = ""
    satz += (" ".join(capitalize_or_not(anfang_advs))).strip()
    satz += " "
    satz += " ".join(capitalize_or_not(sub))
    satz += " "
    satz += str(verb).lower()
    for adv in getUniqValues(advs):
        if len(adv) > 0:
            satz += " "
            satz += " ".join(capitalize_or_not([adv]))
    for obj in getUniqValues(objs):
        if len(obj) > 0 and obj != "nothing":
            satz += " "
            satz += " ".join(capitalize_or_not([obj]))
    satz.replace(".", "").replace(",", "").replace("  ", " ")


#    _subs = []
#    if subs:
#        _subs += getUniqValues(getUniqSentences(subs))
#    subs = []
#    subs_dict = {}
    from defs import db_sentence
#    for s in subs[:]:
#        s_orig = db_sentence()
#        s_orig.copy(s)

#        parts = [ ss[0].strip().lower() for ss in s.parts ]
#        parts = [ x for x in parts if not contains("".join(x), "nothing") ]
#        verb = without_nonsense(str(s.verb)).strip().lower()

#        if len(s.parts) > 0 and len(s.verb) > 0: # and len([ p for p in subs if "".join(["".join(z) for z in p.parts]) is "".join(["".join(z) for z in s.parts]) ]) == 0:
#            subs_dict[str(parts)+str(verb)] = s_orig

#    subs = subs_dict.values()

    for s in subs:
        s = divide(s)

        satz += ", "
        satz += s.quesword

        from defs import get_lang
        if get_lang() == "de":
            s.parts[0].reverse()
        part = " ".join([ " ".join(capitalize_or_not(x.split(" "))) for x in s.parts[0] ])
        satz += " "
        satz += part

        if not s.isTrue:
            satz += " nicht"

        for part in s.parts[1:]:
            if part[0].lower() == "nothing":
                continue
            part.reverse()
            part = " ".join([ " ".join(capitalize_or_not(x.split(" "))) for x in part ])
            satz += " "
            satz += part.capitalize()
        for adv in s.advs:
            if len(adv) > 0:
                satz += " "
                satz += adv.capitalize()

        satz += " "
        satz += str(s.verb)

    satz += "."
    satz = satz.replace("  ", " ").strip()

    import time
    from utilities import case_indep_replace
    tim = time.localtime()
    tim = str(tim[3]) + " Uhr, " + str(tim[4]) + " Minuten und " + str(tim[5]) + " Sekunden"
    satz = case_indep_replace(satz, "NOW Uhr", tim)

    satz = (" " + satz + " ").replace(",", " ,").replace(" can ", " koennen ").replace(" ,", ",").strip()
    satz = (" " + satz + " ").replace(",", " ,").replace(" must ", " muessen ").replace(" _ ", " etwas ").replace(" ,", ",").strip()
    for x in ("ein", "kein", "Ein", "Kein"):
        for y in ("", "e", "en", "er", "en", "em", "es"):
            satz = (" " + satz + " ").replace(",", " ,").replace(" nicht " + x + y, " kein").replace(" ,", ",").strip()
            satz = (" " + satz + " ").replace(",", " ,").replace(" nicht " + x + y, " kein").replace(" ,", ",").strip()
            satz = (" " + satz + " ").replace(",", " ,").replace(" Nicht " + x + y, " kein").replace(" ,", ",").strip()
            satz = (" " + satz + " ").replace(",", " ,").replace(" Nicht " + x + y, " kein").replace(" ,", ",").strip()

    satz = case_indep_replace((" " + satz + " "), " nothing ", " ").replace(" ,", ",").strip()
    satz = case_indep_replace((" " + satz + " "), " nothing.", ".").replace(" ,", ",").strip()
    satz = case_indep_replace((" " + satz + " "), " nothing,", ",").replace(" ,", ",").strip()
    from defs import get_lang
    if get_lang() == "de":
        satz = case_indep_replace((" " + satz + " "), ", __to__", ", zu").replace(" ,", ",").strip()
    else:
        satz = case_indep_replace((" " + satz + " "), ", __to__", " to").replace(" ,", ",").strip()

    satz = satz.replace(". ,", ",")
    satz = satz.replace(" ,", ",")
    satz = satz.replace(" .", ".")
    satz = satz.replace(".,", ",")
    satz = satz.replace("_", " ")

#    print "satz:", satz

    satz = (satz+"__").replace(".__", "").replace("__", "")
    lis = { }
    backup = satz.split(",")[0]
    if len(satz.split(",")) > 2:
        for s in satz.split(",")[1:]:
            s = s.strip()
            ss_ = s[:].lower()
            ss_ = ss_.split(" ")
            ss_.sort()
#            print "lis[" + "".join(ss_) + "] = " + s
            lis["".join(ss_)] = s
        satz = backup + ", " + ", ".join(lis.values()) + "."

    if len(satz) > 2:
        satz = satz[0].upper() + satz[1:]

    return satz

def getObjekteImpl(_sub, verb):
    if len(_sub) == 0 or len(verb) == 0:
        return []

    sub = _sub[:]

    sub = ohne_artikel(sub.lower())
    verb = verb.lower()
    ret = []
    objs = []

    objs = [ x for x in getObjects(sub, verb) if len(x) == 2 ]
    objs = [ x for x in objs if contains(x[1], "|") ]
#    objs = [ (x[0], x[1].split("|")[1] + "|" + x[1].split("|")[0]) for x in objs ]

    ret = [ (x[0], x[1].strip()) for x in objs ]
    ret = [ (x[0], x[1]) for x in ret if len(x[1]) > 0 ]

    return ret

def getObjekte(_sub, verb):
    _sub = _sub[0]
    ret = []
    for __sub in _sub.split(" und "):
        for sub in __sub.split(" oder "):
            ret += getObjekteImpl(sub, verb)

    return ret

def getSubjekteImpl(_sub, verb):
    if len(_sub) == 0 or len(verb) == 0:
        return []

    sub = _sub[:]

    sub = ohne_artikel(sub.lower())
    verb = verb.lower()
    ret = []
    objs = []

    objs = [ x for x in getAgents(sub, verb) if len(x) == 2 ]
    objs = [ x for x in objs if contains(x[1], "|") ]
#    objs = [ (x[0], x[1].split("|")[1] + "|" + x[1].split("|")[0]) for x in objs ]

    ret = [ (x[0], x[1].strip()) for x in objs ]
    ret = [ (x[0], x[1]) for x in ret if len(x[1]) > 0 ]

    return ret

def getSubjekte(_sub, verb):
    _sub = _sub[0]
    ret = []
    for __sub in _sub.split(" und "):
        for sub in __sub.split(" oder "):
            r = getSubjekteImpl(sub, verb)
            ret += r

    return ret


def getAdvBestImpl(_sub, verb_eigentlich):
    if len(_sub) == 0:
        return []

    sub = _sub[:]

    if not verb_eigentlich:
#        print "getAdvBest: Verb not found"
        return []

    sub = ohne_artikel(sub.lower())
    ret = []

    objs = []
    objs += get_advs(sub, verb_eigentlich)
    ret += objs

    ret = [ str(r) for r in ret if len(str(r).strip()) > 0 ]

    ret = getUniqValues(ret)

    return ret

def getAdvBest(___sub, verb):
    ret = []
    if not len(___sub):
        return []
    for _sub in ___sub:
        for __sub in _sub.split(" und "):
            for sub in __sub.split(" oder "):
#                print "getAdvBestImpl(", sub, ", ", verb, ")"
                ret += getAdvBestImpl(sub, verb)

    return ret


def stimmt_spo_impl(_sub, verb, _obj, advs):
    sub = ohne_artikel(_sub[:]).lower()
    obj = ohne_artikel(_obj[:]).lower()

    try:
        if not len(obj):
            obj = "nothing"
        if not len(verb) or not len(sub):
            return False

        i = is_true_impl(sub, verb, obj, advs, 50) or is_true_impl(sub, verb, obj, advs, 100)

        log(sub + ";" + verb + ";" + obj + "=" + str(i))

        return i
    except KeyError:
        return False



def stimmt_spo(_sub, verb, _obj, advs):
    ret = False
    adv = []
    if type(_sub) == type([1]) or type(_sub) == type((1,)):
        try:
            adv.append(_sub[1][:])
        except KeyError:
            pass
        except IndexError:
            pass
        _sub = _sub[0]
    try:
        if type(_obj) == type([1]) or type(_obj) == type((1,)):
            try:
                adv.append(_obj[1][:])
            except KeyError:
                pass
            except IndexError:
                pass
            _obj = _obj[0]
    except:
        return False

    adv = [ x for x in adv if len(x.strip()) > 0 ]
    if len(adv):
        advs += adv

    advs = [ ohne_artikel(x) for x in advs if len(x) ]
    advs = getUniqValues(advs)

    for __sub in _sub.split(" oder "):
        list = []
        for sub in __sub.split(" und "):
            ret_2 = []
            for __obj in _obj.split(" oder "):
                list_2 = []
                for obj in __obj.split(" und "):
                    r = stimmt_spo_impl(sub, verb, obj, advs)
                    print "stimmt_spo:", sub, "#", verb, "#", obj, "#", r
                    if r:
                        list_2 += [ r ]
                print "len(list_2) == len(__obj.split(\" und \")):", len(list_2), " == ", len(__obj.split(" und "))
                print "list_2:", list_2
                if len(list_2) == len(__obj.split(" und ")):
                    ret_2 += list_2
            if ret_2:
                list += list_2
        print "len(list) == len(__sub.split(\" und \")):", len(list), " >= ", len(__sub.split(" und "))
        print "len(list):", len(list)
        if len(list) >= len(__sub.split(" und ")):
            return list

    return False


def replace_if(p, arr_rep, pla):
    if p.lower().replace("|", "") in [ a.lower() for a in arr_rep ]:
        return pla
    return p

def replace_if_array(p, arr_rep, pla):
    if "|".join(p).lower().replace("|", "") in [ a.lower() for a in arr_rep ] or p[0].lower().replace("|", "") in [ a.lower() for a in arr_rep ] or "".join(p).lower().replace("|", "") in [ a.lower() for a in arr_rep ]:
        return [pla, p[1]]
    return p

import sys
from utilities import apply_procent
def add_sentence_to_net(_dbs, a, b, nur_bedingungen = False, __Fact = Fact):
    from jelizacpp import log

    if _dbs != None:
        db_list = []
        if len(_dbs.subs()):
            for dbs in _dbs.subs():
                dbs = divide(dbs)
                db_list.append(dbs)
        dbs = divide(_dbs)
        db_list.append(_dbs)

        if len(_dbs.subs()) and nur_bedingungen:
            for _dbs_sub in _dbs.subs():
                _dbs_sub.quesword = _dbs_sub.quesword.strip().lower()

                if _dbs_sub.quesword in if_words:
                    _dbs = divide(_dbs)
                    _dbs_sub = divide(_dbs_sub)

                    tmp = _dbs.parts[:]
                    _dbs.parts = []
                    for (part, adv) in tmp:
                        if str(part).lower().strip() in something_words:
                            part = "_"
                        _dbs.parts.append([part, adv])

                    if len(_dbs_sub.advs) == 0:
                        _dbs_sub.advs.append("")

                    for _adv in _dbs_sub.advs:
                        adv = str(_adv).lower().strip()

                        if len(_dbs_sub.parts) == 0:
                            print "len(_dbs_sub.parts) == 0"
                            return

                        if len(_dbs_sub.parts) == 1:
                            _dbs_sub.parts.append(["nothing", ""])

#                        dbs.print_parts()

                        for (_part, _adv) in _dbs_sub.parts[1:]:
    ##                        print "_part:", _part
                            part = str(_part).lower().strip()
                            _adv = str(_adv).lower().strip()

                            if part.lower().strip() in something_words:
                                part = "_"

                            key1 = [ str(_dbs_sub.parts[0][0]).lower().strip(), str(_dbs_sub.verb), part, adv ]
                            key2 = [ str(_dbs_sub.parts[0][0]).lower().strip(), str(_dbs_sub.verb), part ]
                            if key1 not in if_then.keys():
                                if_then["#".join(key1)] = []
                            if key2 not in if_then.keys():
                                if_then["#".join(key2)] = []

                            if_then["#".join(key1)] += [ _dbs ]
                            if_then["#".join(key2)] += [ _dbs ]

    ##                        print if_then

                return

        if nur_bedingungen:
            return

        isTrue = True

        for dbs in db_list:
            if contains(dbs.subject, "nicht") or contains(dbs.verb, "nicht") or contains(dbs.object, "nicht") or contains(dbs.additional, "nicht") or contains(dbs.all_without_nonsense, "nicht"):
                isTrue = False

        from defs import db_sentence

        for _dbs in db_list:
            dbs = db_sentence()
            dbs.copy(_dbs)
            dbs.verb = str(dbs.verb)
            if len(dbs.verb) < 1:
                continue

            if len(dbs.subject) < 1:
                continue

#            dbs.parts = [ [ d for d in p ] for p in dbs.parts ]



            if len((" ".join([ "".join(d) for d in dbs.parts])).replace(",", "").strip()) < 2 or contains(dbs.all_without_nonsense, "?"):
                continue

            if len(dbs.parts) == 0:
                continue

            if len(dbs.parts) == 1:
                dbs.parts.append(["nothing", ""])


            nnouns = [ "|".join(d) for d in dbs.parts]
            nadvs = dbs.advs # + [ d[1] for d in dbs.parts ]
            vverb = dbs.verb

            prio = dbs.priority

            try:
                nnouns[0][0]
            except:
                return

            #dbs.print_parts()

            if nnouns[0][0] != "nothing" and dbs.isTrue: # Unwahres nicht in die DB aufnehmen, da nicht drin == falsch
                __Fact(nnouns[0], vverb, nnouns[1:], prio, dbs.subs(), nadvs)
                for n in nnouns:
                    nn = str(n).lower()
                    if nn not in noun_verb:
                        noun_verb[nn] = []
                    noun_verb[nn].append(vverb)

#            dbs.print_parts()
#            print dbs.parts, dbs.advs

            dbs_tmp_sicherung = db_sentence()
            dbs_tmp_sicherung.copy(dbs)
            dbs_tmp_sicherung = divide(dbs_tmp_sicherung)

            a += 1

            if nnouns[0] != "nothing" and dbs.isTrue: # Unwahres nicht in die DB aufnehmen, da nicht drin == falsch
                for n in nnouns[1:]:
                    n = n.split("|")[0]
                    ok = False

#                    print
#                    print "n:", n
#                    print a
                    if (a % 100) == 0:
                        sys.stdout.write(".")
                        apply_procent(100.0 / b * a)
                        sys.stdout.flush()

                    t = "#".join((nnouns[0].split("|")[0], vverb, n, ""))
#                    print if_then, t
                    if t in if_then:
                        ok = 1
                    if not ok:
#                        print "ok, t:", ok, t
                        t = "#".join(("_", vverb, n, ""))
                        if t in if_then:
                            ok = nnouns[0]
                        if not ok:
#                            print "ok, t:", ok, t
                            t = "#".join((nnouns[0].split("|")[0], vverb, "_", ""))
                            if t in if_then:
                                ok = n

                    if ok:
#                        print "=> ok, t:", ok, t
#                        print if_then


                        for dbs in if_then[t]:
                            from defs import db_sentence
                            dbs_tmp = db_sentence()
                            dbs_tmp.copy(dbs)
                            dbs_tmp.has1_sub, dbs_tmp.has2_sub, dbs_tmp.has3_sub, dbs_tmp.has4_sub, dbs_tmp.has5_sub = False, False, False, False, False

                            if type(ok) != type(1) and type(ok) != type(True) and str(ok) != "nothing":
                                ok = " ".join(ok.split("|")).strip()

                                dbs_tmp.parts = [ replace_if_array(p, ("_", "er", "es", "sie", "ihn"), ok) for p in dbs_tmp.parts ]
                                dbs_tmp.object = " ".join([ replace_if(p, ("_", "er", "es", "sie", "ihn"), ok) for p in dbs_tmp.object.split(" ") ])
                                dbs_tmp.object = [ p for p in dbs_tmp.object.split(" ") ]
                                dbs_tmp.object = " ".join(dbs_tmp.object)

#                            print
#                            print
#                            dbs_tmp_sicherung.print_parts()
#                            print "dbs_tmp.parts:", dbs_tmp_sicherung.parts
#                            print
##                            dbs_tmp.print_parts()
#                            print "dbs_tmp.parts:", dbs_tmp.parts
                            add_sentence_to_net(dbs_tmp, 1, 1, False, __Fact)
    return a


def actualNet(db, stop_it):
    from jelizacpp import log

    a = 0
    b = len(db)
    import time
    from defs import db_sentence
    for _dbs in db:
        dbs = db_sentence()
        dbs.copy(_dbs)
        a = add_sentence_to_net(dbs, a, b, True)
    a = 0
    for _dbs in db:
        dbs = db_sentence()
        dbs.copy(_dbs)
        a = add_sentence_to_net(dbs, a, b, False)
#    a = 0
#    for _dbs in db:
#        dbs = db_sentence()
#        dbs.copy(_dbs)
#        a = add_sentence_to_net(dbs, a, b, False)
    print

#    adjust_if_then(db, stop_it) ## Dreifach, Rekursion
#    adjust_if_then(db, stop_it)
#    adjust_if_then(db, stop_it)

def initNet():

    apply_procent(1)
    fp = open("lang_" + get_lang() + "/wsh/synonyms.wsh", "r")
    lines = fp.readlines()
    fp.close()

    vverb = "sein"
    a = 0
    b = 0
    import sys
    for line in lines:
        b += 1
        p = int(100.0 / float(len(lines)) * b)
        if p > a:
            a = p
            sys.stdout.write("\r" + str(p) + "% loaded...\r")
            apply_procent(p)

        synonyms = line.split(",")
        con = False
        for syn in synonyms:
            if syn.lower() == syn:
                con = True
                break
        if con:
            continue

        fact(synonyms[0], vverb, [ s for s in synonyms[1:] ])
        fact(synonyms[0]+"|", vverb, [ s+"|" for s in synonyms[1:] ])
        for syn in synonyms[1:]:
            if syn not in noun_verb:
                noun_verb[syn] = []
            noun_verb[syn].append(vverb)

        if synonyms[0] not in noun_verb:
            noun_verb[synonyms[0]] = []
        noun_verb[synonyms[0]].append(vverb)


gen_net_times = -1

def genNet(db):

    return


    import math
    import time
    from init_semantic import gen_net_times
    from utilities import apply_procent

    log("- Ich kenne " + str(len(getUniqValues(nouns.values()))) + " Woerter")


    uniq_nouns = getUniqValues(nouns.values())
    x = 5
    y = 5
    auslassen = int(float(len(uniq_nouns)) / 30000.0)
    if auslassen < 2:
        auslassen = 1
    lenBild = 1000
    x2 = lenBild
    y2 = lenBild
    x3 = lenBild
    y3 = lenBild * 0.4

    coord = {}

    xmax = lenBild

    import random

    fp2 = open("temp/lines.tmp", "w")
    fp5 = open("temp/coord_words.tmp", "w")

    time.sleep(1)
    vector = [ [ int(x / lenBild), int(x % lenBild) ] for x in xrange(0, lenBild*lenBild) ]
    time.sleep(1)
    random.shuffle(vector)
    time.sleep(1)

    z = 0

    x_uniq_nouns = 1
    for noun in uniq_nouns:
        if x_uniq_nouns % 20 == 0:
#            apply_procent(100.0 / len(uniq_nouns) * x_uniq_nouns)
            time.sleep(1)
        x_uniq_nouns += 1
        z += 1
        x, y = vector[0]
        vector.remove(vector[0])

        coord[noun] = (x, y)

        fp5.write(str(int(x + 1)) + " " + str(int(y + 1)) + " " + str(noun).replace(" ", "_") + "\n")

        try:
            if noun not in noun_verb:
                continue
            for verb in getUniqValues(noun_verb[noun]):
                try:
                    if len(str(noun)) < 2:
                        continue
                    for agent in noun.objects(verb) + noun.agents(verb):
                        x2, y2 = vector[0]
                        vector.remove(vector[0])

                        coord[agent] = (x2, y2)

                        fp2.write(str(int(coord[noun][0]+1 + 1)) + " " + str(int(coord[noun][1]+1 + 1)) + " " + str(int(x2-1 + 1)) + " " + str(int(y2-1 + 1)) + "\n")

                except:
                    raise

        except:
            raise

    fp2.close()
    fp5.close()

def semantic_loadcache(z, stop_it): # z, stop_it
    from jelizacpp import log, send
    from utilities import apply_procent
    import pickle
    try:
        fd = open("temp/semantic_nouns.tmp", "r")
        lines1 = fd.readlines()
        fd.close()
        fd = open("temp/semantic_nouns.tmp_2", "r")
        lines2 = fd.readlines()
        fd.close()

        log("'semantic_nouns.tmp' loaded successful")
        log("Loading semantic net...")

        vverb = "sein"
        a = 0
        b = 0
        for line in lines1:
            line = line.strip()
            b += 1
#            if b > 100:
#                break
            p = 100.0 / float(len(lines1)) * b
            if p > a:
                a = p
                sys.stdout.write("\r" + str(p) + "% loaded...\r")
                apply_procent(p)

            synonyms = line.lower().split(",")

            fact(synonyms[0], vverb, [synonyms[1].lower(),])
            fact(synonyms[0]+"|", vverb, [synonyms[1].lower()+"|",])

        for line in lines2:
            line = line.strip()
            synonyms = line.lower().split(",")

            if synonyms[0].lower() not in noun_verb:
                noun_verb[synonyms[0].lower()] = []
            noun_verb[synonyms[0].lower()].append(vverb)

        log("Semantic net loaded!                ")
    except IOError:
        log("Loading of 'semantic_nouns.tmp' failed")
        log("Creating semantic net...")
        log("Loading semantic net...")
        initNet()
        semantic_savecache()
        log("Semantic net loaded.         ")

    send("READY:EVERYTHING_INITIALIZED")

def semantic_savecache():
    import pickle

    fp = open("lang_" + get_lang() + "/wsh/synonyms.wsh", "r")
    lines = fp.readlines()
    fp.close()
    fp1 = open("temp/semantic_nouns.tmp", "w")
    fp2 = open("temp/semantic_nouns.tmp_2", "w")

    for line in lines:
        line = line.strip()
        synonyms = line.split(",")
#        con = False
#        for syn in synonyms:
#            if syn.lower() == syn:
#                con = True
#                break
#        if con:
#            continue

        synonyms = ",".join(synonyms).lower().split(",")

        for syn in synonyms[1:]:
            if not str(synonyms[0]) == str(syn) and len(syn.strip()):
                fp1.write(",".join([synonyms[0].lower(), syn.lower()]).strip() + "\n")

                fp2.write(syn.lower().strip() + "\n")

        fp2.write(synonyms[0].lower().strip() + "\n")

    fp1.close()
    fp2.close()


last_user_sentence = ""

from semnet import background_do, online_get_objects, get_subj_list
from defs import get_online_semantic_net_urls, db_sentence
from jelizacpp import cpp_to_db_sentence
import semnet

def get_list_subs(___n, verb, o = None):
    if not o:
        o = "nothing"
    if type(o) in [type([1, 2]), type((1, 2,))]:
        o = " ".join(o).strip()
    if type(___n) == type([1, 2]) or type(___n) == type((1, 2,)):
        ___n = ___n[0]
    o = o.strip()

    r = []
    arr_n = []
    for _n in ___n.split(" und "):
        for n in _n.split(" oder "):
            arr_n.append(n.lower().replace("|", "").strip())
            r2 = get_list_subs_impl(ohne_artikel(n.lower()))
            r += r2

    if o:
        vs = verb_synonyms(verb)

        e = [ x[3] for x in r if is_similar(x[2].lower().replace("|", "").strip(), o.lower().replace("|", "").strip()) and x[0].lower().replace("|", "").strip() in arr_n and x[1] in vs ]
        w = []
        for i in e:
            for ii in i:
                w.append(ii)

        if get_use_online_db() and len(w) == 0:
            online_fact_urls = get_online_semantic_net_urls()
            subj_list = get_subj_list([ ___n ])
            for host, ofu in online_fact_urls:
                if len(ofu):
                    th = background_do(online_get_objects, host, ofu, ",".join(subj_list), ",".join(verb_synonyms(verb)))
                    th.start()
                else:
                    th = background_do(online_get_objects, host, ofu, sub, verb)
                    th.start()

                for x in range(1, 16):
                    import time
                    time.sleep(0.1)

                    fp = open("temp/down_tmp.tmp")
                    rrr = [ l.split(";") for l in fp.read().split("\n") if len(l.strip()) > 0 ]
                    rrrr = []
                    for r in rrr:
    #                    print "r:", r
                        if contains(r[1], "|"): rrrr.append((r[0], r[1]))
                        l2 = r[2]
                        if not len(l2.strip()):
                            continue
                        dbs = db_sentence()
                        dbs.subject = l2.split("-----")[0].replace("}", "").replace("{", " ")
                        dbs.verb = l2.split("-----")[1].replace("}", "").replace("{", " ")
                        dbs.object = l2.split("-----")[2].replace("}", "").replace("{", " ")
                        dbs.prefix = l2.split("-----")[3].replace("}", "").replace("{", " ")
                        dbs.suffix = l2.split("-----")[4].replace("}", "").replace("{", " ")
                        dbs.feeling = l2.split("-----")[5].replace("}", "").replace("{", " ")
                        dbs.category = l2.split("-----")[6].replace("}", "").replace("{", " ")
                        dbs.additional = l2.split("-----")[7].replace("}", "").replace("{", " ")
                        dbs.quesword = l2.split("-----")[8].replace("}", "").replace("{", " ")

                        w.append(dbs)
                        semnet.subj_verb_dbs.append((___n.lower(), verb, o.lower(), [dbs]))
                    if len(w):
                        break

        return w
#        return ree
    else:
        print "No subclauses found for:", o, ",", o
#        try: print r[verb]
#        except KeyError: pass
#        pass

    return []

def get_warum_to_do(_dbs):
    from defs import db_sentence
    from utilities import read_to_do_file
    from jelizacpp import cpp_to_db_sentence

    dbs = db_sentence()
    dbs.copy(_dbs)
    delete_words = ( "kann", "koennen", "konnten", "kannst", "kanne", "kannsst", "konntest", "konnte", "koenne", "can",
                     "muss", "muessen", "musst", "mussst", "musse", "muesse", "must",
                     "darf", "duerfen", "durften", "durfte", "darfst", "darft", "darfsst", "darfe",
                   )
    if len(dbs.verb.split(" ")) > 1:
        for word in delete_words:
            dbs.verb = dbs.verb.replace(word, "")
    dbs.verb = dbs.verb.strip()
    dbs = divide(dbs)

    opinion = []

    if not len(dbs.parts):
        return []

    to_do_pairs = read_to_do_file()
    for (to, do) in to_do_pairs:
        to, do = do, to

        dbs2 = db_sentence()
        dbs2.copy_tupel(cpp_to_db_sentence(to))
        dbs2 = divide(dbs2)
        dbs3 = db_sentence()
        dbs3.copy_tupel(cpp_to_db_sentence(do))
        dbs3 = divide(dbs3)

        if len(dbs.verb.split(" ")) > 1:
            for word in delete_words:
                dbs2.verb = dbs2.verb.replace(word, "")

        dbs2.verb = dbs2.verb.strip()

#        print "dbs.verb == dbs2.verb", dbs.verb , "==", dbs2.verb
        if dbs.verb in verb_synonyms(dbs2.verb) + [dbs2.verb]:
            ok = 0
            for p, ad in dbs2.parts:
                if ohne_artikel(p.lower()) in [ ohne_artikel(p2[0].lower()) for p2 in dbs.parts[1:] ]:
                    ok += 1
            if ok:
                subj, ad = dbs2.parts[0]
                if subj.lower() in ["du", "ich", "man", "er", "sie", "es", "I", "you", "someone", "somebody", "anyone", "anybody", "he", "she", "it", "i", "you", "me", "_"] + something_words:
                    subj, ad = dbs.parts[0]
                while len(dbs2.parts) <= 1:
                    dbs2.parts.append(["nothing", ""])
                if (get_lang() == "de"):
                    opinion.append("Damit " + (
                                                 formuliere([subj,""], "", dbs3.parts[:], dbs3.advs, [])
                                                 ).replace(".", "") + " " + dbs3.verb + ".")
                else:
                    opinion.append("To " + (
                                                 formuliere([subj,""], "", dbs3.parts[:], dbs3.advs, [])
                                                 ).replace(".", "") + " " + dbs3.verb + ".")

    return opinion

def get_to_do(_dbs):
    from defs import db_sentence
    from utilities import read_to_do_file
    from jelizacpp import cpp_to_db_sentence, cpp_detect_wordtype

    dbs = db_sentence()
    dbs.copy(_dbs)
    delete_words = ( "kann", "koennen", "konnten", "kannst", "kanne", "kannsst", "konntest", "konnte", "koenne", "can",
                     "muss", "muessen", "musst", "mussst", "musse", "muesse", "must",
                     "darf", "duerfen", "durften", "durfte", "darfst", "darft", "darfsst", "darfe",
                   )
    for word in delete_words:
        dbs.verb = dbs.verb.replace(word, "")
    dbs.verb = dbs.verb.strip()
    dbs = divide(dbs)

    opinion = []

    if not len(dbs.parts):
        return []

    to_do_pairs = read_to_do_file()
    for (to, do) in to_do_pairs:
        dbs2 = db_sentence()
        dbs2.copy_tupel(cpp_to_db_sentence(to))
        dbs2 = divide(dbs2)
        dbs3 = db_sentence()
        dbs3.copy_tupel(cpp_to_db_sentence(do))
        dbs3 = divide(dbs3)

        verb_manually = []
        o = -1
        for x in to.replace(",", "").split(" "):
            o += 1
#            print "cpp_detect_wordtype:", 3
            if cpp_detect_wordtype(x, o == 0) == 2:
                verb_manually += verb_synonyms(x)
        verb_manually += verb_synonyms(dbs2.verb)[:]

        for word in delete_words:
            dbs2.verb = dbs2.verb.replace(word, "")

        dbs2.verb = dbs2.verb.strip()

#        print "dbs.verb == dbs2.verb", dbs.verb , "==", dbs2.verb, "|", verb_manually
        if dbs.verb in verb_manually:
            ok = 0
            for p, ad in dbs2.parts:
                if ohne_artikel(p.lower()) in [ ohne_artikel(p2[0].lower()) for p2 in dbs.parts[1:] ]:
                    ok += 1
            if ok or [ p for p in dbs.parts if not contains(" ".join(p), "nothing") ] or [ p for p in dbs2.parts if not contains(" ".join(p), "nothing") ]:
                subj, ad = dbs3.parts[0]
                if subj.lower() in ["du", "ich", "man", "er", "sie", "es", "I", "you", "someone", "somebody", "anyone", "anybody", "he", "she", "it", "i", "you", "me", "_"] + something_words:
                    subj, ad = dbs.parts[0]
                while len(dbs2.parts) <= 1:
                    dbs2.parts.append(["nothing", ""])
                if (get_lang() == "de"):
                    opinion.append((
                                      formuliere([subj,""], dbs3.verb, dbs3.parts[1:], dbs3.advs, get_list_subs(subj, str(dbs3.verb)))
                                      + ", damit "
                                      + formuliere([subj,""], dbs.verb, dbs2.parts[1:], dbs2.advs, get_list_subs(dbs.parts[0], str(dbs.verb)))
                                      ).replace(".,", ","))
                    opinion.append("Dazu muessen " + (
                                    formuliere([subj,""], dbs3.verb, dbs3.parts[1:], dbs3.advs, get_list_subs(subj, str(dbs3.verb)))
                                    ))
                else:
                    opinion.append((
                                      formuliere([subj,""], dbs3.verb, dbs3.parts[1:], dbs3.advs, get_list_subs(subj, str(dbs3.verb)))
                                      + ", to "
                                      + formuliere(dbs2.parts[0], dbs.verb, dbs2.parts[1:], dbs2.advs, get_list_subs(dbs.parts[0], str(dbs.verb)))
                                      ).replace(".,", ","))

    return opinion

