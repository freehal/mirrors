#!/usr/bin/perl -w
use CGI;
use CGI::Carp qw(fatalsToBrowser);
$| = 1;

our $show_simple = 1;

require 'jeliza-cgi-engine.pl';
