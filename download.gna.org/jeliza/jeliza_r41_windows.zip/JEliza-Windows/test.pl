open FH, "<", "lang_de/word_types.dic";
open FH2, ">", "lang_de/backup/word_types.dic.basic";
while (<FH>) {
	last if /mit[|]prep/;
	print FH2 $_;
}
close FH;
close FH2;
