#-------------------------------------------------->
# JEliza Module
#
#-> name: Greeting
#-> compatible: 2.4
#-> author: JEliza Team
#-> copyright: Tobias Schulz
#-> date: 08.2007
#-------------------------------------------------->

# librarys to import
import random
from string import *

# main part

def greet(question, orig_fra, db, is_positive):
    if question.lower().strip().replace(".", "").replace(",", "").replace("?", "").replace("!", "") not in (
            "guten tag", "guten morgen", "hi", "hallo", "hey", "huhu", "guten abend", "guten nachmittag",
            "good morning", "hello", "good afternoon", "good night",
                                                                                                     ):
        return ""

    import time
    zeit = time.localtime ()
    zeit = time.strftime("%H", (zeit))
    zeit = int (zeit)
    from defs import get_lang
    if get_lang() == "de":
        if zeit >= 0 and zeit < 5:
            return "Wie..? Immer noch wach...?"
        if zeit >= 5 and zeit < 12:
            return "Guten Morgen!"
        if zeit >= 12 and zeit < 17:
            return "Guten Tag!"
        if zeit >= 17 and zeit < 24:
            return "Guten Abend!"
    else:
        if zeit >= 0 and zeit < 5:
            return "You should sleep..."
        if zeit >= 5 and zeit < 12:
            return "Good morning."
        if zeit >= 12 and zeit < 17:
            return "Hello."
        if zeit >= 17 and zeit < 24:
            return "Good night."
    return ""


funcs_module.append(greet)

