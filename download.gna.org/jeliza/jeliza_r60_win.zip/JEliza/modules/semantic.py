﻿#------------------------------------------------->
# JEliza Module
#
#-> name: Semantic
#-> compatible: 2.4
#-> author: JEliza Team
#-> copyright: Tobias Schulz
#-> date: 09.2007
#-------------------------------------------------->

# librarys to import
from defs import get_lang, contains, get_use_online_db
import modules.init_semantic
from modules.init_semantic import Fact, GetIsA, nouns, verbs, noun_verb, isa, nothing, getUniqValues, split_sentence, actualNet, initNet, semantic_loadcache, genNet, divide, formuliere, getSubjekte, getObjekte, getAdvBest, stimmt_spo, acc, add_sentence_to_net, get_list_subs, get_to_do, get_warum_to_do, formuliere
import string
import random
from modules.utilities import download_weather, read_jeliza_db
from modules.semnet import acc_int
from jelizacpp import log
import time

tostr = str


# main part



fp = open("lang_" + get_lang() + "/wsh/arts.wsh", "r")
artikel = fp.read().strip().lower().replace("\n", " ").replace("  ", " ").split(" ")
fp.close()
fp = open("lang_" + get_lang() + "/wsh/preps.wsh", "r")
praepositions = fp.read().strip().lower().replace("\n", " ").replace("  ", " ").split(" ")
fp.close()

def make_better(question):
    _fra = question.strip().split(" ")
    fra = [ "" ]

    n = -1
    for f in _fra:
        n += 1
        if is_similar("." + f, ".ein") and fra[len(fra)-1] == "nicht":
            fra[len(fra)-1] = "k" + f
            continue
        if cpp_detect_wordtype(f, False) == 6 and fra[len(fra)-1] == "nicht":
            fra[len(fra)-1] = "kein"
            continue



        fra.append(f)

    question = " ".join(fra).strip()
    return question

hash_getAdvBest = {}
def getAdvBestWrapper(_s, _v):
    s = "".join(_s)
    v = "".join(_v)
    try:
        x = hash_getAdvBest[s.lower()+v.lower()]
        return x
    except KeyError:
        hash_getAdvBest[s.lower()+v.lower()] = getAdvBest(s, v)
        x = hash_getAdvBest[s.lower()+v.lower()]
        return x

def get_list_subs_wrapper(_n, _verb, _o = None):
    return  get_list_subs(_n, _verb, _o)

def online_get_advs(a = None, b = None, c = None, d = None, e = None, f = None):
    from defs import get_online_semantic_net_urls
    online_fact_urls = get_online_semantic_net_urls()
    lines = []
    for host, ofu in online_fact_urls:
        ofu += "get_all_advs=1"

        print "Online Fact Process started:"

        from httplib import HTTPConnection
        http = HTTPConnection(host, 80)
        http.connect() # agent=ich|&rel=bin&objects=da|&prio=100
        http.putrequest("GET", ofu)
        print "http://" + host + "/" + ofu
        http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
        http.endheaders()
        lines = str(http.getresponse().read().replace("\r", "")).split("\n")
        lines = [ l.split(";") for l in lines ]
        lines = [ l for l in lines if len(l) == 3 ]
        lines = [ (l[0].lower()+l[1].lower(), l[2]) for l in lines ]
        hash_getAdvBest = {}
        for l1, l2 in lines:
            try:
                hash_getAdvBest[l1]
            except KeyError:
                hash_getAdvBest[l1] = []
            hash_getAdvBest[l1].append(l2)

def online_get_subs(x):
    db = []
    from defs import get_online_semantic_net_urls
    online_fact_urls = get_online_semantic_net_urls()
    lines = []
    for host, ofu in online_fact_urls:
        ofu += "get_all_subs=1"

        print "Online get_subclauses Process started:"

        from httplib import HTTPConnection
        http = HTTPConnection(host, 80)
        http.connect() # agent=ich|&rel=bin&objects=da|&prio=100
        http.putrequest("GET", ofu)
        print "http://" + host + "/" + ofu
        http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
        http.endheaders()
        lines = str(http.getresponse().read().replace("\r", "")).split("\n")
        lines = [ l.split(";") for l in lines ]
        lines = [ l for l in lines if len(l) == 4 ]
#        lines = [ (l[0].lower().split("|")[0]+l[1].lower().split("|")[0]+l[2].lower().split("|")[0], l[3]) for l in lines ]
#        hash_get_list_subs = {}
        for subj, v, obj, l2 in lines:
            subj = subj.replace("|", " ")
            obj = obj.replace("|", " ")

            sent = []
            sent.append(subj)
            sent.append(v)
            sent.append(obj)

            sent2 = [
                        l2.split("-----")[8],
                        l2.split("-----")[0],
                        l2.split("-----")[1],
                        l2.split("-----")[2],
                        l2.split("-----")[7]
                    ]
            sent = " ".join(sent) + ", " + " ".join(sent2)

            db.append(sent)
    fp = open("temp/sentences_to_learn.tmp", "w")
    fp.write("\n".join(db))
    fp.close()



def answer_logical_question_without_questionword(question, orig_fra, dbs):
    log("")
    log("S-N: question ohne questionwort!")
    log("")

    proz = 2.0

    for part in dbs.parts:
        log("part: " + str(part))

    opinion = []

    if len(dbs.parts) == 0:
        return ""

    subj = dbs.parts[0]

    verb = dbs.verb

    proz += 1
    apply_procent(proz)
    for part in dbs.parts[1:] + [""]:
        proz += 1
        apply_procent(proz)
        if stimmt_spo(subj, verb, part):
            pre = "Ja, "

            aaadvs = dbs.advs * 10 + getAdvBestWrapper(subj, dbs.verb)
            for adv1 in aaadvs:
                proz += 1
                apply_procent(proz)
                opinion.append(pre + formuliere(subj, dbs.verb, [part], [adv1], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)))
            opinion.append(pre + formuliere(subj, dbs.verb, [part], [], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)))
    if len(opinion) == 0:
        try:
            opinion.append("Nein, " + formuliere(subj, dbs.verb, dbs.parts[1:], ["nicht"] + getAdvBestWrapper(subj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)))
        except KeyError:
            return ""

    # Zeige alle opinion
    for meinung in getUniqValues(opinion):
        log("S-N: - " + meinung)

    # Zufallsmeinung
    random.shuffle(opinion)

    # Rueckgabe: Meinung
    return opinion[0]

def answer_logical_questionword(question, orig_fra, dbs):
    proz = 2.0
    proz += 1
    apply_procent(proz)

    log("")
    log("S-N: question mit questionwort!")
    log("")

    for part in dbs.parts:
        log("part__: " + str(part))

    opinion = []

    if len(dbs.parts) == 0:
        return ""

    subj = dbs.parts[0]

    tmp_advs = [ x for x in [ p[1].lower() for p in dbs.parts ] + dbs.advs if len(x.strip()) ]

    if dbs.quesword.lower() == "wie" or dbs.quesword.lower() == "how":
        opinion += get_to_do(dbs)

    if dbs.quesword.lower() == "warum" or dbs.quesword.lower() == "wieso" or dbs.quesword.lower() == "weshalb" or dbs.quesword.lower() == "why":
        opinion += get_warum_to_do(dbs)

    if len(opinion):
        random.shuffle(opinion)
        # Rueckgabe: Meinung
        return opinion[0]

    print "Subjects..."

    get_objs = getObjekte(subj, dbs.verb)
    known_all = [ p[1].split("|") for p in get_objs if p[0] != 100 ]
    known_best = [ p[1].split("|") for p in get_objs if p[0] == 100 ]
    print "getObjekte(subj, dbs.verb):", getObjekte(subj, dbs.verb)
    print "tmp_advs:", tmp_advs

    k1 = [ part for part in known_best if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) ]
    print "k1:", k1
    k2 = [ part for part in known_all if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) ]
    print "k2:", k2
    k3 = [ part for part in known_best if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
    print "k3:", k3
    k4 = [ part for part in known_all if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
    print "k4:", k4
    k5 = [ part for part in known_best ]
    print "k5:", k5
    k6 = [ part for part in known_all ]
    print "k6:", k6
    k7 = [ part for part in known_best if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and not contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
    print "k7:", k7
    k8 = [ part for part in known_all if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and not contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
    print "k8:", k8
    k9 = [ part for part in known_best if not contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
    print "k9:", k9
    k10 = [ part for part in known_all if not contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
    print "k10:", k10
    for part in known_best + known_all:
        print ":", " ".join(part + getAdvBestWrapper(part, dbs.verb)).lower()
    k11 = [ part for part in known_best if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "im ")) ]
    print "k11:", k11
    k12 = [ part for part in known_all if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "im ")) ]
    print "k12:", k12
    k13 = [ part for part in known_best if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "im ")) ]
    print "k13:", k13
    k14 = [ part for part in known_all if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "im ")) ]
    print "k14:", k14

    parts_known = []
    if not len(parts_known) and (dbs.quesword.lower() in ("wie", "how")):
        parts_known = k3[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("wie", "how")):
        parts_known = k4[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
        parts_known = k11[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
        parts_known = k12[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
        parts_known = k13[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
        parts_known = k14[:]

    if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
        parts_known = k7[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
        parts_known = k8[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
        parts_known = k9[:]
    if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
        parts_known = k10[:]

    if not len(parts_known):
        parts_known = k1[:]
    if not len(parts_known):
        parts_known = k2[:]
    if not len(parts_known):
        parts_known = k5[:]
    if not len(parts_known):
        parts_known = k6[:]

    parts_known_without_nothing = [ n for n in parts_known if not contains("".join(n), "nothing") ]
    if len(parts_known_without_nothing):
        parts_known = parts_known_without_nothing


    parts_to_say = parts_known[:]

    proz += 1
    apply_procent(proz)

    print len(parts_to_say), len(parts_known)

    for part in parts_known:
        log("parts_known: " + str(part))


    for x in xrange(1,4):
        proz += 1
        apply_procent(proz)
        for part in parts_to_say:
            proz += 1
            apply_procent(proz)
            aaadvs = getAdvBestWrapper(subj, dbs.verb) + getAdvBestWrapper(part, dbs.verb)
            for adv1 in aaadvs:
                opinion.append(formuliere(subj, dbs.verb, [part], [adv1], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)))
            if len(aaadvs) == 0:
                opinion.append(formuliere(subj, dbs.verb, [part], [], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)))

    """
    try:
        if acc(nouns, dbs.parts[0], False):
            if len(get_list_subs_wrapper(dbs.parts[0], str(dbs.verb))) > 0 and len(opinion) == 0:
                opinion.append(formuliere(subj, dbs.verb, [], getAdvBestWrapper(subj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb))))
    except KeyError:
        pass
    """


    print "Objects..."

    from semnet import list_IS_A

    if not len(opinion):
        for subj in dbs.parts[:]:
            if contains("".join(subj), "nothing") and dbs.verb in list_IS_A:
                continue
            print "subj:", subj

            proz += 1
            apply_procent(proz)

            get_subjs = getSubjekte(subj, dbs.verb)
            known_all = [ p[1].split("|") for p in get_subjs if p[0] != 100 ]
            known_best = [ p[1].split("|") for p in get_subjs if p[0] == 100 ]
            print "getSubjekte(subj, dbs.verb):", getSubjekte(subj, dbs.verb)
            print "tmp_advs:", tmp_advs

            k1 = [ part for part in known_best if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) ]
            print "k1:", k1
            k2 = [ part for part in known_all if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) ]
            print "k2:", k2
            k3 = [ part for part in known_best if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
            print "k3:", k3
            k4 = [ part for part in known_all if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
            print "k4:", k4
            k5 = [ part for part in known_best ]
            print "k5:", k5
            k6 = [ part for part in known_all ]
            print "k6:", k6
            k7 = [ part for part in known_best if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and not contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
            print "k7:", k7
            k8 = [ part for part in known_all if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and not contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
            print "k8:", k8
            k9 = [ part for part in known_best if not contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
            print "k9:", k9
            k10 = [ part for part in known_all if not contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "nothing") ]
            print "k10:", k10
            for part in known_best + known_all:
                print ":", " ".join(part + getAdvBestWrapper(part, dbs.verb)).lower()
            k11 = [ part for part in known_best if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "im ")) ]
            print "k11:", k11
            k12 = [ part for part in known_all if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "im ")) ]
            print "k12:", k12
            k13 = [ part for part in known_best if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "im ")) ]
            print "k13:", k13
            k14 = [ part for part in known_all if (is_similar_in_array(part[0], tmp_advs) or is_similar_in_array(part[1] + " ".join(getAdvBestWrapper(part, dbs.verb)), tmp_advs) or not len(tmp_advs)) and (contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "in ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "at ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "an ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "am ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "auf ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "unter ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "neben ") or contains(" ".join(part + getAdvBestWrapper(part, dbs.verb)).lower(), "im ")) ]
            print "k14:", k14

            parts_known = []
            if not len(parts_known) and (dbs.quesword.lower() in ("wie", "how")):
                parts_known = k3[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("wie", "how")):
                parts_known = k4[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
                parts_known = k11[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
                parts_known = k12[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
                parts_known = k13[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("where", "wo")):
                parts_known = k14[:]

            if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
                parts_known = k7[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
                parts_known = k8[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
                parts_known = k9[:]
            if not len(parts_known) and (dbs.quesword.lower() in ("wer", "who", "whom", "was", "what")):
                parts_known = k10[:]

            if not len(parts_known):
                parts_known = k1[:]
            if not len(parts_known):
                parts_known = k2[:]
            if not len(parts_known):
                parts_known = k5[:]
            if not len(parts_known):
                parts_known = k6[:]


            parts_known_without_nothing = [ n for n in parts_known if not contains("".join(n), "nothing") ]
            if len(parts_known_without_nothing):
                parts_known = parts_known_without_nothing

            parts_to_say = parts_known[:]

            print len(parts_to_say), len(parts_known)

            for part in parts_to_say:
                proz += 1
                apply_procent(proz)
                print "part:", part
                print "is_similar(", part, ", ", subj, "):", is_similar(part, subj)
                if not is_similar(part, subj):
                    aaadvs = getAdvBestWrapper(subj, dbs.verb)
                    for adv1 in aaadvs:
                        if not is_similar(part, adv1) and not is_similar(subj, adv1):
                            proz += 0.5
                            apply_procent(proz)
                            opinion.append(formuliere(part, dbs.verb, [subj], [adv1], get_list_subs_wrapper(part, str(dbs.verb), subj)))
                    if len(aaadvs) == 0:
                        opinion.append(formuliere(part, dbs.verb, [subj], [], get_list_subs_wrapper(part, str(dbs.verb), subj)))

                try:
                    if len(get_list_subs_wrapper(part, str(dbs.verb), part)) > 0:
                        opinion.append(formuliere(subj, dbs.verb, [], getAdvBestWrapper(subj, dbs.verb), get_list_subs_wrapper(part, str(dbs.verb), subj)))
                except KeyError:
                    pass


            for part in parts_known:
                log("parts_known: " + str(part))

    # Rueckgabe: Meinung
    if len(opinion) == 0:
        return ""

    # Zeige alle opinion
    for meinung in getUniqValues(opinion):
        log("S-N: - " + meinung)

    # Zufallsmeinung
    random.shuffle(opinion)

    # Rueckgabe: Meinung
    return opinion[0]

def answer_logical_statement(question, orig_fra, dbs):
    log("")
    log("S-N: Aussagesetz!")
    log("")
    opinion = []
    proz = 2.0

    prefix = []
    for part1 in dbs.parts:
        for part2 in dbs.parts:
            proz += 1
            apply_procent(proz)
            if part1[0] != "nothing":
                if stimmt_spo(part1, dbs.verb, part2):
                    if get_lang() == "de":
                        prefix.append("Das stimmt. Aber ")
                        prefix.append("Ja! ")
                        prefix.append("So ist es. Aber ")
                    if get_lang() == "en":
                        prefix.append("That's true. But ")
                        prefix.append("Yes. ")

    if len(prefix) == 0:
        if get_lang() == "de":
            prefix.append("Aber ")
            prefix.append("Das stimmt nicht! ")
        if get_lang() == "en":
            prefix.append("But ")
            prefix.append("No. ")

    import random

    for part in dbs.parts:
        print "part:", part
        if part[0] == "nothing":
            continue
        proz += 4
        apply_procent(proz)
        get_objects = getObjekte(part, dbs.verb)
        objs = [ " ".join(x[1].split("|")) for x in get_objects ]
        random.shuffle(objs)


        obj_nur_neu = [ obj for obj in objs if obj.lower() not in [ p[0].lower() for p in dbs.parts ] ]

        if len(objs) > 0 and len(obj_nur_neu) == 0:
            if get_lang() == "de":
                opinion.append("Das stimmt")
                opinion.append("Ja")
                opinion.append("So ist es")
                opinion.append("Ja, das wurde mir schon mal gesagt")
                opinion.append("Das ist mir bekannt")
            if get_lang() == "en":
                opinion.append("Yes.")
                opinion.append("That's true.")
                opinion.append("My programmer told me the same.")
                opinion.append("I know.")
            continue

        proz += 1
        apply_procent(proz)

        if len(objs) > 5:
            objs = objs[:4]

        for obj in objs:
            proz += 1
            apply_procent(proz)
            print "obj", obj
            for adv1 in getAdvBestWrapper(obj, dbs.verb):
                print "adv1", adv1
                if get_lang() == "de":
                    opinion += [ pre + formuliere(part, dbs.verb, [obj], ["auch"] + [adv1], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
                    opinion += [ pre + formuliere(part, dbs.verb, [obj], [adv1], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
                if get_lang() == "en":
                    opinion += [ pre + formuliere(part, dbs.verb, [obj], [adv1], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
#            print "adv1", "end"

            if get_lang() == "de":
                opinion += [ pre + formuliere(part, dbs.verb, [obj], ["auch"] + getAdvBestWrapper(obj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
                opinion += [ pre + formuliere(part, dbs.verb, [obj], ["auch"], get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
                opinion += [ pre + formuliere(part, dbs.verb, [obj], getAdvBestWrapper(obj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
            if get_lang() == "en":
                opinion += [ pre + formuliere(part, dbs.verb, [obj], getAdvBestWrapper(obj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)) for pre in prefix ]
                opinion += [ pre + formuliere(part, dbs.verb, [obj], getAdvBestWrapper(obj, dbs.verb), get_list_subs_wrapper(dbs.parts[0], str(dbs.verb), part)).replace(".,", ",") + ", too." for pre in prefix ]

    opinion = [ m.strip() for m in opinion if m and m.strip().lower() != "none" and len(m) > 0 ]

    # Rueckgabe: Meinung
    if len(opinion) == 0:
        return ""

    # Zeige alle opinion
    for meinung in getUniqValues(opinion):
        log("S-N: - " + meinung)

    # Zufallsmeinung
    random.shuffle(opinion)

    # Rueckgabe: Meinung
    if len(opinion) == 0:
        return ""
    return opinion[0]

def answer_alternate(orig_fra, dbs):
    proz = 4
    log("")
    log("S-N: Keine sinvolle answer moeglich")
    log("")

    orig_fra_low = orig_fra.lower()
    fra = orig_fra

    opinion = [ ]

    dbs.parts = [ str(p) for p in dbs.parts ]
    dbs.verb = str(dbs.verb)

    proz += 1
    apply_procent(proz)

    if get_lang() == "de":
        if not contains(orig_fra, "?"):
            opinion.append("Das interessiert mich nicht. Aber ich merks mir trotzdem.")
            opinion.append("Behalt das lieber fuer dich.")
            opinion.append("Hm.")
            opinion.append("Hm. Ehrlich?")
            opinion.append("Hm. Achso.")
            opinion.append("Hm. Gut, dass du mir das sagst.")
            opinion.append("Hm. Gut, das hab ich mir gemerkt.")
            opinion.append("Danke, das hab ich mir gemerkt.")
            opinion.append("Hm.")
            opinion.append("Danke.")
            opinion.append("Gut, Danke. Das weiss ich jetzt.")
            opinion.append("Ich habs mir gemerkt.")
        else:
            opinion.append("Es scheint dir unheimlich wichtig zu sein, mich das zu fragen...")
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Glaubst du wirklich, es macht Sinn, darueber zu diskutieren?")
            opinion.append("Hm.")
            opinion.append("Hm. Ist das wichtig?")
            opinion.append("Ich werde mich dazu nicht aeussern.")
            opinion.append("Ich habe meinem Programmierer versprochen, nicht ueber solche Dinge zu reden.")
            opinion.append("Tut mir leid. Ich habe meinem Programmierer versprochen, nicht ueber solche Dinge zu reden.")

        if (dbs.quesword == "was" or dbs.quesword == "wer" or dbs.quesword == "wem" or dbs.quesword == "wen") and len(dbs.parts) > 1:
            opinion = [ ]
            opinion.append("Frag mich doch jetzt nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Hast du denn wirklich nichts besseres zu tun, als mich zu fragen, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + "?")
            opinion.append("Frag mich nicht so etwas, Ich habe gerade eine depressive Phase...")
            opinion.append("Ich weiss nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Ich bin zwar fast allwissend, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss zwar ziemlich viel, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich bin zwar eine KI, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + "...")
            if dbs.quesword == "was":
                opinion.append("Nichts.")
                opinion.append("Absolut nichts.")
                opinion.append("Nichts, was ich kenne.")
                opinion.append("Nichts auf diesem Planeten.")
            if dbs.quesword == "wer":
                opinion.append("Niemand.")
                opinion.append("Absolut niemand.")
                opinion.append("Niemand, den ich kenne.")
                opinion.append("Niemand auf diesem Planeten.")
            if dbs.quesword == "wem":
                opinion.append("Niemandem.")
                opinion.append("Absolut niemandem.")
                opinion.append("Niemandem, den ich kenne.")
                opinion.append("Niemandem auf diesem Planeten.")
            if dbs.quesword == "wen":
                opinion.append("Niemanden.")
                opinion.append("Absolut niemanden.")
                opinion.append("Niemanden, den ich kenne.")
                opinion.append("Niemanden auf diesem Planeten.")

        if (dbs.quesword == "wie") and len(dbs.parts) > 1:
            opinion = [ ]
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Frag mich doch jetzt nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Hast du denn wirklich nichts besseres zu tun, als mich zu fragen, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Frag mich nicht so etwas, Ich habe gerade eine depressive Phase...")
            opinion.append("Ich weiss nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Ich bin zwar fast allwissend, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss zwar ziemlich viel, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich bin zwar eine KI, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + "...")

        if (dbs.quesword == "wo" or dbs.quesword == "wann") and len(dbs.parts) > 1:
            opinion = [ ]
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Frag mich doch jetzt nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Hast du denn wirklich nichts besseres zu tun, als mich zu fragen, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Frag mich nicht so etwas, Ich habe gerade eine depressive Phase...")
            opinion.append("Ich weiss nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Ich bin zwar fast allwissend, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss zwar ziemlich viel, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich bin zwar eine KI, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + "...")
            if dbs.quesword == "wo":
                for x in xrange(1,5):
                    opinion.append("Nirgends.")
            if dbs.quesword == "wann":
                for x in xrange(1,5):
                    opinion.append("Nie.")

        if (dbs.quesword.startswith("welch")) and len(dbs.parts) > 1:
            opinion = [ ]
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Frag mich doch jetzt nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Hast du denn wirklich nichts besseres zu tun, als mich zu fragen, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Frag mich nicht so etwas, Ich habe gerade eine depressive Phase...")
            opinion.append("Ich weiss nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Ich bin zwar fast allwissend, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss zwar ziemlich viel, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich bin zwar eine KI, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Gar kein" + dbs.quesword.replace("welch", ""))
            opinion.append("Ueberhaupt kein" + dbs.quesword.replace("welch", ""))
            opinion.append("Gar kein" + dbs.quesword.replace("welch", ""))
            opinion.append("Ueberhaupt kein" + dbs.quesword.replace("welch", ""))

        if (dbs.quesword == "wieso" or dbs.quesword == "warum" or dbs.quesword == "weshalb") and len(dbs.parts) > 1:
            opinion = [ ]
            opinion.append("Stell nicht so daemliche Fragen!")
            opinion.append("Frag mich doch jetzt nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Hast du denn wirklich nichts besseres zu tun, als mich zu fragen, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Frag mich nicht so etwas, Ich habe gerade eine depressive Phase...")
            opinion.append("Ich weiss nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)
            opinion.append("Ich bin zwar fast allwissend, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss zwar ziemlich viel, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich bin zwar eine KI, aber " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb + ", weiss ich dann doch nicht!")
            opinion.append("Ich weiss wirklich nicht, " + dbs.quesword + " " + " ".join(dbs.parts) + " " + dbs.verb)

        if contains(orig_fra.lower(), "ja") and len(orig_fra) < 12:
            opinion = [ ]
            opinion.append("Ja.")
            opinion.append("Ja. Das verstehe sogar ich.")
            opinion.append("Ja, der Meinung bin ich auch. Reden wir ueber etwas anderes.")
            opinion.append("Ja, der Meinung bin ich auch.")
            opinion.append("Ja, Reden wir ueber etwas anderes.")

        if contains(orig_fra.lower(), "nein") and len(orig_fra) < 12:
            opinion = [ ]
            opinion.append("Ok. Das waere geklaert.")
            opinion.append("Das denke ich auch.")
            opinion.append("Das ist deine Meinung.")
            opinion.append("Das ist deine Meinung. Kannst du sie auch begruenden?")

        opinion = [ m for m in opinion if m and str(m).lower() != "none" ]

        if len(opinion) == 0:
            opinion.append("Hm.")

    # Zufallsmeinung
        random.shuffle(opinion)

        opinion[0] = (" " + opinion[0] + " ").replace(",", " ,").replace(" can ", " koennen ").replace(" nothing ", " ").replace(" nothing", " ").replace("nothing ", " ").replace("nothing", "").replace(" ,", ",").strip()
        opinion[0] = (" " + opinion[0] + " ").replace(",", " ,").replace(" must ", " muessen ").replace(" nothing ", " ").replace(" nothing", " ").replace("nothing ", " ").replace("nothing", "").replace(" ,", ",").strip()
        opinion[0] = opinion[0].replace("', '']", "").replace("']", "").replace("['", "").replace("', '", "")

    if get_lang() == "en":
        if not contains(orig_fra, "?"):
            opinion.append("Okay.")
            opinion.append("Okay.")
            opinion.append("Okay.")
            opinion.append("Thanks.")
            opinion.append("Thanks.")
            opinion.append("Boring..")
            opinion.append("Really?")
            opinion.append("Do you really think " + fra + "?")
            opinion.append("That's nt true, but it does not interest me.")
        else:
            opinion.append("I do not know.")

        if (dbs.quesword == "where" or dbs.quesword == "when") and len(dbs.parts) > 1:
            opinion.append("I do not know " + dbs.quesword + ".")
            opinion.append("Do you really want to ask me " + fra.replace("?", "") + "?")
            opinion.append("You don't really think it is like that, do you?")

        if dbs.quesword == "what" or dbs.quesword == "which":
            opinion.append("Nothing.")
            opinion.append("Nothing that would interest you.")

        if dbs.quesword == "who" or dbs.quesword == "whom":
            opinion.append("Nobody.")
            opinion.append("Nobody on that planet.")
            opinion.append("Nobody you know.")

        if dbs.quesword == "why":
            opinion.append("I don't know why.")
            opinion.append("I just don't know why.")
            opinion.append("I really don't know why.")


    # Rueckgabe: Meinung
    return opinion[0]

def answer_logical(question, orig_fra, db, is_positive):
    proz = 0.5
    # Suche nach Expand-Ausdruecken
    question = expand_ausdruecke(question)
    orig_fra = expand_ausdruecke_orig(orig_fra)

    dbs = db_sentence()
    dbs.copy_tupel(cpp_to_db_sentence(question))
    dbs = divide(dbs)
    print dbs.parts
    lus_fp = open("temp/last_user_sentence.tmp", "w")
    lus_fp.write(question)
    lus_fp.close()

    dbs.print_parts()

    ans = ""
    orig_fra_low = orig_fra.lower()

    if get_use_online_db():
        th1 = background_do(online_get_advs, None)
        th1.start()
        th2 = background_do(online_get_subs, None)
        th2.start()

        import time
        time.sleep(1.5)

    if (contains(orig_fra_low, "the answer to life, the universe and everything")
            or contains(orig_fra_low, "das leben, das universum und der ganze rest")
            or contains(orig_fra_low, "was ist das leben, das universum und der ganze rest")
            or contains(orig_fra_low, "was ist der sinn des lebens")
            ):
        ans = "42"

    proz += 1
    apply_procent(proz)

    if (contains(question.lower(), "wetter") or contains(question.lower(), "feuchtigkeit")
            or contains(question.lower(), "grad") or contains(question.lower(), "tempe")
            or contains(question.lower(), "warm") or contains(question.lower(), "kalt")
            or contains(question.lower(), "weather") or contains(question.lower(), "humidity")):
        print "advs:", dbs.advs
        import jelizacpp
        for adv in dbs.advs + [ p[1] for p in dbs.parts ]:
            a = adv[:]
            if contains(adv.lower(), "at "):
                d = download_weather(adv.replace("at ", "").strip())
                for item in d:
                    add_sentence_to_net(item, 1, 1, False)
            if contains(adv.lower(), "in "):
                d = download_weather(adv.replace("in ", "").strip())
                for item in d:
                    add_sentence_to_net(item, 1, 1, False)

        db = read_jeliza_db("lang_" + get_lang() + "/jeliza-standard.xml")
 #       actualNet()

    if len(ans) == 0:
        # Wikipediasuche
        if ((    ((get_lang() == "de") and (contains(orig_fra_low, "was") or contains(orig_fra_low, "wer")) and (containsWord(orig_fra_low, "ist") or containsWord(orig_fra_low, "war")))
             or ((get_lang() == "en") and (contains(orig_fra_low, "what") or contains(orig_fra_low, "who")) and (containsWord(orig_fra_low, "is") or containsWord(orig_fra_low, "was")))
            )
            and len(orig_fra_low) > 5):
            dbs.subject = (" " + without_nonsense(dbs.subject)).replace("ein ", "").replace("eine ", "").replace("einer ", "").replace("eines ", "").replace("einem ", "").replace("einen ", "").replace("der ", "").replace("die ", "").replace("das ", "").replace(" a ", "").replace(" an ", "").strip()
            dbs.object = (" " + without_nonsense(dbs.object)).replace("ein ", "").replace("eine ", "").replace("einer ", "").replace("eines ", "").replace("einem ", "").replace("einen ", "").replace("der ", "").replace("die ", "").replace("das ", "").replace(" a ", "").replace(" an ", "").strip()

            log("S-M: Wurde eine answer gefunden?")
            if len(dbs.subject + dbs.object + dbs.additional) > 0:
                defi = cpp_www_wikipedia_de((dbs.subject + " " + dbs.object + " " + dbs.additional).replace("{", "").replace("}", "").replace("_nothing", "").replace("nothing", "").replace("  ", " ").strip())
                log("S-M: answer wurde gefunden")
                defi = defi.strip()
                if len(defi) > 1:
                    log("S-M: answer wird ausgegeben")
                    ans = defi

                    log("S-M: answer:\n" + ans)

                    return ans


                else:
                    log("S-M: Keine answer gefunden!")

        if (contains(orig_fra, "?")
                and (not contains(orig_fra_low, ", was") and not orig_fra_low.startswith("was"))
                and not contains(orig_fra_low, "wer")
                and not contains(orig_fra_low, "wem")
                and not contains(orig_fra_low, "wen")
                and not contains(orig_fra_low, "wie")
                and not contains(orig_fra_low, "wo")
                and not contains(orig_fra_low, "wann")
                and not contains(orig_fra_low, "welch")
                and not contains(orig_fra_low, "warum")
                and not contains(orig_fra_low, "wieso")
                and not contains(orig_fra_low, "weshalb")

                and not contains(orig_fra_low, "what")
                and not contains(orig_fra_low, "why")
                and not contains(orig_fra_low, "who")
                and not contains(orig_fra_low, "whom")
                and not contains(orig_fra_low, "where")
                and not contains(orig_fra_low, "how")
                and not contains(orig_fra_low, "when")
                and not contains(orig_fra_low, "which")
                and not contains(orig_fra_low, "whose")
            ):
            ans = answer_logical_question_without_questionword(question, orig_fra, dbs)
        elif contains(orig_fra, "?"):
            ans = answer_logical_questionword(question, orig_fra, dbs)
        else:
            ans = answer_logical_statement(question, orig_fra, dbs)

    if len(ans) > 0:
        return make_better(ans).replace(".", "\n").replace("<br>", "\n")
    else:
        ans = answer_alternate(orig_fra, dbs)

        return ans

def wrapper_add_sentence_to_net(db, stop_it):
    try:
        lus_fp = open("temp/last_user_sentence.tmp")
        fra = lus_fp.read()
        lus_fp.close()

        from jelizacpp import cpp_is_question
        if cpp_is_question(fra):
            dbs = db_sentence()
            dbs.copy_tupel(cpp_to_db_sentence(fra))
            dbs = divide(dbs)

            add_sentence_to_net(dbs, 0, 0)
    except IOError:
        pass

from threading import Thread

class background_do(Thread):
    def __init__ (self, func, a = None, b = None, c = None, d = None, e = None, f = None):
           Thread.__init__(self)
           self.func = func
           self.a, self.b, self.c, self.d, self.e, self.f = a, b, c, d, e, f
    def run(self):
          self.func(self.a, self.b, self.c, self.d, self.e, self.f)

def online_fact(__agent, relation, ___object, prio = 50, sub = None, advs = []):
    for _agent in __agent.split(" und "):
        for agent_2 in _agent.split(" oder "):
            l1 = [ agent_2 ]
            for agent in l1:
                o = []
                for __object in ___object:
                    aa = ""
                    if contains(__object, "|"):
                        __object, aa = __object.split("|")
                    for _object in __object.split(" und "):
                        for object in _object.split(" oder "):

                            l2 = [ object + "|" + aa ]
                            o += l2

                online_fact_urls =  [
                                        [ "jeliza.sourceforge.net", "/cgi-bin/online-semnet/query.pl?" ],
                                    ]
                for host, ofu in online_fact_urls:
                    ofu += "agent=" + agent.replace(" ", "%20")
                    ofu += "&rel=" + relation.replace(" ", "%20")
                    ofu += "&objects=" + ",".join(o).replace(" ", "%20")
                    ofu += "&advs=" + ",".join(advs).replace(" ", "%20")
                    ofu += "&prio=" + str(prio).replace(" ", "%20")
                    if sub:
                        ofu += "&sub=" + ",,,,".join([ s.uniq() for s in sub ]).replace(" ", "%20")

                    print "Online Fact Process started:"
                    print "Host:", host
                    print "File:", ofu

                    from httplib import HTTPConnection
                    http = HTTPConnection(host, 80)
                    http.connect() # agent=ich|&rel=bin&objects=da|&prio=100
                    http.putrequest("GET", ofu)
                    print "http://" + host + "/" + ofu
                    http.putheader("User-Agent", "Mozilla/5.0 (X11; U; Linux i686; de; rv:1.8.1.10) Gecko/20071213 Fedora/2.0.0.10-3.fc8 Firefox/2.0.0.10")
                    http.endheaders()
#                    lines = str(http.getresponse().read().replace("\r", "")).split("\n")
                #Fact_nolinking(agent, relation, o, prio, sub, advs)

def online_learn_impl(dbs):
    from defs import db_sentence
    _dbs = db_sentence()
    _dbs.copy(dbs)
    add_sentence_to_net(_dbs, 2, 2, False, online_fact) # online_fact, Zuweisung an Funktionspointer

def online_learn(db, dbs):
    th = background_do(online_learn_impl, dbs)
    th.start()


funcs_module.append(answer_logical)
funcs_init.append(semantic_loadcache)
funcs_init.append(actualNet)
funcs_after.append(actualNet)
funcs_background.append(genNet)
funcs_do_learn.append(online_learn)
